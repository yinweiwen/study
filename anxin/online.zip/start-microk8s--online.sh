#!/bin/bash

echo "------准备--在线启动本地化---------"
echo "------1--开始安装和更新 microk8s---------"

snap version && snap refresh
sudo snap install microk8s --classic --channel=1.22

if [ $? != 0 ]; then
    echo "------1-- microk8s  安装失败  code=$?---------"
    echo "------1-- microk8s  准备退出 ---------"
    exit 0
fi

microk8s.kubectl create namespace lk

echo "------1-- microk8s  安装完成 ---------"

echo "------2--准备--导入 microk8s-看板组件 ---------"
echo "------2--执行组件镜像拉取 shell脚本 ---------"
source ./fetch-images.sh

if [ $? != 0 ]; then
    echo "------2-- dashbaord组件  准备失败 ---------"
    echo "------2-- dashbaord组件  准备退出 ---------"
    exit 0
fi

echo "------2-- 组件  准备启动 (这步耗时较久，请等待)---------"
microk8s status --wait-ready && microk8s enable dashboard

token=$(microk8s kubectl -n kube-system get secret | grep default-token | cut -d " " -f1)
microk8s kubectl -n kube-system describe secret $token >dashboard_token.txt

microk8s enable dns

echo "------2-- 组件  启动完成 ---------"

echo "------3-- 本地化 基础进程 开始拉取 ---------"

#es 挂载数据路径
mkdir -p /home/anxinlocal/esdata
chmod 777 /home/anxinlocal/esdata
#webapi 报表模板路径
mkdir -p /home/anxinlocal/static
#pg 挂载数据路径
mkdir -p /home/anxinlocal/pgdata

#拉取 base 镜像
echo "------2--执行 base 镜像拉取 shell脚本 ---------"
source ./pull-base-images.sh

sleep 10s

#启动 base pod
yaml_list=()
source ./loopDirToFindYaml2.sh base_images
echo "f-yaml文件个数为: ${#yaml_list[*]}"

for item in ${yaml_list[*]}; do
    echo "------3--开始拉取base镜像pod ${item} ---------"
    microk8s.kubectl apply -f ${item}
    sleep 10s
done

#拉取 app 镜像（提前拉取应用镜像  给base镜像pod拉起时间）
echo "------3--执行 app 镜像拉取 shell脚本 ---------"
source ./pull-app-images.sh

echo "准备执行pg创建库脚本"
#测试用
pgpodname=$(microk8s.kubectl get pod -n lk | grep pg-deployment- | awk '{print $1}')
echo " pod名称 $pgpodname"

#测试用
echo "------4--开始执行数据库脚本 ---------"
#pg数据库 脚本
#microk8s.kubectl -n lk logs "$(microk8s.kubectl get pod -n lk | grep pg-deployment- | awk '{print $1}')"

microk8s.kubectl exec -i "$pgpodname" -n lk -- psql -U postgres <./base_images/pg/pgscript/create_db.sql
sleep 5s
microk8s.kubectl exec -i "$pgpodname" -n lk -- psql -U postgres -d iota <./base_images/pg/pgscript/iota_create.sql
sleep 5s
microk8s.kubectl exec -i "$pgpodname" -n lk -- psql -U postgres -d axy <./base_images/pg/pgscript/axy_schema.sql
sleep 5s
microk8s.kubectl exec -i "$pgpodname" -n lk -- psql -U postgres -d axy <./base_images/pg/pgscript/axy_data.sql
sleep 5s

#microk8s.kubectl exec -i pg-deployment-6b5dbdc447-l7qqk -n lk -- psql -U postgres -f script/create_db.sql

echo "------5--开始创建es索引 ---------"
source ./base_images/ESAndKibana/init_es/init_es_index.sh
echo "------5--结束创建es索引 ---------"

#kafka pod地址 存入hosts
#sed -i "1i    $(microk8s.kubectl -n lk get pod -o wide | grep kafka-deployment- | awk '{print $6,$1}') " /etc/hosts

#cat /etc/hosts

echo "------6-- 本地化 进程 开始拉取 ---------"

source ./loopDirToFindYaml2.sh app_images
echo "f-yaml文件个数为: ${#yaml_list[*]}"

for item in ${yaml_list[*]}; do
    echo "------6--开始拉取app镜像pod ${item} ---------"
    microk8s.kubectl apply -f ${item}
    sleep 10s
done

echo "------7-- 本地化 进程 部署完成  开始使用 ---------"

cat dashboard_token.txt

#microk8s.kubectl edit svc -n kube-system   kubernetes-dashboard
