#!/bin/bash
images=(
    k8s.gcr.io/pause:3.1=registry.cn-hangzhou.aliyuncs.com/google_containers/pause-amd64:3.1
    k8s.gcr.io/google_containers/defaultbackend:1.4=registry.cn-hangzhou.aliyuncs.com/google_containers/defaultbackend:1.4
    k8s.gcr.io/kubernetes-dashboard-amd64:v1.10.1=registry.cn-hangzhou.aliyuncs.com/google_containers/kubernetes-dashboard-amd64:v1.10.1
    k8s.gcr.io/heapster-influxdb-amd64:v1.3.3=registry.cn-hangzhou.aliyuncs.com/google_containers/heapster-influxdb-amd64:v1.3.3
    k8s.gcr.io/heapster-amd64:v1.5.2=registry.cn-hangzhou.aliyuncs.com/google_containers/heapster-amd64:v1.5.2
    k8s.gcr.io/heapster-grafana-amd64:v4.4.3=registry.cn-hangzhou.aliyuncs.com/google_containers/heapster-grafana-amd64:v4.4.3
    #1.22 microk8s版本 metrics-server
    k8s.gcr.io/metrics-server/metrics-server:v0.5.0=registry.cn-hangzhou.aliyuncs.com/google_containers/metrics-server:v0.5.0
    #1.21 microk8s版本 metrics-server
    #k8s.gcr.io/metrics-server-amd64:v0.3.6=registry.cn-hangzhou.aliyuncs.com/google_containers/metrics-server-amd64:v0.3.6
    #calico-node 需要
    docker.io/calico/cni:v3.19.1=docker.io/calico/cni:v3.19.1
	#ingress
	k8s.gcr.io/ingress-nginx/controller:v1.0.0-alpha.2=registry.cn-hangzhou.aliyuncs.com/google_containers/nginx-ingress-controller:v1.0.0-alpha.2
)

OIFS=$IFS # 保存旧值

for image in ${images[@]}; do
    IFS='='
    set $image
    echo "准备拉取 $2"
    microk8s.ctr image pull $2
    microk8s.ctr image tag $2 $1
    microk8s.ctr image rm $2
    echo "拉取成功"
    IFS=$OIFS # 还原旧值
done

return 0
