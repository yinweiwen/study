--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: orgid; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgid (
    id integer
);


--
-- Name: t_abn_report_params; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_abn_report_params (
    id integer NOT NULL,
    station_id integer NOT NULL,
    factor_proto_code character varying(30) NOT NULL,
    itemid integer,
    abn_type integer,
    params jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL
);


--
-- Name: t_abn_report_params_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_abn_report_params_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_abn_report_params_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_abn_report_params_id_seq OWNED BY public.t_abn_report_params.id;


--
-- Name: t_abn_report_push_strategy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_abn_report_push_strategy (
    id integer NOT NULL,
    user_id integer NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    structures integer[] NOT NULL,
    created_org integer
);


--
-- Name: t_abn_report_push_strategy_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_abn_report_push_strategy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_abn_report_push_strategy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_abn_report_push_strategy_id_seq OWNED BY public.t_abn_report_push_strategy.id;


--
-- Name: t_abn_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_abn_type (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(50) NOT NULL
);


--
-- Name: t_agg_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_agg_config (
    id integer NOT NULL,
    struct_id integer NOT NULL,
    factor_id integer NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    category integer NOT NULL,
    algorithm integer NOT NULL,
    start_day smallint,
    end_day smallint,
    start_hour smallint,
    end_hour smallint,
    delete boolean DEFAULT false NOT NULL,
    start_time integer NOT NULL,
    time_range jsonb
);


--
-- Name: t_agg_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_agg_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_agg_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_agg_config_id_seq OWNED BY public.t_agg_config.id;


--
-- Name: t_agg_threshold_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_agg_threshold_config (
    id integer NOT NULL,
    struct_id integer NOT NULL,
    factor_id integer NOT NULL,
    agg_category integer NOT NULL,
    item_id smallint NOT NULL,
    threshold_level smallint NOT NULL,
    threshold_lower double precision NOT NULL,
    threshold_upper double precision NOT NULL,
    start_hour smallint,
    end_hour smallint
);


--
-- Name: t_agg_threshold_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_agg_threshold_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_agg_threshold_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_agg_threshold_config_id_seq OWNED BY public.t_agg_threshold_config.id;


--
-- Name: t_agg_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_agg_type (
    id integer NOT NULL,
    type_name character varying(30) NOT NULL,
    parent_type_id smallint NOT NULL,
    description character varying(30),
    name character varying(10)
);


--
-- Name: t_alarm; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_alarm (
    id integer NOT NULL,
    alarm_type integer NOT NULL,
    source_type integer NOT NULL,
    structure integer NOT NULL,
    device uuid,
    sensor integer,
    alarm_info character varying(256) NOT NULL,
    alarm_level integer NOT NULL,
    alarm_count integer NOT NULL,
    begin_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone,
    alarm_state integer NOT NULL
);


--
-- Name: t_alarm_category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_alarm_category (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: t_alarm_category_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_alarm_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_alarm_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_alarm_category_id_seq OWNED BY public.t_alarm_category.id;


--
-- Name: t_alarm_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_alarm_code (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(255),
    type_code character varying(20) NOT NULL,
    level integer NOT NULL,
    upgrade_strategy jsonb,
    enable boolean DEFAULT true NOT NULL
);


--
-- Name: t_alarm_code_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_alarm_code_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_alarm_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_alarm_code_id_seq OWNED BY public.t_alarm_code.id;


--
-- Name: t_alarm_custom_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_alarm_custom_message (
    id integer NOT NULL,
    structure integer NOT NULL,
    email character varying(255),
    sms character varying(255)
);


--
-- Name: t_alarm_custom_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_alarm_custom_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_alarm_custom_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_alarm_custom_message_id_seq OWNED BY public.t_alarm_custom_message.id;


--
-- Name: t_alarm_deal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_alarm_deal (
    id integer NOT NULL,
    alarm integer NOT NULL,
    deal_user integer NOT NULL,
    deal_info character varying(256),
    deal_time timestamp with time zone NOT NULL
);


--
-- Name: t_alarm_deal_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_alarm_deal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_alarm_deal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_alarm_deal_id_seq OWNED BY public.t_alarm_deal.id;


--
-- Name: t_alarm_detail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_alarm_detail (
    id bigint NOT NULL,
    alarm integer NOT NULL,
    alarm_info character varying(256) NOT NULL,
    alarm_time timestamp with time zone NOT NULL
);


--
-- Name: t_alarm_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_alarm_detail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_alarm_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_alarm_detail_id_seq OWNED BY public.t_alarm_detail.id;


--
-- Name: t_alarm_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_alarm_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_alarm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_alarm_id_seq OWNED BY public.t_alarm.id;


--
-- Name: t_alarm_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_alarm_policy (
    id integer NOT NULL,
    structures integer[] NOT NULL,
    sms_noticed boolean NOT NULL,
    notice_users integer[] NOT NULL,
    enabled boolean NOT NULL,
    created_organization integer NOT NULL,
    alarm_categories integer[] NOT NULL,
    email_noticed boolean NOT NULL,
    email_alarm_levels integer[],
    sms_alarm_levels integer[],
    wx_noticed boolean DEFAULT false NOT NULL,
    wx_alarm_levels integer[],
    extras jsonb,
    broadcast_noticed boolean DEFAULT false NOT NULL,
    broadcast_alarm_levels integer[],
    broadcast_device_id character varying(50)
);


--
-- Name: t_alarm_policy_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_alarm_policy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_alarm_policy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_alarm_policy_id_seq OWNED BY public.t_alarm_policy.id;


--
-- Name: t_alarm_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_alarm_type (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    category integer NOT NULL,
    enabled boolean NOT NULL,
    upgrade_strategy jsonb
);


--
-- Name: t_alarm_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_alarm_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_alarm_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_alarm_type_id_seq OWNED BY public.t_alarm_type.id;


--
-- Name: t_api_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_api_log (
    id bigint NOT NULL,
    log_time timestamp with time zone NOT NULL,
    method character varying(20),
    content character varying(256),
    parameter character varying(256),
    parameter_show character varying(256),
    user_agent character varying(512),
    url character varying(256),
    status_code integer,
    cost integer,
    visible boolean NOT NULL
);


--
-- Name: t_api_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_api_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_api_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_api_log_id_seq OWNED BY public.t_api_log.id;


--
-- Name: t_app_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_app_message (
    id integer NOT NULL,
    project_id integer NOT NULL,
    title character varying(128) NOT NULL,
    content character varying(4096) NOT NULL,
    post_time timestamp(6) with time zone NOT NULL,
    post_user_id integer NOT NULL,
    expired_time timestamp(6) with time zone NOT NULL
);


--
-- Name: t_app_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_app_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_app_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_app_message_id_seq OWNED BY public.t_app_message.id;


--
-- Name: t_apply; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_apply (
    id integer NOT NULL,
    phone character varying(11) NOT NULL,
    org character varying(100) NOT NULL,
    province character varying(20) NOT NULL,
    city character varying(20) NOT NULL,
    struct_types character varying(50) NOT NULL,
    reg_code uuid NOT NULL,
    submit_date timestamp with time zone NOT NULL,
    process_date timestamp with time zone,
    approved boolean,
    remarks character varying(200)
);


--
-- Name: t_apply_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_apply_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_apply_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_apply_id_seq OWNED BY public.t_apply.id;


--
-- Name: t_averagerainfall; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_averagerainfall (
    id integer NOT NULL,
    "structId" integer NOT NULL,
    rainfall numeric(8,3) NOT NULL,
    "time" timestamp with time zone NOT NULL
);


--
-- Name: t_averagerainfall_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_averagerainfall_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_averagerainfall_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_averagerainfall_id_seq OWNED BY public.t_averagerainfall.id;


--
-- Name: t_bim_rendering_path; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_bim_rendering_path (
    id integer NOT NULL,
    structure_id character varying(50) NOT NULL,
    bim_rendering_path character varying(200) NOT NULL
);


--
-- Name: t_bim_rendering_path_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_bim_rendering_path_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_bim_rendering_path_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_bim_rendering_path_id_seq OWNED BY public.t_bim_rendering_path.id;


--
-- Name: t_bim_stations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_bim_stations (
    id integer NOT NULL,
    structure_id character varying(50) NOT NULL,
    stations_id character varying(50) NOT NULL,
    component_id character varying(50) NOT NULL,
    point character varying(256) NOT NULL,
    bbox character varying(256)
);


--
-- Name: t_bim_stations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_bim_stations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_bim_stations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_bim_stations_id_seq OWNED BY public.t_bim_stations.id;


--
-- Name: t_calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_calendar (
    id integer NOT NULL,
    org integer NOT NULL,
    type integer NOT NULL,
    calendar_time timestamp with time zone NOT NULL,
    calendar_content character varying(512),
    structure integer
);


--
-- Name: t_calendar_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_calendar_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_calendar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_calendar_id_seq OWNED BY public.t_calendar.id;


--
-- Name: t_calendar_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_calendar_type (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: t_calendar_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_calendar_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_calendar_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_calendar_type_id_seq OWNED BY public.t_calendar_type.id;


--
-- Name: t_component; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_component (
    id integer NOT NULL,
    component character varying(255)
);


--
-- Name: t_component_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_component_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_component_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_component_id_seq OWNED BY public.t_component.id;


--
-- Name: t_construction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_construction (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    address character varying(100),
    longitude numeric(20,14),
    latitude numeric(20,14),
    des character varying(100) NOT NULL,
    portrait character varying(200) NOT NULL,
    org_built integer NOT NULL,
    org_construct integer NOT NULL,
    org_owner integer NOT NULL,
    org_supervision integer NOT NULL,
    area integer,
    height integer,
    design_company character varying(100),
    construct_begin timestamp with time zone,
    construct_end timestamp with time zone,
    project_type integer DEFAULT 1 NOT NULL
);


--
-- Name: t_construction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_construction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_construction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_construction_id_seq OWNED BY public.t_construction.id;


--
-- Name: t_data_original; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_data_original (
    id bigint NOT NULL,
    iota_device_id uuid NOT NULL,
    original_data jsonb NOT NULL,
    collect_time timestamp with time zone NOT NULL,
    batch_no character varying(100) NOT NULL
);


--
-- Name: t_data_original_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_data_original_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_data_original_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_data_original_id_seq OWNED BY public.t_data_original.id;


--
-- Name: t_data_sensor_latest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_data_sensor_latest (
    id integer NOT NULL,
    sensor integer NOT NULL,
    latest_data jsonb NOT NULL,
    collect_time timestamp with time zone NOT NULL,
    violate_rational_times integer NOT NULL,
    state integer NOT NULL
);


--
-- Name: t_data_sensor_latest_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_data_sensor_latest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_data_sensor_latest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_data_sensor_latest_id_seq OWNED BY public.t_data_sensor_latest.id;


--
-- Name: t_debug_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_debug_history (
    do_user_id integer,
    do_time timestamp with time zone DEFAULT now(),
    package_size character varying(10),
    use_time integer,
    result integer,
    iota_thing_id uuid NOT NULL,
    dtu_id character varying(50) DEFAULT NULL::character varying,
    id integer NOT NULL,
    device_id character varying(50) NOT NULL,
    is_success boolean
);


--
-- Name: COLUMN t_debug_history.do_user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_debug_history.do_user_id IS '操作人id';


--
-- Name: COLUMN t_debug_history.do_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_debug_history.do_time IS '操作时间';


--
-- Name: COLUMN t_debug_history.package_size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_debug_history.package_size IS '数据包大小';


--
-- Name: COLUMN t_debug_history.use_time; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_debug_history.use_time IS '耗时';


--
-- Name: COLUMN t_debug_history.result; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_debug_history.result IS '结果';


--
-- Name: COLUMN t_debug_history.iota_thing_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_debug_history.iota_thing_id IS 'iotathingid';


--
-- Name: COLUMN t_debug_history.dtu_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_debug_history.dtu_id IS 'dtuid';


--
-- Name: COLUMN t_debug_history.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_debug_history.id IS 'id';


--
-- Name: COLUMN t_debug_history.device_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_debug_history.device_id IS '下发设备id';


--
-- Name: COLUMN t_debug_history.is_success; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_debug_history.is_success IS '是否成功';


--
-- Name: t_debug_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_debug_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_debug_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_debug_history_id_seq OWNED BY public.t_debug_history.id;


--
-- Name: t_department; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_department (
    id integer NOT NULL,
    org integer NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: t_department_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_department_id_seq OWNED BY public.t_department.id;


--
-- Name: t_department_structure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_department_structure (
    id integer NOT NULL,
    department integer NOT NULL,
    structure integer NOT NULL,
    role_id integer,
    user_id integer
);


--
-- Name: t_department_structure_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_department_structure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_department_structure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_department_structure_id_seq OWNED BY public.t_department_structure.id;


--
-- Name: t_device_sensor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_device_sensor (
    id integer NOT NULL,
    iota_device_id uuid NOT NULL,
    iota_device_serial integer DEFAULT 0 NOT NULL,
    sensor integer NOT NULL,
    params jsonb
);


--
-- Name: t_device_sensor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_device_sensor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_device_sensor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_device_sensor_id_seq OWNED BY public.t_device_sensor.id;


--
-- Name: t_dyna_glt_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_dyna_glt_config (
    id integer NOT NULL,
    scheme_id uuid NOT NULL,
    glt integer NOT NULL,
    cond jsonb,
    enable boolean
);


--
-- Name: t_dyna_glt_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_dyna_glt_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_dyna_glt_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_dyna_glt_config_id_seq OWNED BY public.t_dyna_glt_config.id;


--
-- Name: t_event_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_event_config (
    id integer NOT NULL,
    "structId" integer NOT NULL,
    "indexId" integer NOT NULL,
    weight integer NOT NULL
);


--
-- Name: COLUMN t_event_config."indexId"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_event_config."indexId" IS 't_type_event_index';


--
-- Name: COLUMN t_event_config.weight; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_event_config.weight IS '比重';


--
-- Name: t_event_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_event_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_event_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_event_config_id_seq OWNED BY public.t_event_config.id;


--
-- Name: t_factor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_factor (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    proto character varying(30) NOT NULL,
    org integer,
    item jsonb NOT NULL
);


--
-- Name: t_factor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_factor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_factor_id_seq OWNED BY public.t_factor.id;


--
-- Name: t_factor_proto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_factor_proto (
    code character varying(30) NOT NULL,
    name character varying(50)
);


--
-- Name: t_factor_proto_device; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_factor_proto_device (
    id integer NOT NULL,
    proto character varying(30) NOT NULL,
    iota_product_code uuid NOT NULL,
    formula integer,
    fields jsonb,
    multi boolean DEFAULT false,
    multi_formula integer,
    multi_fields jsonb,
    input_unitconvert jsonb
);


--
-- Name: t_factor_proto_device_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_factor_proto_device_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_factor_proto_device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_factor_proto_device_id_seq OWNED BY public.t_factor_proto_device.id;


--
-- Name: t_factor_proto_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_factor_proto_item (
    id integer NOT NULL,
    proto character varying(30) NOT NULL,
    name character varying(50) NOT NULL,
    field_name character varying(50) NOT NULL,
    "precision" integer
);


--
-- Name: t_factor_proto_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_factor_proto_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_factor_proto_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_factor_proto_item_id_seq OWNED BY public.t_factor_proto_item.id;


--
-- Name: t_factor_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_factor_template (
    id integer NOT NULL,
    structtype integer NOT NULL,
    name character varying(100) NOT NULL,
    org integer,
    publish boolean NOT NULL,
    description character varying(100)
);


--
-- Name: t_factor_template_factor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_factor_template_factor (
    template_id integer NOT NULL,
    factor integer NOT NULL,
    id integer NOT NULL
);


--
-- Name: t_factor_template_factor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_factor_template_factor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_factor_template_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_factor_template_factor_id_seq OWNED BY public.t_factor_template_factor.id;


--
-- Name: t_factor_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_factor_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_factor_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_factor_template_id_seq OWNED BY public.t_factor_template.id;


--
-- Name: t_filter_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_filter_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_filter_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_filter_config (
    id integer DEFAULT nextval('public.t_filter_config_id_seq'::regclass) NOT NULL,
    sensor integer DEFAULT nextval('public.t_filter_config_id_seq'::regclass),
    item integer,
    method integer,
    window_size integer NOT NULL,
    params jsonb,
    enable boolean DEFAULT true NOT NULL,
    updatetime timestamp with time zone NOT NULL
);


--
-- Name: t_filter_enviroment_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_filter_enviroment_config (
    id integer NOT NULL,
    project integer NOT NULL,
    params jsonb NOT NULL,
    receiver jsonb NOT NULL
);


--
-- Name: t_filter_enviroment_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_filter_enviroment_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_filter_enviroment_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_filter_enviroment_config_id_seq OWNED BY public.t_filter_enviroment_config.id;


--
-- Name: t_filter_method; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_filter_method (
    id integer NOT NULL,
    type integer NOT NULL,
    name character varying(50) NOT NULL,
    params jsonb
);


--
-- Name: t_filter_method_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_filter_method_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_filter_method_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_filter_method_id_seq OWNED BY public.t_filter_method.id;


--
-- Name: t_formula; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_formula (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    expression_shown character varying(255) NOT NULL,
    description character varying(100),
    params jsonb NOT NULL,
    ioparams jsonb,
    expression character varying(255),
    ioparams_ext jsonb,
    props jsonb
);


--
-- Name: t_formula_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_formula_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_formula_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_formula_id_seq OWNED BY public.t_formula.id;


--
-- Name: t_formula_params_ex; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_formula_params_ex (
    id integer NOT NULL,
    name character varying(255),
    params jsonb NOT NULL
);


--
-- Name: t_formula_params_ex_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_formula_params_ex_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_formula_params_ex_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_formula_params_ex_id_seq OWNED BY public.t_formula_params_ex.id;


--
-- Name: t_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_group (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    group_type character varying(50) NOT NULL,
    factor integer NOT NULL,
    structure integer NOT NULL,
    params jsonb DEFAULT '{}'::jsonb
);


--
-- Name: t_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_group_id_seq OWNED BY public.t_group.id;


--
-- Name: t_group_sensor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_group_sensor (
    id integer NOT NULL,
    group_id integer NOT NULL,
    sensor integer NOT NULL,
    params_value jsonb
);


--
-- Name: t_group_sensor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_group_sensor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_group_sensor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_group_sensor_id_seq OWNED BY public.t_group_sensor.id;


--
-- Name: t_group_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_group_type (
    type_code character varying(50) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    params jsonb NOT NULL,
    present boolean NOT NULL
);


--
-- Name: t_group_type_factor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_group_type_factor (
    id integer NOT NULL,
    group_type character varying(50) NOT NULL,
    proto character varying(30) NOT NULL
);


--
-- Name: t_group_type_factor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_group_type_factor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_group_type_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_group_type_factor_id_seq OWNED BY public.t_group_type_factor.id;


--
-- Name: t_institution; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_institution (
    id integer NOT NULL,
    institutionname character varying(50) NOT NULL,
    institutionrole integer NOT NULL,
    orgid integer,
    institution_corporation character varying(50),
    institution_corporation_contact character varying(50)
);


--
-- Name: t_institution_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_institution_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_institution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_institution_id_seq OWNED BY public.t_institution.id;


--
-- Name: t_item_unit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_item_unit (
    id integer NOT NULL,
    name character varying(50),
    item integer NOT NULL,
    if_default boolean,
    transform numeric(18,6)
);


--
-- Name: t_item_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_item_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_item_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_item_unit_id_seq OWNED BY public.t_item_unit.id;


--
-- Name: t_layout_model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_layout_model (
    id integer NOT NULL,
    layout integer NOT NULL,
    params jsonb NOT NULL,
    structure integer NOT NULL
);


--
-- Name: t_layout_model_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_layout_model_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_layout_model_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_layout_model_id_seq OWNED BY public.t_layout_model.id;


--
-- Name: t_layout_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_layout_type (
    id integer NOT NULL,
    name character varying(100)
);


--
-- Name: t_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_message (
    id integer NOT NULL,
    user_id integer NOT NULL,
    message_type integer NOT NULL,
    generate_time timestamp with time zone NOT NULL,
    content character varying(512),
    read_time timestamp with time zone,
    readed boolean DEFAULT false NOT NULL
);


--
-- Name: t_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_message_id_seq OWNED BY public.t_message.id;


--
-- Name: t_message_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_message_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: t_netdisk_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_netdisk_file (
    id integer NOT NULL,
    file_type integer NOT NULL,
    file_name character varying(100) NOT NULL,
    file_ext character varying(30),
    file_size integer NOT NULL,
    file_link character varying(512) NOT NULL,
    update_user integer NOT NULL,
    update_time timestamp with time zone,
    extra_info jsonb
);


--
-- Name: t_netdisk_file_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_netdisk_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_netdisk_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_netdisk_file_id_seq OWNED BY public.t_netdisk_file.id;


--
-- Name: t_organization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_organization (
    id integer NOT NULL,
    org_type integer NOT NULL,
    name character varying(100) NOT NULL,
    domain character varying(100),
    state integer NOT NULL,
    aptitude_file character varying(512),
    register_code character varying(50),
    logo character varying(512),
    scale character varying(100),
    region character varying(200),
    app_key character(40),
    app_secret character(40)
);


--
-- Name: t_organization_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_organization_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_organization_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_organization_id_seq OWNED BY public.t_organization.id;


--
-- Name: t_organization_project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_organization_project (
    id integer NOT NULL,
    org integer NOT NULL,
    project integer NOT NULL
);


--
-- Name: t_organization_project_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_organization_project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_organization_project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_organization_project_id_seq OWNED BY public.t_organization_project.id;


--
-- Name: t_phone_validate_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_phone_validate_code (
    id integer NOT NULL,
    phone character varying(20) NOT NULL,
    code character varying(6) NOT NULL,
    sig character varying(40) NOT NULL,
    expired timestamp with time zone NOT NULL
);


--
-- Name: t_phone_validate_code_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_phone_validate_code_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_phone_validate_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_phone_validate_code_id_seq OWNED BY public.t_phone_validate_code.id;


--
-- Name: t_project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_project (
    id integer NOT NULL,
    name character varying(50),
    logo character varying(256),
    theme character varying(256),
    url character varying(256),
    marked boolean,
    create_time timestamp with time zone NOT NULL,
    update_time timestamp with time zone,
    project_state integer NOT NULL,
    describe character varying(512),
    type integer DEFAULT 0 NOT NULL,
    extra jsonb,
    event_state boolean DEFAULT false
);


--
-- Name: t_project_approve; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_project_approve (
    id integer NOT NULL,
    project integer NOT NULL,
    approve_user integer NOT NULL,
    approve_time timestamp with time zone NOT NULL,
    project_state integer NOT NULL,
    approve_info character varying(2048)
);


--
-- Name: t_project_approve_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_project_approve_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_project_approve_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_project_approve_id_seq OWNED BY public.t_project_approve.id;


--
-- Name: t_project_construction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_project_construction (
    id integer NOT NULL,
    project integer NOT NULL,
    construction integer NOT NULL
);


--
-- Name: t_project_construction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_project_construction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_project_construction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_project_construction_id_seq OWNED BY public.t_project_construction.id;


--
-- Name: t_project_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_project_id_seq OWNED BY public.t_project.id;


--
-- Name: t_project_structure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_project_structure (
    id integer NOT NULL,
    project integer NOT NULL,
    structure integer NOT NULL
);


--
-- Name: t_project_structure_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_project_structure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_project_structure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_project_structure_id_seq OWNED BY public.t_project_structure.id;


--
-- Name: t_project_structuregroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_project_structuregroup (
    id integer NOT NULL,
    project integer NOT NULL,
    structuregroup integer NOT NULL
);


--
-- Name: t_project_structuregroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_project_structuregroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_project_structuregroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_project_structuregroup_id_seq OWNED BY public.t_project_structuregroup.id;


--
-- Name: t_project_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_project_type (
    id integer NOT NULL,
    type_name character varying(20) NOT NULL,
    description character varying(20) NOT NULL
);


--
-- Name: t_rational; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_rational (
    id integer NOT NULL,
    sensor integer,
    item integer,
    lower numeric(12,5),
    upper numeric(12,5),
    enabled boolean DEFAULT true NOT NULL
);


--
-- Name: t_rational_device; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_rational_device (
    id integer NOT NULL,
    iota_device_id uuid NOT NULL,
    item integer,
    lower numeric(12,5),
    upper numeric(12,5),
    enabled boolean DEFAULT true NOT NULL
);


--
-- Name: t_rational_filter; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_rational_filter (
    id integer NOT NULL,
    sensor integer NOT NULL,
    item integer NOT NULL,
    rationallower numeric(10,4) NOT NULL,
    rationalupper numeric(10,4) NOT NULL,
    enabled boolean NOT NULL
);


--
-- Name: t_rational_filter_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_rational_filter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_rational_filter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_rational_filter_id_seq OWNED BY public.t_rational_filter.id;


--
-- Name: t_recalc_product_formula; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_recalc_product_formula (
    id integer NOT NULL,
    iota_product_code uuid NOT NULL,
    iota_product_formula uuid,
    formula integer NOT NULL,
    fields jsonb NOT NULL
);


--
-- Name: t_relay_proxy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_relay_proxy (
    name character varying(255) NOT NULL,
    in_mode character varying(20) NOT NULL,
    out_mode character varying(20) NOT NULL,
    in_config jsonb NOT NULL,
    out_config jsonb NOT NULL
);


--
-- Name: t_report_generate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_report_generate (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    structure integer NOT NULL,
    report_type integer NOT NULL,
    template_cfg jsonb NOT NULL,
    "interval" character varying(50) NOT NULL,
    confirm boolean NOT NULL,
    enabled boolean NOT NULL,
    manual_monitoring boolean DEFAULT false,
    agg_config jsonb,
    doc_type character varying(10) DEFAULT 'excel'::character varying
);


--
-- Name: t_report_generate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_report_generate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_report_generate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_report_generate_id_seq OWNED BY public.t_report_generate.id;


--
-- Name: t_report_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_report_template (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    handler character varying(50) NOT NULL,
    file_link character varying(512) NOT NULL,
    factor_proto character varying(30),
    structure integer,
    report_type integer NOT NULL,
    manual boolean DEFAULT false,
    cells jsonb,
    struct_type integer[] DEFAULT '{}'::integer[] NOT NULL,
    structs integer[] DEFAULT '{}'::integer[],
    params jsonb
);


--
-- Name: t_report_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_report_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_report_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_report_template_id_seq OWNED BY public.t_report_template.id;


--
-- Name: t_resource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_resource (
    code character varying(50) NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    type integer,
    parent_resource character varying(50)
);


--
-- Name: t_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_role (
    id integer NOT NULL,
    dep integer NOT NULL,
    name character varying(50) NOT NULL,
    portal character varying(2) DEFAULT 'AC'::character varying NOT NULL,
    description character varying(100),
    type boolean DEFAULT false NOT NULL
);


--
-- Name: COLUMN t_role.type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_role.type IS '职位类型：true为管理员，false为非管理员职位';


--
-- Name: t_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_role_id_seq OWNED BY public.t_role.id;


--
-- Name: t_role_resource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_role_resource (
    id integer NOT NULL,
    role integer NOT NULL,
    resource character varying(50) NOT NULL
);


--
-- Name: t_role_resource_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_role_resource_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_role_resource_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_role_resource_id_seq OWNED BY public.t_role_resource.id;


--
-- Name: t_sensor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_sensor (
    id integer NOT NULL,
    structure integer NOT NULL,
    name character varying(50) NOT NULL,
    factor integer NOT NULL,
    portrait character varying(512),
    labels character varying(100)[],
    manual_data boolean DEFAULT false NOT NULL,
    extras jsonb
);


--
-- Name: t_sensor_factor_threshold; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_sensor_factor_threshold (
    id integer NOT NULL,
    batch_no character varying(100),
    sensor integer,
    item integer,
    level integer,
    lower numeric(12,5),
    upper numeric(12,5),
    start_hour integer,
    end_hour integer,
    description character varying(100)
);


--
-- Name: t_sensor_factor_threshold_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_sensor_factor_threshold_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_sensor_factor_threshold_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_sensor_factor_threshold_id_seq OWNED BY public.t_sensor_factor_threshold.id;


--
-- Name: t_sensor_filter_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_sensor_filter_config (
    id integer NOT NULL,
    sensor integer NOT NULL,
    item integer NOT NULL,
    method integer NOT NULL,
    params_value jsonb NOT NULL,
    enabled boolean NOT NULL,
    update_time timestamp with time zone
);


--
-- Name: t_sensor_filter_config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_sensor_filter_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_sensor_filter_config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_sensor_filter_config_id_seq OWNED BY public.t_sensor_filter_config.id;


--
-- Name: t_sensor_formula; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_sensor_formula (
    id integer NOT NULL,
    sensor integer NOT NULL,
    formula integer NOT NULL,
    params_value jsonb NOT NULL
);


--
-- Name: t_sensor_formula_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_sensor_formula_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_sensor_formula_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_sensor_formula_id_seq OWNED BY public.t_sensor_formula.id;


--
-- Name: t_sensor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_sensor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_sensor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_sensor_id_seq OWNED BY public.t_sensor.id;


--
-- Name: t_sensor_layout; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_sensor_layout (
    id integer NOT NULL,
    sensor integer,
    model integer NOT NULL,
    "position" jsonb,
    modal_layout integer
);


--
-- Name: t_sensor_layout_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_sensor_layout_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_sensor_layout_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_sensor_layout_id_seq OWNED BY public.t_sensor_layout.id;


--
-- Name: t_structure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_structure (
    id integer NOT NULL,
    iota_thing_id uuid NOT NULL,
    structure_type integer NOT NULL,
    name character varying(50),
    description character varying(100),
    region_path character varying(100),
    longitude numeric(20,14),
    latitude numeric(20,14),
    address character varying(100),
    portrait character varying(512),
    extra_info jsonb,
    org integer NOT NULL,
    create_time timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: t_structure_component; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_structure_component (
    id integer NOT NULL,
    structtypeid integer NOT NULL,
    componentid integer NOT NULL
);


--
-- Name: t_structure_component_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_structure_component_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_structure_component_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_structure_component_id_seq OWNED BY public.t_structure_component.id;


--
-- Name: t_structure_factor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_structure_factor (
    id integer NOT NULL,
    structure integer NOT NULL,
    factor integer NOT NULL,
    alias_name character varying(50)
);


--
-- Name: t_structure_factor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_structure_factor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_structure_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_structure_factor_id_seq OWNED BY public.t_structure_factor.id;


--
-- Name: t_structure_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_structure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_structure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_structure_id_seq OWNED BY public.t_structure.id;


--
-- Name: t_structure_site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_structure_site (
    id integer NOT NULL,
    structid integer NOT NULL,
    siteid integer NOT NULL
);


--
-- Name: t_structure_site_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_structure_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_structure_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_structure_site_id_seq OWNED BY public.t_structure_site.id;


--
-- Name: t_structure_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_structure_type (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(100),
    parent_type integer NOT NULL,
    portrait character varying(512)
);


--
-- Name: t_structure_type_factor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_structure_type_factor (
    id integer NOT NULL,
    structure_type integer NOT NULL,
    factor integer NOT NULL
);


--
-- Name: t_structure_type_factor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_structure_type_factor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_structure_type_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_structure_type_factor_id_seq OWNED BY public.t_structure_type_factor.id;


--
-- Name: t_structure_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_structure_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_structure_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_structure_type_id_seq OWNED BY public.t_structure_type.id;


--
-- Name: t_structuregroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_structuregroup (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    extras jsonb
);


--
-- Name: t_structuregroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_structuregroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_structuregroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_structuregroup_id_seq OWNED BY public.t_structuregroup.id;


--
-- Name: t_structuregroup_structure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_structuregroup_structure (
    id integer NOT NULL,
    structuregroup integer NOT NULL,
    structure integer NOT NULL
);


--
-- Name: t_structuregroup_structure_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_structuregroup_structure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_structuregroup_structure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_structuregroup_structure_id_seq OWNED BY public.t_structuregroup_structure.id;


--
-- Name: t_task_recalculate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_task_recalculate (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    emit_user integer NOT NULL,
    station_id integer NOT NULL,
    data_begin_time timestamp with time zone NOT NULL,
    data_end_time timestamp with time zone NOT NULL,
    task_begin_time timestamp with time zone,
    task_end_time timestamp with time zone,
    task_state integer NOT NULL,
    task_result jsonb,
    msg_id uuid NOT NULL
);


--
-- Name: t_task_recalculate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_task_recalculate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_task_recalculate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_task_recalculate_id_seq OWNED BY public.t_task_recalculate.id;


--
-- Name: t_type_alarm_source; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_type_alarm_source (
    id integer NOT NULL,
    name character varying(50),
    description character varying(100)
);


--
-- Name: t_type_alarm_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_type_alarm_state (
    id integer NOT NULL,
    name character varying(50),
    description character varying(100)
);


--
-- Name: t_type_event_index; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_type_event_index (
    id integer NOT NULL,
    name character varying(10) NOT NULL,
    description character varying(20)
);


--
-- Name: t_type_event_index_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_type_event_index_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_type_event_index_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_type_event_index_id_seq OWNED BY public.t_type_event_index.id;


--
-- Name: t_type_file_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_type_file_type (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: t_type_institution_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_type_institution_role (
    id integer NOT NULL,
    name character varying(50),
    description character varying(100)
);


--
-- Name: t_type_org_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_type_org_type (
    id integer NOT NULL,
    name character varying(50),
    description character varying(100)
);


--
-- Name: t_type_project_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_type_project_state (
    id integer NOT NULL,
    name character varying(50),
    description character varying(100)
);


--
-- Name: t_type_report_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_type_report_state (
    id integer NOT NULL,
    name character varying(50),
    description character varying(100)
);


--
-- Name: t_type_report_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_type_report_type (
    id integer NOT NULL,
    name character varying(50),
    description character varying(100)
);


--
-- Name: t_type_role_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_type_role_type (
    code character varying(2) NOT NULL,
    description character varying(20) NOT NULL
);


--
-- Name: t_units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_units (
    name character varying(20) NOT NULL,
    dimension character varying(20),
    description character varying(255),
    coef numeric(32,16),
    base boolean DEFAULT false NOT NULL,
    alternative character varying(255)
);


--
-- Name: t_upload_comm_http; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_upload_comm_http (
    id integer NOT NULL,
    content json NOT NULL,
    enable boolean DEFAULT true NOT NULL,
    description character varying(255)
);


--
-- Name: TABLE t_upload_comm_http; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.t_upload_comm_http IS 'ET数据上报消费者(upload)普通HTTP上报类配置表';


--
-- Name: t_upload_comm_http_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_upload_comm_http_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_upload_comm_http_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_upload_comm_http_id_seq OWNED BY public.t_upload_comm_http.id;


--
-- Name: t_upload_params; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_upload_params (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    params jsonb,
    description character varying(255)
);


--
-- Name: t_upload_params_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_upload_params_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_upload_params_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_upload_params_id_seq OWNED BY public.t_upload_params.id;


--
-- Name: t_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_user (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    name_present character varying(50),
    password character varying(256),
    phone character varying(50),
    email character varying(50),
    avator character varying(512),
    org integer NOT NULL,
    role integer NOT NULL,
    register_time timestamp with time zone,
    mail_notice boolean DEFAULT false NOT NULL,
    sms_notice boolean DEFAULT false NOT NULL,
    no_disturb boolean DEFAULT false NOT NULL,
    enabled boolean NOT NULL,
    open_id character varying(50),
    nick_name character varying(50),
    wx_notice boolean DEFAULT false NOT NULL,
    union_id character varying(50),
    institution_role character varying(50) DEFAULT NULL::character varying
);


--
-- Name: t_user_favorite; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_user_favorite (
    id integer NOT NULL,
    user_id integer NOT NULL,
    file_type integer NOT NULL,
    path integer NOT NULL
);


--
-- Name: t_user_favorite_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_user_favorite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_user_favorite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_user_favorite_id_seq OWNED BY public.t_user_favorite.id;


--
-- Name: t_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_user_id_seq OWNED BY public.t_user.id;


--
-- Name: t_user_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_user_token (
    token uuid NOT NULL,
    user_info jsonb NOT NULL,
    expired timestamp with time zone NOT NULL
);


--
-- Name: t_vehicle_overload; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_vehicle_overload (
    id integer NOT NULL,
    axis_num character varying(100) NOT NULL,
    overload_standard numeric(18,6) NOT NULL,
    over_heigth numeric(18,6) NOT NULL,
    over_len numeric(18,6) NOT NULL,
    overwidth numeric(18,6) NOT NULL
);


--
-- Name: t_vehicle_overload_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_vehicle_overload_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_vehicle_overload_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_vehicle_overload_id_seq OWNED BY public.t_vehicle_overload.id;


--
-- Name: t_video_ipc; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_video_ipc (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    channel_no integer,
    push_server integer,
    nvr integer,
    structure integer NOT NULL,
    has_ptz boolean DEFAULT false NOT NULL,
    longitude numeric(20,14),
    latitude numeric(20,14),
    type character varying(10) DEFAULT 'original'::character varying NOT NULL,
    uid character varying(255),
    username character varying(255),
    password character varying(255),
    serial_no character varying(50),
    rtmp_address character varying(255),
    hls_address character varying(255)
);


--
-- Name: t_video_ipc_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_video_ipc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_video_ipc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_video_ipc_id_seq OWNED BY public.t_video_ipc.id;


--
-- Name: t_video_ipc_station; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_video_ipc_station (
    id integer NOT NULL,
    ipc integer NOT NULL,
    station integer NOT NULL
);


--
-- Name: t_video_ipc_station_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_video_ipc_station_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_video_ipc_station_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_video_ipc_station_id_seq OWNED BY public.t_video_ipc_station.id;


--
-- Name: t_video_nvr; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_video_nvr (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    ip character varying(50) NOT NULL,
    port integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(50) NOT NULL,
    channels_total integer NOT NULL,
    vendor integer NOT NULL,
    structure integer NOT NULL
);


--
-- Name: t_video_nvr_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_video_nvr_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_video_nvr_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_video_nvr_id_seq OWNED BY public.t_video_nvr.id;


--
-- Name: t_video_nvr_vendor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_video_nvr_vendor (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    enabled boolean DEFAULT false NOT NULL
);


--
-- Name: t_video_nvr_vendor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_video_nvr_vendor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_video_nvr_vendor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_video_nvr_vendor_id_seq OWNED BY public.t_video_nvr_vendor.id;


--
-- Name: t_video_push_server; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_video_push_server (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    ip character varying(15) NOT NULL,
    port integer NOT NULL
);


--
-- Name: t_video_push_server_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_video_push_server_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_video_push_server_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_video_push_server_id_seq OWNED BY public.t_video_push_server.id;


--
-- Name: t_weather_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_weather_history (
    id integer NOT NULL,
    "structId" integer NOT NULL,
    weather character varying(20) NOT NULL,
    date date NOT NULL
);


--
-- Name: t_weather_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_weather_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_weather_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_weather_history_id_seq OWNED BY public.t_weather_history.id;


--
-- Name: t_workflow_business; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_workflow_business (
    id integer NOT NULL,
    procdef_key character varying(100) NOT NULL,
    procdef_id character varying(100) NOT NULL,
    procinst_id integer,
    created_by character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: COLUMN t_workflow_business.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_workflow_business.created_by IS '创建人';


--
-- Name: COLUMN t_workflow_business.created_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.t_workflow_business.created_at IS '创建时间';


--
-- Name: t_workflow_business_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_workflow_business_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_workflow_business_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_workflow_business_id_seq OWNED BY public.t_workflow_business.id;


--
-- Name: t_workflow_form_proto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_workflow_form_proto (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    form_metas jsonb NOT NULL,
    procdef_key character varying(100) NOT NULL,
    procdef_id character varying(100) NOT NULL,
    actdef_key character varying(100) NOT NULL,
    belongto_startevent boolean DEFAULT false NOT NULL
);


--
-- Name: t_workflow_form_proto_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_workflow_form_proto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_workflow_form_proto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_workflow_form_proto_id_seq OWNED BY public.t_workflow_form_proto.id;


--
-- Name: t_wx_bind_result; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_wx_bind_result (
    id integer NOT NULL,
    user_id integer NOT NULL,
    open_id character varying(100) NOT NULL,
    union_id character varying(100) NOT NULL,
    result boolean NOT NULL,
    error character varying(255),
    "time" timestamp with time zone NOT NULL
);


--
-- Name: t_wx_bind_result_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.t_wx_bind_result_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: t_wx_bind_result_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.t_wx_bind_result_id_seq OWNED BY public.t_wx_bind_result.id;


--
-- Name: t_wx_subscribe; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.t_wx_subscribe (
    open_id character varying(50) NOT NULL,
    union_id character varying(50) NOT NULL
);


--
-- Name: tmp_role_resource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tmp_role_resource (
    role integer,
    resource character varying(50)
);


--
-- Name: t_abn_report_params id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_abn_report_params ALTER COLUMN id SET DEFAULT nextval('public.t_abn_report_params_id_seq'::regclass);


--
-- Name: t_abn_report_push_strategy id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_abn_report_push_strategy ALTER COLUMN id SET DEFAULT nextval('public.t_abn_report_push_strategy_id_seq'::regclass);


--
-- Name: t_agg_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_agg_config ALTER COLUMN id SET DEFAULT nextval('public.t_agg_config_id_seq'::regclass);


--
-- Name: t_agg_threshold_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_agg_threshold_config ALTER COLUMN id SET DEFAULT nextval('public.t_agg_threshold_config_id_seq'::regclass);


--
-- Name: t_alarm id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm ALTER COLUMN id SET DEFAULT nextval('public.t_alarm_id_seq'::regclass);


--
-- Name: t_alarm_category id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_category ALTER COLUMN id SET DEFAULT nextval('public.t_alarm_category_id_seq'::regclass);


--
-- Name: t_alarm_code id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_code ALTER COLUMN id SET DEFAULT nextval('public.t_alarm_code_id_seq'::regclass);


--
-- Name: t_alarm_custom_message id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_custom_message ALTER COLUMN id SET DEFAULT nextval('public.t_alarm_custom_message_id_seq'::regclass);


--
-- Name: t_alarm_deal id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_deal ALTER COLUMN id SET DEFAULT nextval('public.t_alarm_deal_id_seq'::regclass);


--
-- Name: t_alarm_detail id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_detail ALTER COLUMN id SET DEFAULT nextval('public.t_alarm_detail_id_seq'::regclass);


--
-- Name: t_alarm_policy id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_policy ALTER COLUMN id SET DEFAULT nextval('public.t_alarm_policy_id_seq'::regclass);


--
-- Name: t_alarm_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_type ALTER COLUMN id SET DEFAULT nextval('public.t_alarm_type_id_seq'::regclass);


--
-- Name: t_api_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_api_log ALTER COLUMN id SET DEFAULT nextval('public.t_api_log_id_seq'::regclass);


--
-- Name: t_app_message id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_app_message ALTER COLUMN id SET DEFAULT nextval('public.t_app_message_id_seq'::regclass);


--
-- Name: t_apply id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_apply ALTER COLUMN id SET DEFAULT nextval('public.t_apply_id_seq'::regclass);


--
-- Name: t_averagerainfall id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_averagerainfall ALTER COLUMN id SET DEFAULT nextval('public.t_averagerainfall_id_seq'::regclass);


--
-- Name: t_bim_rendering_path id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_bim_rendering_path ALTER COLUMN id SET DEFAULT nextval('public.t_bim_rendering_path_id_seq'::regclass);


--
-- Name: t_bim_stations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_bim_stations ALTER COLUMN id SET DEFAULT nextval('public.t_bim_stations_id_seq'::regclass);


--
-- Name: t_calendar id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_calendar ALTER COLUMN id SET DEFAULT nextval('public.t_calendar_id_seq'::regclass);


--
-- Name: t_calendar_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_calendar_type ALTER COLUMN id SET DEFAULT nextval('public.t_calendar_type_id_seq'::regclass);


--
-- Name: t_component id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_component ALTER COLUMN id SET DEFAULT nextval('public.t_component_id_seq'::regclass);


--
-- Name: t_construction id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_construction ALTER COLUMN id SET DEFAULT nextval('public.t_construction_id_seq'::regclass);


--
-- Name: t_data_original id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_data_original ALTER COLUMN id SET DEFAULT nextval('public.t_data_original_id_seq'::regclass);


--
-- Name: t_data_sensor_latest id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_data_sensor_latest ALTER COLUMN id SET DEFAULT nextval('public.t_data_sensor_latest_id_seq'::regclass);


--
-- Name: t_debug_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_debug_history ALTER COLUMN id SET DEFAULT nextval('public.t_debug_history_id_seq'::regclass);


--
-- Name: t_department id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_department ALTER COLUMN id SET DEFAULT nextval('public.t_department_id_seq'::regclass);


--
-- Name: t_department_structure id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_department_structure ALTER COLUMN id SET DEFAULT nextval('public.t_department_structure_id_seq'::regclass);


--
-- Name: t_device_sensor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_device_sensor ALTER COLUMN id SET DEFAULT nextval('public.t_device_sensor_id_seq'::regclass);


--
-- Name: t_dyna_glt_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_dyna_glt_config ALTER COLUMN id SET DEFAULT nextval('public.t_dyna_glt_config_id_seq'::regclass);


--
-- Name: t_event_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_event_config ALTER COLUMN id SET DEFAULT nextval('public.t_event_config_id_seq'::regclass);


--
-- Name: t_factor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor ALTER COLUMN id SET DEFAULT nextval('public.t_factor_id_seq'::regclass);


--
-- Name: t_factor_proto_device id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_proto_device ALTER COLUMN id SET DEFAULT nextval('public.t_factor_proto_device_id_seq'::regclass);


--
-- Name: t_factor_proto_item id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_proto_item ALTER COLUMN id SET DEFAULT nextval('public.t_factor_proto_item_id_seq'::regclass);


--
-- Name: t_factor_template id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_template ALTER COLUMN id SET DEFAULT nextval('public.t_factor_template_id_seq'::regclass);


--
-- Name: t_factor_template_factor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_template_factor ALTER COLUMN id SET DEFAULT nextval('public.t_factor_template_factor_id_seq'::regclass);


--
-- Name: t_filter_enviroment_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_filter_enviroment_config ALTER COLUMN id SET DEFAULT nextval('public.t_filter_enviroment_config_id_seq'::regclass);


--
-- Name: t_filter_method id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_filter_method ALTER COLUMN id SET DEFAULT nextval('public.t_filter_method_id_seq'::regclass);


--
-- Name: t_formula id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_formula ALTER COLUMN id SET DEFAULT nextval('public.t_formula_id_seq'::regclass);


--
-- Name: t_formula_params_ex id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_formula_params_ex ALTER COLUMN id SET DEFAULT nextval('public.t_formula_params_ex_id_seq'::regclass);


--
-- Name: t_group id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group ALTER COLUMN id SET DEFAULT nextval('public.t_group_id_seq'::regclass);


--
-- Name: t_group_sensor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group_sensor ALTER COLUMN id SET DEFAULT nextval('public.t_group_sensor_id_seq'::regclass);


--
-- Name: t_group_type_factor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group_type_factor ALTER COLUMN id SET DEFAULT nextval('public.t_group_type_factor_id_seq'::regclass);


--
-- Name: t_institution id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_institution ALTER COLUMN id SET DEFAULT nextval('public.t_institution_id_seq'::regclass);


--
-- Name: t_item_unit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_item_unit ALTER COLUMN id SET DEFAULT nextval('public.t_item_unit_id_seq'::regclass);


--
-- Name: t_layout_model id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_layout_model ALTER COLUMN id SET DEFAULT nextval('public.t_layout_model_id_seq'::regclass);


--
-- Name: t_message id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_message ALTER COLUMN id SET DEFAULT nextval('public.t_message_id_seq'::regclass);


--
-- Name: t_netdisk_file id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_netdisk_file ALTER COLUMN id SET DEFAULT nextval('public.t_netdisk_file_id_seq'::regclass);


--
-- Name: t_organization id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_organization ALTER COLUMN id SET DEFAULT nextval('public.t_organization_id_seq'::regclass);


--
-- Name: t_organization_project id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_organization_project ALTER COLUMN id SET DEFAULT nextval('public.t_organization_project_id_seq'::regclass);


--
-- Name: t_phone_validate_code id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_phone_validate_code ALTER COLUMN id SET DEFAULT nextval('public.t_phone_validate_code_id_seq'::regclass);


--
-- Name: t_project id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project ALTER COLUMN id SET DEFAULT nextval('public.t_project_id_seq'::regclass);


--
-- Name: t_project_approve id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_approve ALTER COLUMN id SET DEFAULT nextval('public.t_project_approve_id_seq'::regclass);


--
-- Name: t_project_construction id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_construction ALTER COLUMN id SET DEFAULT nextval('public.t_project_construction_id_seq'::regclass);


--
-- Name: t_project_structure id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_structure ALTER COLUMN id SET DEFAULT nextval('public.t_project_structure_id_seq'::regclass);


--
-- Name: t_project_structuregroup id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_structuregroup ALTER COLUMN id SET DEFAULT nextval('public.t_project_structuregroup_id_seq'::regclass);


--
-- Name: t_rational_filter id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_rational_filter ALTER COLUMN id SET DEFAULT nextval('public.t_rational_filter_id_seq'::regclass);


--
-- Name: t_report_generate id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_report_generate ALTER COLUMN id SET DEFAULT nextval('public.t_report_generate_id_seq'::regclass);


--
-- Name: t_report_template id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_report_template ALTER COLUMN id SET DEFAULT nextval('public.t_report_template_id_seq'::regclass);


--
-- Name: t_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_role ALTER COLUMN id SET DEFAULT nextval('public.t_role_id_seq'::regclass);


--
-- Name: t_role_resource id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_role_resource ALTER COLUMN id SET DEFAULT nextval('public.t_role_resource_id_seq'::regclass);


--
-- Name: t_sensor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor ALTER COLUMN id SET DEFAULT nextval('public.t_sensor_id_seq'::regclass);


--
-- Name: t_sensor_factor_threshold id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_factor_threshold ALTER COLUMN id SET DEFAULT nextval('public.t_sensor_factor_threshold_id_seq'::regclass);


--
-- Name: t_sensor_filter_config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_filter_config ALTER COLUMN id SET DEFAULT nextval('public.t_sensor_filter_config_id_seq'::regclass);


--
-- Name: t_sensor_formula id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_formula ALTER COLUMN id SET DEFAULT nextval('public.t_sensor_formula_id_seq'::regclass);


--
-- Name: t_sensor_layout id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_layout ALTER COLUMN id SET DEFAULT nextval('public.t_sensor_layout_id_seq'::regclass);


--
-- Name: t_structure id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure ALTER COLUMN id SET DEFAULT nextval('public.t_structure_id_seq'::regclass);


--
-- Name: t_structure_component id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_component ALTER COLUMN id SET DEFAULT nextval('public.t_structure_component_id_seq'::regclass);


--
-- Name: t_structure_factor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_factor ALTER COLUMN id SET DEFAULT nextval('public.t_structure_factor_id_seq'::regclass);


--
-- Name: t_structure_site id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_site ALTER COLUMN id SET DEFAULT nextval('public.t_structure_site_id_seq'::regclass);


--
-- Name: t_structure_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_type ALTER COLUMN id SET DEFAULT nextval('public.t_structure_type_id_seq'::regclass);


--
-- Name: t_structure_type_factor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_type_factor ALTER COLUMN id SET DEFAULT nextval('public.t_structure_type_factor_id_seq'::regclass);


--
-- Name: t_structuregroup id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structuregroup ALTER COLUMN id SET DEFAULT nextval('public.t_structuregroup_id_seq'::regclass);


--
-- Name: t_structuregroup_structure id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structuregroup_structure ALTER COLUMN id SET DEFAULT nextval('public.t_structuregroup_structure_id_seq'::regclass);


--
-- Name: t_task_recalculate id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_task_recalculate ALTER COLUMN id SET DEFAULT nextval('public.t_task_recalculate_id_seq'::regclass);


--
-- Name: t_type_event_index id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_event_index ALTER COLUMN id SET DEFAULT nextval('public.t_type_event_index_id_seq'::regclass);


--
-- Name: t_upload_comm_http id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_upload_comm_http ALTER COLUMN id SET DEFAULT nextval('public.t_upload_comm_http_id_seq'::regclass);


--
-- Name: t_upload_params id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_upload_params ALTER COLUMN id SET DEFAULT nextval('public.t_upload_params_id_seq'::regclass);


--
-- Name: t_user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_user ALTER COLUMN id SET DEFAULT nextval('public.t_user_id_seq'::regclass);


--
-- Name: t_user_favorite id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_user_favorite ALTER COLUMN id SET DEFAULT nextval('public.t_user_favorite_id_seq'::regclass);


--
-- Name: t_vehicle_overload id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_vehicle_overload ALTER COLUMN id SET DEFAULT nextval('public.t_vehicle_overload_id_seq'::regclass);


--
-- Name: t_video_ipc id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_ipc ALTER COLUMN id SET DEFAULT nextval('public.t_video_ipc_id_seq'::regclass);


--
-- Name: t_video_ipc_station id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_ipc_station ALTER COLUMN id SET DEFAULT nextval('public.t_video_ipc_station_id_seq'::regclass);


--
-- Name: t_video_nvr id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_nvr ALTER COLUMN id SET DEFAULT nextval('public.t_video_nvr_id_seq'::regclass);


--
-- Name: t_video_nvr_vendor id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_nvr_vendor ALTER COLUMN id SET DEFAULT nextval('public.t_video_nvr_vendor_id_seq'::regclass);


--
-- Name: t_video_push_server id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_push_server ALTER COLUMN id SET DEFAULT nextval('public.t_video_push_server_id_seq'::regclass);


--
-- Name: t_weather_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_weather_history ALTER COLUMN id SET DEFAULT nextval('public.t_weather_history_id_seq'::regclass);


--
-- Name: t_workflow_business id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_workflow_business ALTER COLUMN id SET DEFAULT nextval('public.t_workflow_business_id_seq'::regclass);


--
-- Name: t_workflow_form_proto id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_workflow_form_proto ALTER COLUMN id SET DEFAULT nextval('public.t_workflow_form_proto_id_seq'::regclass);


--
-- Name: t_wx_bind_result id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_wx_bind_result ALTER COLUMN id SET DEFAULT nextval('public.t_wx_bind_result_id_seq'::regclass);


--
-- Name: t_abn_report_params t_abn_report_params_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_abn_report_params
    ADD CONSTRAINT t_abn_report_params_id_pk PRIMARY KEY (id);


--
-- Name: t_abn_report_push_strategy t_abn_report_push_strategy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_abn_report_push_strategy
    ADD CONSTRAINT t_abn_report_push_strategy_pkey PRIMARY KEY (id);


--
-- Name: t_abn_type t_abn_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_abn_type
    ADD CONSTRAINT t_abn_type_pkey PRIMARY KEY (id);


--
-- Name: t_agg_config t_agg_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_agg_config
    ADD CONSTRAINT t_agg_config_pkey PRIMARY KEY (id);


--
-- Name: t_agg_threshold_config t_agg_threshold_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_agg_threshold_config
    ADD CONSTRAINT t_agg_threshold_config_pkey PRIMARY KEY (id);


--
-- Name: t_agg_type t_agg_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_agg_type
    ADD CONSTRAINT t_agg_type_pkey PRIMARY KEY (id);


--
-- Name: t_alarm_category t_alarm_category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_category
    ADD CONSTRAINT t_alarm_category_pkey PRIMARY KEY (id);


--
-- Name: t_alarm_code t_alarm_code_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_code
    ADD CONSTRAINT t_alarm_code_pkey PRIMARY KEY (id);


--
-- Name: t_alarm_custom_message t_alarm_custom_message_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_custom_message
    ADD CONSTRAINT t_alarm_custom_message_pk PRIMARY KEY (id);


--
-- Name: t_alarm_deal t_alarm_deal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_deal
    ADD CONSTRAINT t_alarm_deal_pkey PRIMARY KEY (id);


--
-- Name: t_alarm_detail t_alarm_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_detail
    ADD CONSTRAINT t_alarm_detail_pkey PRIMARY KEY (id);


--
-- Name: t_alarm t_alarm_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm
    ADD CONSTRAINT t_alarm_pkey PRIMARY KEY (id);


--
-- Name: t_alarm_policy t_alarm_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_policy
    ADD CONSTRAINT t_alarm_policy_pkey PRIMARY KEY (id);


--
-- Name: t_alarm_type t_alarm_type_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_type
    ADD CONSTRAINT t_alarm_type_code_key UNIQUE (code);


--
-- Name: t_alarm_type t_alarm_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_type
    ADD CONSTRAINT t_alarm_type_pkey PRIMARY KEY (id);


--
-- Name: t_api_log t_api_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_api_log
    ADD CONSTRAINT t_api_log_pkey PRIMARY KEY (id);


--
-- Name: t_app_message t_app_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_app_message
    ADD CONSTRAINT t_app_message_pkey PRIMARY KEY (id);


--
-- Name: t_apply t_apply_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_apply
    ADD CONSTRAINT t_apply_pkey PRIMARY KEY (id);


--
-- Name: t_averagerainfall t_averagerainfall_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_averagerainfall
    ADD CONSTRAINT t_averagerainfall_pkey PRIMARY KEY (id);


--
-- Name: t_bim_rendering_path t_bim_rendering_path_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_bim_rendering_path
    ADD CONSTRAINT t_bim_rendering_path_pkey PRIMARY KEY (id);


--
-- Name: t_bim_stations t_bim_stations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_bim_stations
    ADD CONSTRAINT t_bim_stations_pkey PRIMARY KEY (id);


--
-- Name: t_calendar t_calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_calendar
    ADD CONSTRAINT t_calendar_pkey PRIMARY KEY (id);


--
-- Name: t_calendar_type t_calendar_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_calendar_type
    ADD CONSTRAINT t_calendar_type_pkey PRIMARY KEY (id);


--
-- Name: t_component t_component_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_component
    ADD CONSTRAINT t_component_pkey PRIMARY KEY (id);


--
-- Name: t_construction t_construction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_construction
    ADD CONSTRAINT t_construction_pkey PRIMARY KEY (id);


--
-- Name: t_data_original t_data_original_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_data_original
    ADD CONSTRAINT t_data_original_pkey PRIMARY KEY (id);


--
-- Name: t_data_sensor_latest t_data_sensor_latest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_data_sensor_latest
    ADD CONSTRAINT t_data_sensor_latest_pkey PRIMARY KEY (id);


--
-- Name: t_data_sensor_latest t_data_sensor_latest_sensor_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_data_sensor_latest
    ADD CONSTRAINT t_data_sensor_latest_sensor_key UNIQUE (sensor);


--
-- Name: t_debug_history t_debug_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_debug_history
    ADD CONSTRAINT t_debug_history_pkey PRIMARY KEY (id);


--
-- Name: t_department t_department_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_department
    ADD CONSTRAINT t_department_pkey PRIMARY KEY (id);


--
-- Name: t_department_structure t_department_structure_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_department_structure
    ADD CONSTRAINT t_department_structure_pkey PRIMARY KEY (id);


--
-- Name: t_device_sensor t_device_sensor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_device_sensor
    ADD CONSTRAINT t_device_sensor_pkey PRIMARY KEY (id);


--
-- Name: t_dyna_glt_config t_dyna_glt_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_dyna_glt_config
    ADD CONSTRAINT t_dyna_glt_config_pkey PRIMARY KEY (id);


--
-- Name: t_event_config t_event_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_event_config
    ADD CONSTRAINT t_event_config_pkey PRIMARY KEY (id);


--
-- Name: t_factor t_factor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor
    ADD CONSTRAINT t_factor_pkey PRIMARY KEY (id);


--
-- Name: t_factor_proto_device t_factor_proto_device_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_proto_device
    ADD CONSTRAINT t_factor_proto_device_pkey PRIMARY KEY (id);


--
-- Name: t_factor_proto_item t_factor_proto_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_proto_item
    ADD CONSTRAINT t_factor_proto_item_pkey PRIMARY KEY (id);


--
-- Name: t_factor_proto t_factor_proto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_proto
    ADD CONSTRAINT t_factor_proto_pkey PRIMARY KEY (code);


--
-- Name: t_factor_template_factor t_factor_template_factor_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_template_factor
    ADD CONSTRAINT t_factor_template_factor_id_pk PRIMARY KEY (id);


--
-- Name: t_factor_template t_factor_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_template
    ADD CONSTRAINT t_factor_template_pkey PRIMARY KEY (id);


--
-- Name: t_filter_config t_filter_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_filter_config
    ADD CONSTRAINT t_filter_config_pkey PRIMARY KEY (id);


--
-- Name: t_filter_enviroment_config t_filter_enviroment_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_filter_enviroment_config
    ADD CONSTRAINT t_filter_enviroment_config_pkey PRIMARY KEY (id);


--
-- Name: t_filter_method t_filter_method_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_filter_method
    ADD CONSTRAINT t_filter_method_pkey PRIMARY KEY (id);


--
-- Name: t_formula_params_ex t_formula_params_ex_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_formula_params_ex
    ADD CONSTRAINT t_formula_params_ex_pk PRIMARY KEY (id);


--
-- Name: t_formula t_formula_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_formula
    ADD CONSTRAINT t_formula_pkey PRIMARY KEY (id);


--
-- Name: t_group t_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group
    ADD CONSTRAINT t_group_pkey PRIMARY KEY (id);


--
-- Name: t_group_sensor t_group_sensor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group_sensor
    ADD CONSTRAINT t_group_sensor_pkey PRIMARY KEY (id);


--
-- Name: t_group_type_factor t_group_type_factor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group_type_factor
    ADD CONSTRAINT t_group_type_factor_pkey PRIMARY KEY (id);


--
-- Name: t_group_type t_group_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group_type
    ADD CONSTRAINT t_group_type_pkey PRIMARY KEY (type_code);


--
-- Name: t_institution t_institution_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_institution
    ADD CONSTRAINT t_institution_pkey PRIMARY KEY (id);


--
-- Name: t_item_unit t_item_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_item_unit
    ADD CONSTRAINT t_item_unit_pkey PRIMARY KEY (id);


--
-- Name: t_layout_model t_layout_model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_layout_model
    ADD CONSTRAINT t_layout_model_pkey PRIMARY KEY (id);


--
-- Name: t_layout_type t_layout_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_layout_type
    ADD CONSTRAINT t_layout_type_pkey PRIMARY KEY (id);


--
-- Name: t_message t_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_message
    ADD CONSTRAINT t_message_pkey PRIMARY KEY (id);


--
-- Name: t_message_type t_message_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_message_type
    ADD CONSTRAINT t_message_type_pkey PRIMARY KEY (id);


--
-- Name: t_netdisk_file t_netdisk_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_netdisk_file
    ADD CONSTRAINT t_netdisk_file_pkey PRIMARY KEY (id);


--
-- Name: t_organization t_organization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_organization
    ADD CONSTRAINT t_organization_pkey PRIMARY KEY (id);


--
-- Name: t_organization_project t_organization_project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_organization_project
    ADD CONSTRAINT t_organization_project_pkey PRIMARY KEY (id);


--
-- Name: t_phone_validate_code t_phone_validate_code_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_phone_validate_code
    ADD CONSTRAINT t_phone_validate_code_pkey PRIMARY KEY (id);


--
-- Name: t_project_approve t_project_approve_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_approve
    ADD CONSTRAINT t_project_approve_pkey PRIMARY KEY (id);


--
-- Name: t_project_construction t_project_construction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_construction
    ADD CONSTRAINT t_project_construction_pkey PRIMARY KEY (id);


--
-- Name: t_project t_project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project
    ADD CONSTRAINT t_project_pkey PRIMARY KEY (id);


--
-- Name: t_project_structure t_project_structure_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_structure
    ADD CONSTRAINT t_project_structure_pkey PRIMARY KEY (id);


--
-- Name: t_project_structuregroup t_project_structuregroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_structuregroup
    ADD CONSTRAINT t_project_structuregroup_pkey PRIMARY KEY (id);


--
-- Name: t_rational_device t_rational_device_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_rational_device
    ADD CONSTRAINT t_rational_device_pkey PRIMARY KEY (id);


--
-- Name: t_rational_filter t_rational_filter_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_rational_filter
    ADD CONSTRAINT t_rational_filter_pkey PRIMARY KEY (id);


--
-- Name: t_rational t_rational_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_rational
    ADD CONSTRAINT t_rational_pkey PRIMARY KEY (id);


--
-- Name: t_recalc_product_formula t_recalc_product_formula_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_recalc_product_formula
    ADD CONSTRAINT t_recalc_product_formula_pkey PRIMARY KEY (id);


--
-- Name: t_relay_proxy t_relay_proxy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_relay_proxy
    ADD CONSTRAINT t_relay_proxy_pkey PRIMARY KEY (name);


--
-- Name: t_report_generate t_report_generate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_report_generate
    ADD CONSTRAINT t_report_generate_pkey PRIMARY KEY (id);


--
-- Name: t_report_template t_report_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_report_template
    ADD CONSTRAINT t_report_template_pkey PRIMARY KEY (id);


--
-- Name: t_resource t_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_resource
    ADD CONSTRAINT t_resource_pkey PRIMARY KEY (code);


--
-- Name: t_role t_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_role
    ADD CONSTRAINT t_role_pkey PRIMARY KEY (id);


--
-- Name: t_role_resource t_role_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_role_resource
    ADD CONSTRAINT t_role_resource_pkey PRIMARY KEY (id);


--
-- Name: t_role_resource t_role_resource_role_resource_uindex; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_role_resource
    ADD CONSTRAINT t_role_resource_role_resource_uindex UNIQUE (role, resource);


--
-- Name: t_sensor_factor_threshold t_sensor_factor_threshold_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_factor_threshold
    ADD CONSTRAINT t_sensor_factor_threshold_pkey PRIMARY KEY (id);


--
-- Name: t_sensor_filter_config t_sensor_filter_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_filter_config
    ADD CONSTRAINT t_sensor_filter_config_pkey PRIMARY KEY (id);


--
-- Name: t_sensor_formula t_sensor_formula_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_formula
    ADD CONSTRAINT t_sensor_formula_pkey PRIMARY KEY (id);


--
-- Name: t_sensor_layout t_sensor_layout_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_layout
    ADD CONSTRAINT t_sensor_layout_pkey PRIMARY KEY (id);


--
-- Name: t_sensor t_sensor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor
    ADD CONSTRAINT t_sensor_pkey PRIMARY KEY (id);


--
-- Name: t_structure_component t_structure_component_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_component
    ADD CONSTRAINT t_structure_component_pkey PRIMARY KEY (id);


--
-- Name: t_structure_site t_structure_construction_site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_site
    ADD CONSTRAINT t_structure_construction_site_pkey PRIMARY KEY (id);


--
-- Name: t_structure_factor t_structure_factor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_factor
    ADD CONSTRAINT t_structure_factor_pkey PRIMARY KEY (id);


--
-- Name: t_structure t_structure_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure
    ADD CONSTRAINT t_structure_pkey PRIMARY KEY (id);


--
-- Name: t_structure_type_factor t_structure_type_factor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_type_factor
    ADD CONSTRAINT t_structure_type_factor_pkey PRIMARY KEY (id);


--
-- Name: t_structure_type t_structure_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_type
    ADD CONSTRAINT t_structure_type_pkey PRIMARY KEY (id);


--
-- Name: t_structuregroup t_structuregroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structuregroup
    ADD CONSTRAINT t_structuregroup_pkey PRIMARY KEY (id);


--
-- Name: t_structuregroup_structure t_structuregroup_structure_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structuregroup_structure
    ADD CONSTRAINT t_structuregroup_structure_pkey PRIMARY KEY (id);


--
-- Name: t_task_recalculate t_task_recalculate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_task_recalculate
    ADD CONSTRAINT t_task_recalculate_pkey PRIMARY KEY (id);


--
-- Name: t_type_alarm_source t_type_alarm_source_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_alarm_source
    ADD CONSTRAINT t_type_alarm_source_pkey PRIMARY KEY (id);


--
-- Name: t_type_alarm_state t_type_alarm_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_alarm_state
    ADD CONSTRAINT t_type_alarm_state_pkey PRIMARY KEY (id);


--
-- Name: t_type_event_index t_type_event_index_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_event_index
    ADD CONSTRAINT t_type_event_index_pkey PRIMARY KEY (id);


--
-- Name: t_type_file_type t_type_file_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_file_type
    ADD CONSTRAINT t_type_file_type_pkey PRIMARY KEY (id);


--
-- Name: t_type_institution_role t_type_institution_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_institution_role
    ADD CONSTRAINT t_type_institution_role_pkey PRIMARY KEY (id);


--
-- Name: t_type_org_type t_type_org_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_org_type
    ADD CONSTRAINT t_type_org_type_pkey PRIMARY KEY (id);


--
-- Name: t_type_project_state t_type_project_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_project_state
    ADD CONSTRAINT t_type_project_state_pkey PRIMARY KEY (id);


--
-- Name: t_type_report_state t_type_report_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_report_state
    ADD CONSTRAINT t_type_report_state_pkey PRIMARY KEY (id);


--
-- Name: t_type_report_type t_type_report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_report_type
    ADD CONSTRAINT t_type_report_type_pkey PRIMARY KEY (id);


--
-- Name: t_type_role_type t_type_role_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_type_role_type
    ADD CONSTRAINT t_type_role_type_pkey PRIMARY KEY (code);


--
-- Name: t_upload_comm_http t_upload_comm_http_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_upload_comm_http
    ADD CONSTRAINT t_upload_comm_http_pkey PRIMARY KEY (id);


--
-- Name: t_upload_params t_upload_params_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_upload_params
    ADD CONSTRAINT t_upload_params_pkey PRIMARY KEY (id);


--
-- Name: t_user_favorite t_user_favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_user_favorite
    ADD CONSTRAINT t_user_favorite_pkey PRIMARY KEY (id);


--
-- Name: t_user t_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_user
    ADD CONSTRAINT t_user_pkey PRIMARY KEY (id);


--
-- Name: t_user_token t_user_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_user_token
    ADD CONSTRAINT t_user_token_pkey PRIMARY KEY (token);


--
-- Name: t_vehicle_overload t_vehicle_overload_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_vehicle_overload
    ADD CONSTRAINT t_vehicle_overload_pkey PRIMARY KEY (id);


--
-- Name: t_video_ipc t_video_ipc_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_ipc
    ADD CONSTRAINT t_video_ipc_pkey PRIMARY KEY (id);


--
-- Name: t_video_ipc_station t_video_ipc_station_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_ipc_station
    ADD CONSTRAINT t_video_ipc_station_pkey PRIMARY KEY (id);


--
-- Name: t_video_nvr t_video_nvr_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_nvr
    ADD CONSTRAINT t_video_nvr_pkey PRIMARY KEY (id);


--
-- Name: t_video_nvr_vendor t_video_nvr_vendor_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_nvr_vendor
    ADD CONSTRAINT t_video_nvr_vendor_pkey PRIMARY KEY (id);


--
-- Name: t_video_push_server t_video_push_server_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_push_server
    ADD CONSTRAINT t_video_push_server_pkey PRIMARY KEY (id);


--
-- Name: t_workflow_business t_workflow_business_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_workflow_business
    ADD CONSTRAINT t_workflow_business_pkey PRIMARY KEY (id);


--
-- Name: t_workflow_form_proto t_workflow_form_proto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_workflow_form_proto
    ADD CONSTRAINT t_workflow_form_proto_pkey PRIMARY KEY (id);


--
-- Name: t_wx_bind_result t_wx_bind_result_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_wx_bind_result
    ADD CONSTRAINT t_wx_bind_result_pkey PRIMARY KEY (id);


--
-- Name: t_wx_subscribe t_wx_subscribe_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_wx_subscribe
    ADD CONSTRAINT t_wx_subscribe_pkey PRIMARY KEY (open_id);


--
-- Name: idx_api_log_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_log_status ON public.t_api_log USING btree (status_code);


--
-- Name: idx_api_log_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_log_time ON public.t_api_log USING btree (log_time);


--
-- Name: idx_data_original; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_data_original ON public.t_data_original USING btree (iota_device_id, collect_time);


--
-- Name: idx_project_approve; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_approve ON public.t_project_approve USING btree (project, approve_time, project_state);


--
-- Name: idx_task_recalculate_d_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_recalculate_d_time ON public.t_task_recalculate USING btree (data_begin_time, data_end_time);


--
-- Name: idx_task_recalculate_t_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_recalculate_t_time ON public.t_task_recalculate USING btree (task_begin_time, task_end_time);


--
-- Name: t_abn_report_params_id_uindex; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX t_abn_report_params_id_uindex ON public.t_abn_report_params USING btree (id);


--
-- Name: t_agg_config_id_uindex; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX t_agg_config_id_uindex ON public.t_agg_config USING btree (id);


--
-- Name: t_agg_threshold_config_id_uindex; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX t_agg_threshold_config_id_uindex ON public.t_agg_threshold_config USING btree (id);


--
-- Name: t_agg_type_id_uindex; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX t_agg_type_id_uindex ON public.t_agg_type USING btree (id);


--
-- Name: t_structure_construction_site_id_uindex; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX t_structure_construction_site_id_uindex ON public.t_structure_site USING btree (id);


--
-- Name: t_event_config indexId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_event_config
    ADD CONSTRAINT "indexId" FOREIGN KEY ("indexId") REFERENCES public.t_type_event_index(id);


--
-- Name: t_event_config structId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_event_config
    ADD CONSTRAINT "structId" FOREIGN KEY ("structId") REFERENCES public.t_structure(id);


--
-- Name: t_abn_report_params t_abn_report_params_t_abn_type_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_abn_report_params
    ADD CONSTRAINT t_abn_report_params_t_abn_type_id_fk FOREIGN KEY (abn_type) REFERENCES public.t_abn_type(id);


--
-- Name: t_abn_report_params t_abn_report_params_t_factor_proto_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_abn_report_params
    ADD CONSTRAINT t_abn_report_params_t_factor_proto_code_fk FOREIGN KEY (factor_proto_code) REFERENCES public.t_factor_proto(code);


--
-- Name: t_abn_report_params t_abn_report_params_t_sensor_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_abn_report_params
    ADD CONSTRAINT t_abn_report_params_t_sensor_id_fk FOREIGN KEY (station_id) REFERENCES public.t_sensor(id);


--
-- Name: t_agg_config t_agg_config_factor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_agg_config
    ADD CONSTRAINT t_agg_config_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES public.t_factor(id);


--
-- Name: t_agg_config t_agg_config_struct_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_agg_config
    ADD CONSTRAINT t_agg_config_struct_id_fkey FOREIGN KEY (struct_id) REFERENCES public.t_structure(id);


--
-- Name: t_agg_threshold_config t_agg_threshold_config_factor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_agg_threshold_config
    ADD CONSTRAINT t_agg_threshold_config_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES public.t_factor(id);


--
-- Name: t_agg_threshold_config t_agg_threshold_config_struct_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_agg_threshold_config
    ADD CONSTRAINT t_agg_threshold_config_struct_id_fkey FOREIGN KEY (struct_id) REFERENCES public.t_structure(id);


--
-- Name: t_alarm t_alarm_alarm_state_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm
    ADD CONSTRAINT t_alarm_alarm_state_fkey FOREIGN KEY (alarm_state) REFERENCES public.t_type_alarm_state(id);


--
-- Name: t_alarm t_alarm_alarm_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm
    ADD CONSTRAINT t_alarm_alarm_type_fkey FOREIGN KEY (alarm_type) REFERENCES public.t_alarm_type(id);


--
-- Name: t_alarm_deal t_alarm_deal_alarm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_deal
    ADD CONSTRAINT t_alarm_deal_alarm_fkey FOREIGN KEY (alarm) REFERENCES public.t_alarm(id);


--
-- Name: t_alarm_deal t_alarm_deal_deal_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_deal
    ADD CONSTRAINT t_alarm_deal_deal_user_fkey FOREIGN KEY (deal_user) REFERENCES public.t_user(id);


--
-- Name: t_alarm_detail t_alarm_detail_alarm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_detail
    ADD CONSTRAINT t_alarm_detail_alarm_fkey FOREIGN KEY (alarm) REFERENCES public.t_alarm(id);


--
-- Name: t_alarm_policy t_alarm_policy_t_organization_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_policy
    ADD CONSTRAINT t_alarm_policy_t_organization_id_fk FOREIGN KEY (created_organization) REFERENCES public.t_organization(id);


--
-- Name: t_alarm t_alarm_source_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm
    ADD CONSTRAINT t_alarm_source_type_fkey FOREIGN KEY (source_type) REFERENCES public.t_type_alarm_source(id);


--
-- Name: t_alarm t_alarm_structure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm
    ADD CONSTRAINT t_alarm_structure_fkey FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_alarm_type t_alarm_type_category_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_alarm_type
    ADD CONSTRAINT t_alarm_type_category_fkey FOREIGN KEY (category) REFERENCES public.t_alarm_category(id);


--
-- Name: t_app_message t_app_message_post_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_app_message
    ADD CONSTRAINT t_app_message_post_user_id_fkey FOREIGN KEY (post_user_id) REFERENCES public.t_user(id) ON DELETE CASCADE;


--
-- Name: t_app_message t_app_message_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_app_message
    ADD CONSTRAINT t_app_message_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.t_project(id) ON DELETE CASCADE;


--
-- Name: t_calendar t_calendar_org_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_calendar
    ADD CONSTRAINT t_calendar_org_fkey FOREIGN KEY (org) REFERENCES public.t_organization(id);


--
-- Name: t_calendar t_calendar_t_structure_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_calendar
    ADD CONSTRAINT t_calendar_t_structure_id_fk FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_calendar t_calendar_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_calendar
    ADD CONSTRAINT t_calendar_type_fkey FOREIGN KEY (type) REFERENCES public.t_calendar_type(id);


--
-- Name: t_project_construction t_construction_t_construction_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_construction
    ADD CONSTRAINT t_construction_t_construction_id_fk FOREIGN KEY (construction) REFERENCES public.t_construction(id);


--
-- Name: t_project_construction t_construction_t_project_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_construction
    ADD CONSTRAINT t_construction_t_project_id_fk FOREIGN KEY (project) REFERENCES public.t_project(id);


--
-- Name: t_data_sensor_latest t_data_sensor_latest_sensor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_data_sensor_latest
    ADD CONSTRAINT t_data_sensor_latest_sensor_fkey FOREIGN KEY (sensor) REFERENCES public.t_sensor(id);


--
-- Name: t_department t_department_org_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_department
    ADD CONSTRAINT t_department_org_fkey FOREIGN KEY (org) REFERENCES public.t_organization(id);


--
-- Name: t_department_structure t_department_structure_department_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_department_structure
    ADD CONSTRAINT t_department_structure_department_fkey FOREIGN KEY (department) REFERENCES public.t_department(id);


--
-- Name: t_department_structure t_department_structure_structure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_department_structure
    ADD CONSTRAINT t_department_structure_structure_fkey FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_device_sensor t_device_sensor_sensor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_device_sensor
    ADD CONSTRAINT t_device_sensor_sensor_fkey FOREIGN KEY (sensor) REFERENCES public.t_sensor(id);


--
-- Name: t_factor_proto_device t_factor_proto_device_formula_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_proto_device
    ADD CONSTRAINT t_factor_proto_device_formula_fkey FOREIGN KEY (formula) REFERENCES public.t_formula(id);


--
-- Name: t_factor_proto_device t_factor_proto_device_proto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_proto_device
    ADD CONSTRAINT t_factor_proto_device_proto_fkey FOREIGN KEY (proto) REFERENCES public.t_factor_proto(code);


--
-- Name: t_factor t_factor_proto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor
    ADD CONSTRAINT t_factor_proto_fkey FOREIGN KEY (proto) REFERENCES public.t_factor_proto(code);


--
-- Name: t_factor_proto_item t_factor_proto_item_proto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_proto_item
    ADD CONSTRAINT t_factor_proto_item_proto_fkey FOREIGN KEY (proto) REFERENCES public.t_factor_proto(code);


--
-- Name: t_factor_template_factor t_factor_template_factor_t_factor_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_template_factor
    ADD CONSTRAINT t_factor_template_factor_t_factor_id_fk FOREIGN KEY (factor) REFERENCES public.t_factor(id);


--
-- Name: t_factor_template_factor t_factor_template_factor_t_factor_template_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_template_factor
    ADD CONSTRAINT t_factor_template_factor_t_factor_template_id_fk FOREIGN KEY (template_id) REFERENCES public.t_factor_template(id);


--
-- Name: t_factor_template t_factor_template_org_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_template
    ADD CONSTRAINT t_factor_template_org_fkey FOREIGN KEY (org) REFERENCES public.t_organization(id);


--
-- Name: t_factor_template t_factor_template_structtype_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_factor_template
    ADD CONSTRAINT t_factor_template_structtype_fkey FOREIGN KEY (structtype) REFERENCES public.t_structure_type(id);


--
-- Name: t_filter_config t_filter_config_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_filter_config
    ADD CONSTRAINT t_filter_config_item_fkey FOREIGN KEY (item) REFERENCES public.t_factor_proto_item(id);


--
-- Name: t_filter_config t_filter_config_method_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_filter_config
    ADD CONSTRAINT t_filter_config_method_fkey FOREIGN KEY (method) REFERENCES public.t_filter_method(id);


--
-- Name: t_filter_config t_filter_config_sensor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_filter_config
    ADD CONSTRAINT t_filter_config_sensor_fkey FOREIGN KEY (sensor) REFERENCES public.t_sensor(id);


--
-- Name: t_group t_group_factor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group
    ADD CONSTRAINT t_group_factor_fkey FOREIGN KEY (factor) REFERENCES public.t_factor(id);


--
-- Name: t_group t_group_group_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group
    ADD CONSTRAINT t_group_group_type_fkey FOREIGN KEY (group_type) REFERENCES public.t_group_type(type_code);


--
-- Name: t_group_sensor t_group_sensor_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group_sensor
    ADD CONSTRAINT t_group_sensor_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.t_group(id);


--
-- Name: t_group_sensor t_group_sensor_sensor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group_sensor
    ADD CONSTRAINT t_group_sensor_sensor_fkey FOREIGN KEY (sensor) REFERENCES public.t_sensor(id);


--
-- Name: t_group t_group_structure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group
    ADD CONSTRAINT t_group_structure_fkey FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_group_type_factor t_group_type_factor_group_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group_type_factor
    ADD CONSTRAINT t_group_type_factor_group_type_fkey FOREIGN KEY (group_type) REFERENCES public.t_group_type(type_code);


--
-- Name: t_group_type_factor t_group_type_factor_proto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_group_type_factor
    ADD CONSTRAINT t_group_type_factor_proto_fkey FOREIGN KEY (proto) REFERENCES public.t_factor_proto(code);


--
-- Name: t_item_unit t_item_unit_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_item_unit
    ADD CONSTRAINT t_item_unit_item_fkey FOREIGN KEY (item) REFERENCES public.t_factor_proto_item(id);


--
-- Name: t_layout_model t_layout_model_layout_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_layout_model
    ADD CONSTRAINT t_layout_model_layout_fkey FOREIGN KEY (layout) REFERENCES public.t_layout_type(id);


--
-- Name: t_layout_model t_layout_model_structure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_layout_model
    ADD CONSTRAINT t_layout_model_structure_fkey FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_message t_message_message_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_message
    ADD CONSTRAINT t_message_message_type_fkey FOREIGN KEY (message_type) REFERENCES public.t_message_type(id);


--
-- Name: t_message t_message_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_message
    ADD CONSTRAINT t_message_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.t_user(id);


--
-- Name: t_netdisk_file t_netdisk_file_file_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_netdisk_file
    ADD CONSTRAINT t_netdisk_file_file_type_fkey FOREIGN KEY (file_type) REFERENCES public.t_type_file_type(id);


--
-- Name: t_netdisk_file t_netdisk_file_update_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_netdisk_file
    ADD CONSTRAINT t_netdisk_file_update_user_fkey FOREIGN KEY (update_user) REFERENCES public.t_user(id);


--
-- Name: t_organization t_organization_org_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_organization
    ADD CONSTRAINT t_organization_org_type_fkey FOREIGN KEY (org_type) REFERENCES public.t_type_org_type(id);


--
-- Name: t_organization_project t_organization_project_org_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_organization_project
    ADD CONSTRAINT t_organization_project_org_fkey FOREIGN KEY (org) REFERENCES public.t_organization(id);


--
-- Name: t_organization_project t_organization_project_project_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_organization_project
    ADD CONSTRAINT t_organization_project_project_fkey FOREIGN KEY (project) REFERENCES public.t_project(id);


--
-- Name: t_project_approve t_project_approve_approve_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_approve
    ADD CONSTRAINT t_project_approve_approve_user_fkey FOREIGN KEY (approve_user) REFERENCES public.t_user(id);


--
-- Name: t_project_approve t_project_approve_project_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_approve
    ADD CONSTRAINT t_project_approve_project_fkey FOREIGN KEY (project) REFERENCES public.t_project(id);


--
-- Name: t_project t_project_project_state_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project
    ADD CONSTRAINT t_project_project_state_fkey FOREIGN KEY (project_state) REFERENCES public.t_type_project_state(id);


--
-- Name: t_project_structure t_project_structure_project_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_structure
    ADD CONSTRAINT t_project_structure_project_fkey FOREIGN KEY (project) REFERENCES public.t_project(id);


--
-- Name: t_project_structure t_project_structure_structure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_structure
    ADD CONSTRAINT t_project_structure_structure_fkey FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_project_structuregroup t_project_structuregroup_project_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_structuregroup
    ADD CONSTRAINT t_project_structuregroup_project_fkey FOREIGN KEY (project) REFERENCES public.t_project(id);


--
-- Name: t_project_structuregroup t_project_structuregroup_structuregroup_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_project_structuregroup
    ADD CONSTRAINT t_project_structuregroup_structuregroup_fkey FOREIGN KEY (structuregroup) REFERENCES public.t_structuregroup(id);


--
-- Name: t_rational_device t_rational_device_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_rational_device
    ADD CONSTRAINT t_rational_device_item_fkey FOREIGN KEY (item) REFERENCES public.t_factor_proto_item(id);


--
-- Name: t_rational_filter t_rational_filter_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_rational_filter
    ADD CONSTRAINT t_rational_filter_item_fkey FOREIGN KEY (item) REFERENCES public.t_factor_proto_item(id);


--
-- Name: t_rational_filter t_rational_filter_sensor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_rational_filter
    ADD CONSTRAINT t_rational_filter_sensor_fkey FOREIGN KEY (sensor) REFERENCES public.t_sensor(id);


--
-- Name: t_rational t_rational_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_rational
    ADD CONSTRAINT t_rational_item_fkey FOREIGN KEY (item) REFERENCES public.t_factor_proto_item(id);


--
-- Name: t_rational t_rational_sensor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_rational
    ADD CONSTRAINT t_rational_sensor_fkey FOREIGN KEY (sensor) REFERENCES public.t_sensor(id);


--
-- Name: t_recalc_product_formula t_recalc_product_formula_t_formula_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_recalc_product_formula
    ADD CONSTRAINT t_recalc_product_formula_t_formula_id_fk FOREIGN KEY (formula) REFERENCES public.t_formula(id);


--
-- Name: t_report_generate t_report_generate_report_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_report_generate
    ADD CONSTRAINT t_report_generate_report_type_fkey FOREIGN KEY (report_type) REFERENCES public.t_type_report_type(id);


--
-- Name: t_report_generate t_report_generate_structure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_report_generate
    ADD CONSTRAINT t_report_generate_structure_fkey FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_report_template t_report_template_report_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_report_template
    ADD CONSTRAINT t_report_template_report_type_fkey FOREIGN KEY (report_type) REFERENCES public.t_type_report_type(id);


--
-- Name: t_role t_role_dep_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_role
    ADD CONSTRAINT t_role_dep_fkey FOREIGN KEY (dep) REFERENCES public.t_department(id);


--
-- Name: t_role_resource t_role_resource_resource_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_role_resource
    ADD CONSTRAINT t_role_resource_resource_fkey FOREIGN KEY (resource) REFERENCES public.t_resource(code);


--
-- Name: t_role_resource t_role_resource_role_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_role_resource
    ADD CONSTRAINT t_role_resource_role_fkey FOREIGN KEY (role) REFERENCES public.t_role(id);


--
-- Name: t_sensor t_sensor_factor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor
    ADD CONSTRAINT t_sensor_factor_fkey FOREIGN KEY (factor) REFERENCES public.t_factor(id);


--
-- Name: t_sensor_factor_threshold t_sensor_factor_threshold_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_factor_threshold
    ADD CONSTRAINT t_sensor_factor_threshold_item_fkey FOREIGN KEY (item) REFERENCES public.t_factor_proto_item(id);


--
-- Name: t_sensor_factor_threshold t_sensor_factor_threshold_sensor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_factor_threshold
    ADD CONSTRAINT t_sensor_factor_threshold_sensor_fkey FOREIGN KEY (sensor) REFERENCES public.t_sensor(id);


--
-- Name: t_sensor_filter_config t_sensor_filter_config_item_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_filter_config
    ADD CONSTRAINT t_sensor_filter_config_item_fkey FOREIGN KEY (item) REFERENCES public.t_factor_proto_item(id);


--
-- Name: t_sensor_filter_config t_sensor_filter_config_method_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_filter_config
    ADD CONSTRAINT t_sensor_filter_config_method_fkey FOREIGN KEY (method) REFERENCES public.t_filter_method(id);


--
-- Name: t_sensor_filter_config t_sensor_filter_config_sensor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_filter_config
    ADD CONSTRAINT t_sensor_filter_config_sensor_fkey FOREIGN KEY (sensor) REFERENCES public.t_sensor(id);


--
-- Name: t_sensor_formula t_sensor_formula_formula_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_formula
    ADD CONSTRAINT t_sensor_formula_formula_fkey FOREIGN KEY (formula) REFERENCES public.t_formula(id);


--
-- Name: t_sensor_formula t_sensor_formula_sensor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_formula
    ADD CONSTRAINT t_sensor_formula_sensor_fkey FOREIGN KEY (sensor) REFERENCES public.t_sensor(id);


--
-- Name: t_sensor_layout t_sensor_layout_model_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_layout
    ADD CONSTRAINT t_sensor_layout_model_fkey FOREIGN KEY (model) REFERENCES public.t_layout_model(id);


--
-- Name: t_sensor_layout t_sensor_layout_sensor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_layout
    ADD CONSTRAINT t_sensor_layout_sensor_fkey FOREIGN KEY (sensor) REFERENCES public.t_sensor(id);


--
-- Name: t_sensor_layout t_sensor_layout_t_layout_model__fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor_layout
    ADD CONSTRAINT t_sensor_layout_t_layout_model__fk FOREIGN KEY (modal_layout) REFERENCES public.t_layout_model(id);


--
-- Name: t_sensor t_sensor_structure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_sensor
    ADD CONSTRAINT t_sensor_structure_fkey FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_structure_factor t_structure_factor_factor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_factor
    ADD CONSTRAINT t_structure_factor_factor_fkey FOREIGN KEY (factor) REFERENCES public.t_factor(id);


--
-- Name: t_structure_factor t_structure_factor_structure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_factor
    ADD CONSTRAINT t_structure_factor_structure_fkey FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_structure t_structure_org_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure
    ADD CONSTRAINT t_structure_org_fkey FOREIGN KEY (org) REFERENCES public.t_organization(id);


--
-- Name: t_structure t_structure_structure_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure
    ADD CONSTRAINT t_structure_structure_type_fkey FOREIGN KEY (structure_type) REFERENCES public.t_structure_type(id);


--
-- Name: t_structure_type_factor t_structure_type_factor_factor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_type_factor
    ADD CONSTRAINT t_structure_type_factor_factor_fkey FOREIGN KEY (factor) REFERENCES public.t_factor(id);


--
-- Name: t_structure_type_factor t_structure_type_factor_structure_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structure_type_factor
    ADD CONSTRAINT t_structure_type_factor_structure_type_fkey FOREIGN KEY (structure_type) REFERENCES public.t_structure_type(id);


--
-- Name: t_structuregroup_structure t_structuregroup_structure_structure_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structuregroup_structure
    ADD CONSTRAINT t_structuregroup_structure_structure_fkey FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_structuregroup_structure t_structuregroup_structure_structuregroup_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_structuregroup_structure
    ADD CONSTRAINT t_structuregroup_structure_structuregroup_fkey FOREIGN KEY (structuregroup) REFERENCES public.t_structuregroup(id);


--
-- Name: t_task_recalculate t_task_recalculate_emit_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_task_recalculate
    ADD CONSTRAINT t_task_recalculate_emit_user_fkey FOREIGN KEY (emit_user) REFERENCES public.t_user(id);


--
-- Name: t_institution t_type_institution_role_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_institution
    ADD CONSTRAINT t_type_institution_role_fkey FOREIGN KEY (institutionrole) REFERENCES public.t_type_institution_role(id);


--
-- Name: t_user_favorite t_user_favorite_file_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_user_favorite
    ADD CONSTRAINT t_user_favorite_file_type_fkey FOREIGN KEY (file_type) REFERENCES public.t_type_file_type(id);


--
-- Name: t_user_favorite t_user_favorite_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_user_favorite
    ADD CONSTRAINT t_user_favorite_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.t_user(id);


--
-- Name: t_user t_user_org_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_user
    ADD CONSTRAINT t_user_org_fkey FOREIGN KEY (org) REFERENCES public.t_organization(id);


--
-- Name: t_user t_user_role_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_user
    ADD CONSTRAINT t_user_role_fkey FOREIGN KEY (role) REFERENCES public.t_role(id);


--
-- Name: t_video_ipc_station t_video_ipc_station_t_sensor_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_ipc_station
    ADD CONSTRAINT t_video_ipc_station_t_sensor_id_fk FOREIGN KEY (station) REFERENCES public.t_sensor(id);


--
-- Name: t_video_ipc_station t_video_ipc_station_t_video_ipc_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_ipc_station
    ADD CONSTRAINT t_video_ipc_station_t_video_ipc_id_fk FOREIGN KEY (ipc) REFERENCES public.t_video_ipc(id);


--
-- Name: t_video_ipc t_video_ipc_t_structure_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_ipc
    ADD CONSTRAINT t_video_ipc_t_structure_id_fk FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_video_ipc t_video_ipc_t_video_nvr_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_ipc
    ADD CONSTRAINT t_video_ipc_t_video_nvr_id_fk FOREIGN KEY (nvr) REFERENCES public.t_video_nvr(id);


--
-- Name: t_video_ipc t_video_ipc_t_video_push_server_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_ipc
    ADD CONSTRAINT t_video_ipc_t_video_push_server_id_fk FOREIGN KEY (push_server) REFERENCES public.t_video_push_server(id);


--
-- Name: t_video_nvr t_video_nvr_t_structure_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_nvr
    ADD CONSTRAINT t_video_nvr_t_structure_id_fk FOREIGN KEY (structure) REFERENCES public.t_structure(id);


--
-- Name: t_video_nvr t_video_nvr_t_video_nvr_vendor_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_video_nvr
    ADD CONSTRAINT t_video_nvr_t_video_nvr_vendor_id_fk FOREIGN KEY (vendor) REFERENCES public.t_video_nvr_vendor(id);


--
-- Name: t_wx_bind_result t_wx_bind_result_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.t_wx_bind_result
    ADD CONSTRAINT t_wx_bind_result_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.t_user(id);


--
-- PostgreSQL database dump complete
--

