--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: t_abn_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_abn_type (id, name, description) FROM stdin;
3	trend	趋势
1	interrupt	数据中断
2	burr	毛刺
\.


--
-- Data for Name: t_agg_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_agg_type (id, type_name, parent_type_id, description, name) FROM stdin;
1000	分类	0	\N	\N
1001	算法	0	\N	\N
2001	日聚集	1000	\N	d
2002	周聚集	1000	\N	w
2003	月聚集	1000	\N	m
2004	年聚集	1000	\N	y
2005	时聚集	1000	\N	h
3001	平均值	1001	\N	avg
3002	最大值	1001	\N	max
3003	最小值	1001	\N	min
3004	中值	1001	\N	med
3005	求和	1001	\N	sum
\.


--
-- Data for Name: t_alarm_category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_alarm_category (id, name) FROM stdin;
1	设备类
2	数据类
3	开发类
\.


--
-- Data for Name: t_alarm_code; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_alarm_code (id, code, name, type_code, level, upgrade_strategy, enable) FROM stdin;
1	30010403	正常操作发生异常	3001	3	\N	t
2	30010016	设备自动采集	3001	3	\N	t
3	30010301	华云雨量计同步时间	3001	3	\N	t
4	10010006	该传感器不参与采集	1001	3	\N	t
5	2003	维度任务交叠	3004	3	\N	t
6	50010001	网关与服务端之间心跳超时	5001	1	\N	t
7	60010002	电量不高于20%	6001	2	\N	t
8	3008	脚本调用异常	3004	3	\N	t
9	10010002	无效DTU	1001	1	\N	t
10	30080002	传感器数据变化速率超过2级告警阈值	3008	2	\N	t
11	3003	协议初始化异常	3004	3	\N	t
12	30010005	项目号错误	3001	2	\N	t
13	1001	采集超时	3003	3	\N	t
14	30010026	测斜仪类传感器初始角度设置错误	3001	3	\N	t
15	2002	维度未使用能力	3004	3	\N	t
16	30010023	振弦传感器短路	3001	3	\N	t
17	30030001	采集超时	3003	3	\N	t
18	30040003	无效数据	3004	3	\N	t
19	30010011	采集的频率异常	3001	3	\N	t
20	2004	维度在开始前被终止	3004	3	\N	t
21	30010031	设备电量异常	3001	2	\N	t
22	30080001	传感器数据变化速率超过1级告警阈值	3008	1	\N	t
23	30010020	时间设置错误	3001	3	\N	t
24	30010201	频率线异常	3001	3	\N	t
25	30070001	传感器测量值超过1级告警阈值	3007	1	\N	t
26	30010006	广播号错误	3001	2	\N	t
27	30010017	系统忙碌	3001	2	\N	t
28	30010007	读取传感器信息错误	3001	3	\N	t
30	30010024	温度传感器断路	3001	3	\N	t
31	20020003	采集命令下发错误	2002	1	\N	t
32	30010029	器件初始化/复位失败	3001	3	\N	t
33	30010101	模块号错误	3001	3	\N	t
34	30010025	温度传感器短路	3001	3	\N	t
35	2001	任务已过期	3004	3	\N	t
36	30010501	激光返回错误	3001	3	\N	t
37	3005	协议数据格式异常	3004	3	\N	t
38	60010001	电量不高于10%	6001	1	\N	t
39	10010003	沉降分组计算没有基点数据	1001	1	\N	t
40	30040002	接收数据为空	3004	3	\N	t
41	30010010	通道号错误	3001	3	\N	t
42	30010402	寄存器错误	3001	3	\N	t
43	3001	协议定义错误	3004	3	\N	t
44	30010003	校验码错误	3001	3	\N	t
45	10010007	找不到该传感器信息	1001	2	\N	t
46	30010030	I2C总线忙	3001	2	\N	t
47	30070002	传感器测量值超过2级告警阈值	3007	2	\N	t
48	30050001	采集数据超出传感器量程	3005	3	\N	t
49	2005	维度达到最大调用次数	3004	3	\N	t
50	30010014	采集的电压异常	3001	3	\N	t
51	30010008	读取设备信息错误	3001	3	\N	t
52	20020002	DTU忙碌	2002	3	\N	t
53	30010002	单总线短路检测	3001	1	\N	t
54	3006	协议加载异常	3004	3	\N	t
55	30010401	功能号错误	3001	3	\N	t
56	30010018	数据存储错误	3001	3	\N	t
57	30010028	磁通量传感器采集积分电压异常	3001	3	\N	t
58	30040001	解析数据失败	3004	3	\N	t
59	30010021	数据存储错误	3001	3	\N	t
60	30010013	采集的湿度异常	3001	3	\N	t
61	10010004	编译错误	1001	1	\N	t
62	5001	数据有效性判断: 违例	3005	3	\N	t
63	30010202	温度线异常	3001	3	\N	t
64	30010004	功能码错误	3001	2	\N	t
65	30010009	采集时间错误	3001	3	\N	t
66	10010005	采集命令构造错误	1001	1	\N	t
67	30080003	传感器数据变化速率超过3级告警阈值	3008	3	\N	t
68	20020001	写串口异常	2002	1	\N	t
69	30070003	传感器测量值超过3级告警阈值	3007	3	\N	t
70	20010001	DTU未连接	2001	1	\N	t
71	60010003	电量不高于30%	6001	3	\N	t
72	30010015	采集的角度异常	3001	3	\N	t
73	10010001	发送数据为空	1001	3	\N	t
74	30010027	测斜仪类传感器温补系数设置错误	3001	3	\N	t
75	30020002	不受支持的协议	3002	2	\N	t
76	30060001	传感器数据中断	3006	3	\N	t
77	30010203	频率线温度线都异常	3001	3	\N	t
78	30010012	采集的温度异常	3001	3	\N	t
79	30010001	单总线忙	3001	2	\N	t
80	30020001	协议错误	3002	2	\N	t
81	3007	协议脚本中缺少函数	3004	3	\N	t
82	30010019	数据读取错误	3001	3	\N	t
83	30010022	振弦传感器断路	3001	3	\N	t
84	3010	协议缺失	3004	1	\N	f
29	3002	无法建立连接	3004	3	\N	f
85	30090001	聚集数据超过1级告警阈值	3009	1	\N	t
86	30090002	聚集数据超过2级告警阈值	3009	2	\N	t
87	30090003	聚集数据超过3级告警阈值	3009	3	\N	t
88	70021100	24小时紧急	7002	1	\N	t
89	70021101	个人救护	7002	1	\N	t
90	70021110	火警报警	7002	1	\N	t
91	70021111	燃气报警	7002	1	\N	t
92	70021112	水浸报警	7002	1	\N	t
93	70021130	瞬时报警	7002	1	\N	t
94	70021384	无线探测器低压	7002	1	\N	t
95	70021140	温感报警	7002	1	\N	t
96	70021400	周期检测	7002	1	\N	t
97	70021485	巡更	7002	1	\N	t
98	70021609	IP设置	7002	1	\N	t
99	70021702	无线探测器防拆	7002	1	\N	t
100	70030001	垃圾箱状态异常	7003	1	\N	t
101	70040001	电流小于阈值	7004	1	\N	t
102	70040002	电流大于阈值	7004	1	\N	t
103	70040003	电压小于阈值	7004	1	\N	t
104	70040004	电压大于阈值	7004	1	\N	t
105	70040005	离线	7004	1	\N	t
106	30100001	数据异常	3010	1	\N	t
107	70050001	RTU告警	7005	1	\N	t
\.


--
-- Data for Name: t_alarm_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_alarm_type (id, code, name, description, category, enabled, upgrade_strategy) FROM stdin;
1	2001	DTU下线	DTU下线时触发	1	t	\N
7	5001	网关无响应	网关程序无响应	1	t	\N
8	6001	低电量	节点电量低	1	t	\N
9	6002	未传输数据过多	节点唤醒，数据量>100时触发	1	t	\N
10	6003	节点未苏醒	节点未在指定时刻苏醒过来	1	t	\N
11	3007	数据超阈值	数据超过设置的告警阈值	2	t	\N
12	3008	变化速率超阈值	采集数据变化速率超过设置的告警阈值	2	t	\N
13	1001	DAC内部错误	DAC内部错误	3	t	\N
14	2002	DTU通信异常	DTU串口写失败或者DTU忙碌状态下发送指令时	3	t	\N
15	3002	协议错误	DAC下发采集指令时发生错误	3	t	\N
2	3001	设备诊断异常	采集时传感器返回诊断错误码	1	t	{"total": 2, "upgrade1": 10, "upgrade2": 10}
3	3003	采集超时	DAC下发采集指令后20s未接收到返回码	1	t	{"total": 2, "upgrade1": 10, "upgrade2": 10}
4	3004	数据解析错误	DAC解析返回码出现错误	1	t	{"total": 2, "upgrade1": 10, "upgrade2": 10}
5	3005	数据超量程	采集数据超过传感器量程	1	t	{"total": 2, "upgrade1": 10, "upgrade2": 10}
6	3006	数据中断	连续3轮未采集到数据	1	t	{"total": 2, "upgrade1": 10, "upgrade2": 10}
17	7002	烟感告警	烟感告警	1	t	\N
18	7003	垃圾箱设备异常	垃圾箱设备异常	1	t	\N
19	7004	烟雾火警	烟雾火警	1	t	\N
16	3009	聚集数据超阈值	时/日聚集数据超过设置的告警阈值	2	t	{"independent": true}
20	3010	数据异常	数据识别为异常	2	t	\N
21	7005	RTU告警	RTU告警	1	t	\N
\.


--
-- Data for Name: t_calendar_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_calendar_type (id, name) FROM stdin;
1	工程进度
2	人工巡检
3	集成配置
4	系统跟踪
5	重大事件
\.


--
-- Data for Name: t_component; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_component (id, component) FROM stdin;
1	桥跨结构
2	支座系统
3	桥墩
4	桥台
5	墩台基础
6	桥跨铺装
7	排水防水系统
8	栏杆
9	伸缩缝
10	灯光照明
\.


--
-- Data for Name: t_factor_proto; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_factor_proto (code, name) FROM stdin;
1001	风速风向
1002	温湿度
1003	雨量
1004	温度
1005	地下水位
1006	湿度
1007	噪声
1008	渗流量
1009	浸润线
1010	干滩和库水位
1011	电流
1012	气压
1013	液位
1014	流量
1015	蚀度
1016	ph值
1017	氧气/氮气浓度
1018	气体浓度
1019	爆炸性气体
1020	光照
1021	辐射
1022	风速
1023	液体浓度
1024	窨井水位
1025	路面积水
2001	索力
2002	车流量
2003	压力
2004	受力
3001	应变
3002	应变花
3003	应力
4001	单向位移
4002	双向位移
4003	三向位移
4004	挠度
4005	深层水平位移
4006	单向角度
4007	双向角度
4008	裂缝
4009	伸缩缝
4010	杆塔倾斜
4011	拱顶沉降
5001	振动速度
5002	振动加速度
5003	动应变
6001	起重机主起
6002	起重机副起
6003	起重机大车
6004	起重机小车
1026	粉尘/颗粒物监测
1027	大气污染指数
1028	结冰
1029	风向
2005	重力
4012	三向角度
1030	能见度
1031	一氧化碳浓度
4013	全站位移
2006	钢筋混凝土支撑轴力
1032	大气监测仪
1033	气象站监测
4014	塔吊
1034	扬尘
7001	立杆倾斜与轴力
7002	倾斜与支架水平位移
7003	倾斜与模板沉降
8001	空气质量指数
8002	地表水环境质量
9001	用电量
9002	用水量
9003	厕所人流量
9004	厕所环境
0001	状态
4015	升降机
1041	盐分电导率
6010	安全帽
1035	气象站
4016	高程
8003	睡眠
8004	求救
8005	电量
8006	跌倒定位
8007	定位
8008	心率
8009	运动数据
7007	垃圾容量
8010	恶臭
8011	移动空气质量
9005	空间转换门
4018	安全步距监测
9010	人流量
1045	库流量
1046	库容
1047	进水量
8012	恶臭排放量
1048	烟感报警
3006	管道应力
4020	相邻沉降
8013	路灯
5041	烟感报警
7008	站台限界
7009	智能垃圾
4021	桩顶水平及竖向位移
5005	振动等效声级
1050	河流监测
2014	受力与温度
3007	应力(Kpa)
1052	太阳辐射
1051	百叶气象
4023	恶臭气体四项监测
4022	恶臭气体六项监测
4024	恶臭气体四项监测-2
7010	消火栓
7011	电气火灾
4025	崩塌
4026	恶臭气体三项监测
8022	环境气体监测
5006	三向振动
8033	人员定位
7030	三相电表
\.


--
-- Data for Name: t_factor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_factor (id, name, proto, org, item) FROM stdin;
1	风速风向	1001	\N	{}
2	温湿度	1002	\N	{}
3	雨量	1003	\N	{}
4	温度	1004	\N	{}
5	噪声	1007	\N	{}
6	索力	2001	\N	{}
7	车流量	2002	\N	{}
8	加固钢板应变	3001	\N	{}
9	钢管拱肋应变	3001	\N	{}
10	混凝土拱肋应变	3001	\N	{}
11	应变	3001	\N	{}
13	表面位移	4003	\N	{}
14	塔顶偏位	4003	\N	{}
15	桥墩倾斜	4007	\N	{}
16	主梁挠度	4004	\N	{}
17	桥梁伸缩缝	4009	\N	{}
18	裂缝	4008	\N	{}
19	挠度	4004	\N	{}
20	支座位移	4001	\N	{}
21	倾角	4006	\N	{}
22	桥塔倾斜	4002	\N	{}
23	拱座转角	4006	\N	{}
24	位移	4001	\N	{}
25	梁体振动	5002	\N	{}
26	振动速度	5001	\N	{}
27	动应变	5003	\N	{}
28	桥面振动	5002	\N	{}
31	地下水位	1005	\N	{}
33	锚索受力	2004	\N	{}
36	支撑轴力	2004	\N	{}
37	围护墙内力	2004	\N	{}
38	支撑内力	2004	\N	{}
39	立柱内力	2004	\N	{}
40	锚杆内力	2004	\N	{}
41	土钉内力	2004	\N	{}
42	围护墙侧向土压力	2003	\N	{}
43	钢筋混凝土应力应变	3001	\N	{}
44	围护墙顶部水平位移	4002	\N	{}
45	围护墙竖向位移	4001	\N	{}
46	立柱竖向位移	4001	\N	{}
47	土体分层竖向位移	4001	\N	{}
48	周边地表竖向位移	4001	\N	{}
49	地表裂缝	4008	\N	{}
50	水平位移	4002	\N	{}
51	竖向位移	4001	\N	{}
52	深层水平位移	4005	\N	{}
58	土体压力	2003	\N	{}
60	锚杆拉力	2004	\N	{}
61	支护结构应力	3003	\N	{}
63	支护结构变形	4002	\N	{}
70	渗流量	1008	\N	{}
71	扬压力	2003	\N	{}
72	渗透压力	2003	\N	{}
75	坝体位移	4003	\N	{}
76	坝基位移	4003	\N	{}
77	近坝岸坡位移	4003	\N	{}
79	倾斜	4002	\N	{}
84	毒害气体	1018	\N	{}
85	初衬受压力	2003	\N	{}
86	涌水	2003	\N	{}
88	初支与二衬接触压力	2003	\N	{}
89	围岩与初支接触压力	2003	\N	{}
90	二衬钢筋应力	3003	\N	{}
91	拉索应力	3003	\N	{}
92	剪切件应力	3003	\N	{}
93	钢筋应力	3003	\N	{}
94	混凝土应力	3003	\N	{}
95	初支衬砌应变	3001	\N	{}
96	二次衬砌应变	3001	\N	{}
97	钢支撑应力	3001	\N	{}
98	锚杆轴力	3001	\N	{}
102	拱顶沉降	4011	\N	{}
103	净空收敛	4001	\N	{}
104	管片变形	4007	\N	{}
105	围岩体内部位移	4005	\N	{}
106	隧道结构水平位移	4002	\N	{}
107	道床及拱腰结构沉降	4001	\N	{}
108	隧道壁振动	5002	\N	{}
109	轨道板振动	5002	\N	{}
112	渗流	1008	\N	{}
113	浸润线	1009	\N	{}
114	干滩和库水位	1010	\N	{}
116	深部水平位移	4005	\N	{}
117	干滩高程	4001	\N	{}
127	建筑物倾斜	4007	\N	{}
129	周边土体振动	5002	\N	{}
131	杆塔倾斜	4010	\N	{}
133	蚀度	1015	\N	{}
134	PH值	1016	\N	{}
135	电流	1011	\N	{}
137	气压	1012	\N	{}
138	液位	1013	\N	{}
12	应变花	3002	\N	{}
35	钢支撑轴力	2004	\N	{}
139	流量	1014	\N	{}
140	压力	2003	\N	{}
142	杆塔倾斜	4002	\N	{}
143	振动加速度	5002	\N	{}
145	起重机主起	6001	\N	{}
146	起重机副起	6002	\N	{}
147	起重机大车	6003	\N	{}
148	起重机小车	6004	\N	{}
151	湿度	1006	\N	{}
152	CO2浓度	1018	\N	{}
153	光照	1020	\N	{}
155	辐射	1021	\N	{}
156	风速	1022	\N	{}
158	土温	1004	\N	{}
159	土湿	1006	\N	{}
160	土壤温湿度	1002	\N	{}
161	土壤盐分	1023	\N	{}
162	窨井水位	1024	\N	{}
163	路面积水	1025	\N	{}
164	排水管渠气体浓度	1018	\N	{}
165	氧气/氮气浓度	1017	\N	{}
166	其他常规气体	1018	\N	{}
167	爆炸性气体	1019	\N	{}
168	有机化合物气体	1018	\N	{}
169	船舶姿态	4007	\N	{}
170	粉尘	1026	\N	{}
171	PM	1027	\N	{}
173	建筑物倾斜(位移)	4002	\N	{}
174	路面结冰	1028	\N	{}
204	沉降	4001	\N	{}
205	分层沉降	4001	\N	{}
206	风向	1029	\N	{}
211	油压	2003	\N	{}
214	烟雾	1018	\N	{}
215	CO浓度	1018	\N	{}
216	NO2浓度	1018	\N	{}
217	O3浓度	1018	\N	{}
218	PM2.5浓度	1026	\N	{}
219	PM10浓度	1026	\N	{}
220	SO2浓度	1018	\N	{}
222	水平收敛	4001	\N	{}
223	绳索张力	2005	\N	{}
226	重量	2005	\N	{}
227	倾角	4012	\N	{}
228	能见度	1030	\N	{}
231	CO浓度	1031	\N	{}
232	O2浓度	1017	\N	{}
234	塔体倾斜	4007	\N	{}
237	应力	3003	\N	{}
238	地表沉降	4001	\N	{}
239	全站仪位移	4013	\N	{}
241	钢筋混凝土支撑轴力	2006	\N	{}
242	空气质量	1032	\N	{}
243	大气监测	1033	\N	{}
249	塔吊	4014	\N	{}
250	扬尘	1034	\N	{}
251	立杆倾斜与立杆轴力	7001	\N	{}
252	倾斜与支架水平位移	7002	\N	{}
253	立杆倾斜与模板沉降	7003	\N	{}
254	高支模倾斜	4007	1	{}
255	空气质量指数	8001	\N	{}
256	地表水环境质量	8002	\N	{}
259	用电量	9001	\N	{}
260	用水量	9002	\N	{}
261	厕所人流量	9003	\N	{}
262	厕所坑位	0001	\N	{}
263	厕所环境	9004	\N	{}
264	升降机	4015	\N	{}
266	盐分电导率	1041	\N	{}
267	土壤温湿度	1002	\N	{}
269	土壤PH值	1016	\N	{}
34	孔隙水压	2003	\N	{}
272	空气五项	1035	\N	{}
271	人员定位	6010	\N	{}
273	沉降高程	4016	\N	{}
274	睡眠	8003	\N	{}
275	求救	8004	\N	{}
276	电量	8005	\N	{}
277	跌倒定位	8006	\N	{}
278	定位	8007	\N	{}
279	心率	8008	\N	{}
280	运动数据	8009	\N	{}
283	水位	1005	1	{}
284	垃圾容量	7007	\N	{}
285	恶臭	8010	\N	{}
286	围护墙水平位移	4001	1	{}
287	移动空气质量	8011	\N	{}
288	空间转换门	9005	\N	{}
289	安全步距监测	4018	\N	{}
290	水位监测	1005	1	{}
292	振动加速度监测	5002	1	{}
293	人流量	9010	\N	{}
294	库流量	1045	1	{}
296	库容监测	1046	1	{}
291	出水量监测	1045	1	{}
295	进水量监测	1047	1	{}
297	载重	2005	\N	{}
299	建筑物裂缝监测	4008	1	{}
301	燃气管线沉降	4001	1	{}
300	围护墙顶部沉降监测	4001	1	{}
298	建筑物沉降监测	4001	1	{}
302	堆石高度监测	4001	1	{}
303	恶臭排放量	8012	\N	{}
304	恶臭排放量	8012	1	{}
306	爬架倾斜	4007	1	{}
307	燃气管道应变	3001	1	{}
308	水池水位	1005	1	{}
309	钢筋应力	3003	1	{}
310	管道应力	3006	\N	{}
311	全站仪三向位移	4003	1	{}
312	相邻沉降	4020	\N	{}
313	相邻沉降	4020	\N	{}
314	路灯	8013	\N	{}
315	烟感报警	5041	\N	{}
316	站台限界	7008	\N	{}
317	坝体单向表面位移	4001	1	{}
319	智能垃圾	7009	\N	{}
320	智能垃圾	7009	\N	{}
321	桩顶水平及竖向位移	4021	\N	{}
322	环境监测	1034	1	{}
323	建筑物振动	5005	\N	{}
324	挡土墙倾斜	4007	1	{}
325	河流监测	1050	\N	{}
326	河流监测	1050	1	{}
327	支撑轴力与温度	2014	\N	{}
328	应力(Kpa)	3007	\N	{}
329	太阳辐射	1052	\N	{}
330	百叶气象	1051	\N	{}
332	恶臭气体四项监测	4023	\N	{}
333	恶臭气体六项监测	4022	\N	{}
335	周边地表竖向位移	4001	1	{}
336	围护墙顶部水平位移（位移）	4001	1	{}
337	恶臭气体四项监测-2	4024	\N	{}
338	山体裂缝监测	4008	1	{}
339	消防水池	1005	1	{}
340	烟感	1048	1	{}
341	可燃气体	1019	1	{}
342	消火栓	7010	\N	{}
343	电气火灾	7011	\N	{}
344	断面收敛	4011	1	{}
345	断面沉降	4001	1	{}
346	崩塌	4025	\N	{}
347	土壤温湿度	1002	1	{}
348	倾角位移监测	4007	\N	{}
349	恶臭气体三项监测	4026	\N	{}
350	抗滑桩倾角	4007	1	{}
353	环境气体监测	8022	\N	{}
354	爆破振动	5006	\N	{}
355	振动爆破	5006	1	{}
356	人员定位	8033	\N	{}
357	三轴倾角	4012	1	{}
359	三相电表	7030	\N	{}
\.


--
-- Data for Name: t_formula; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_formula (id, name, expression_shown, description, params, ioparams, expression, ioparams_ext, props) FROM stdin;
125	力转应力	σ=F/A	\N	[{"name": "A", "unit": "mm^2", "alias": "钢筋计有效面积(mm^2)"}]	{"input": ["F"], "output": ["σ"]}	σ=F*1000/A	{"input": [{"name": "F", "unit": "kN"}], "output": [{"name": "σ", "unit": "MPa"}]}	\N
100	减初值公式	phy=DAQi-DAQ0	\N	[{"name": "DAQ0", "alias": "初值"}]	{"input": ["DAQi"], "output": ["phy"]}	phy=DAQi-DAQ0	{"input": [{"name": "DAQi"}], "output": [{"name": "phy"}]}	\N
120	振动索力识别公式	T=4*m*l^2*f1^2/1000	\N	[{"name": "l", "alias": "索长(m)"}, {"name": "m", "alias": "线密度(kg/m)"}, {"name": "f1", "alias": "基频(Hz)"}, {"name": "δ", "alias": "误差范围(Hz)"}]	{"input": [""], "output": ["force"]}	\N	{"input": [], "output": [{"name": "force", "unit": "kN"}]}	\N
105	压强测水位公式	h=(Pi/pg)	\N	[{"name": "ρ", "unit": "10^3kg/m^3", "alias": "密度(10^3kg/m^3)"}]	{"input": ["Pi"], "output": ["h"]}	h=Pi*1000/(ρ*9.8)	{"input": [{"name": "Pi", "unit": "kPa"}], "output": [{"name": "h", "unit": "m"}]}	\N
107	干滩长度计算	l=(H-(h+hi))/s	\N	[{"name": "H", "unit": "m", "alias": "滩顶高程(m)"}, {"name": "h", "unit": "m", "alias": "安装高程(m)"}, {"name": "s", "alias": "坡比"}]	{"input": ["hi"], "output": ["L"]}	L=(H-(h0+hi))/s	{"input": [{"name": "hi", "unit": "m"}], "output": [{"name": "L", "unit": "m"}]}	\N
108	振动物理量转换公式	A=V/k	弃用公式	[{"name": "k", "alias": "转换系数"}]	{"input": [""], "output": [""]}	\N	\N	\N
111	初值减测值	phy=C0-Ci	\N	[{"name": "C0", "alias": "初值"}]	{"input": ["Ci"], "output": ["phy"]}	phy=C0-Ci	{"input": [{"name": "Ci"}], "output": [{"name": "phy"}]}	\N
113	应变计计算轴力	F=A*E*[(∑εi)/n]+F0	\N	[{"name": "E", "unit": "kN/mm^2", "alias": "钢材弹性模量(kN/mm^2)"}, {"name": "A", "unit": "mm^2", "alias": "钢材截面积(mm^2)"}, {"name": "F0", "unit": "kN", "alias": "初值(kN)"}]	{"input": ["ε"], "output": ["F"]}	F=ε*E*A+F0	{"input": [{"name": "ε", "unit": "με"}], "output": [{"name": "F", "unit": "kN"}]}	\N
114	路面积水液位计算	Hc=h+hsi	\N	[{"name": "h", "unit": "mm", "alias": "安装高度(mm)"}]	{"input": ["hsi"], "output": ["Hc"]}	Hc=h+hsi	{"input": [{"name": "hsi", "unit": "mm"}], "output": [{"name": "Hc", "unit": "mm"}]}	\N
116	逆初值基准值公式	phy=-(DAQi-DAQ0)+D	\N	[{"name": "D", "unit": "mm", "alias": "初始裂缝宽度(mm)"}, {"name": "C0", "unit": "mm", "alias": "初值(mm)"}]	{"input": ["DAQi"], "output": ["phy"]}	phy=-(DAQi-C0)+D	{"input": [{"name": "DAQi", "unit": "mm"}], "output": [{"name": "phy", "unit": "mm"}]}	\N
118	测斜倾角计算挠度	Yn=Yn-1+((Xn-Xn-1)/2)*((An-1*π/180)+(An*π/180)–2*M	弃用公式	[{"name": "L", "alias": "距基点位置(m)"}]	{"input": [""], "output": [""]}	\N	\N	\N
119	激光测沉降	Δh=(Li-L0)/tanθ	\N	[{"name": "L0", "alias": "初始测值(m)"}, {"name": "θ", "alias": "挡光板与垂直方向的夹角(°)"}]	{"input": ["Li"], "output": ["Δh"]}	Δh=(Li-L0)/tan(θ*π/180)	{"input": [{"name": "Li"}], "output": [{"name": "Δh"}]}	\N
122	振动特征参数计算	phy={pv,ppv,rms}	\N	[]	{"input": [""], "output": [""]}	\N	\N	\N
124	压力变送器公式	Δh=(Pi-P0)/(ρ*g)+H0	\N	[{"name": "ρ", "unit": "10^3kg/m^3", "alias": "密度(10^3kg/m^3)"}, {"name": "P0", "unit": "kPa", "alias": "压强初值(kPa)"}, {"name": "H0", "unit": "m", "alias": "安装高程(m)"}]	{"input": ["Pi"], "output": ["Δh"]}	Δh=(Pi-P0)/(ρ*g)+H0	{"input": [{"name": "Pi", "unit": "kPa"}], "output": [{"name": "Δh", "unit": "m"}]}	\N
202	组内平均	Δh=∑pv/n	\N	[]	{"input": ["pv"], "output": ["Δh"]}	Δh=AVG(pv)	{"input": [{"name": "pv"}], "output": [{"name": "Δh"}]}	\N
203	组内最大值	pmax=MAX(pv)	\N	[]	{"input": ["pv"], "output": ["pmax"]}	pmax=MAX(pv)	{"input": [{"name": "pv"}], "output": [{"name": "pmax"}]}	\N
205	虚拟基点公式	Δh=Base-(RefS-RefB)	弃用公式	[]	{"input": ["h"], "output": ["Δh"]}	\N	\N	\N
206	虚拟基点公式(二级)	Δh=Base0-(RefS0-RefB0)-(RefS1-RefB1)	弃用公式	[]	{"input": ["h"], "output": ["Δh"]}	\N	\N	\N
212	输电塔自动调平计算公式	h(i,j)=[i*a*sin(θ_x) + j*b*sin(θ_y)]/2; d = min{h(i,j)}; H(i,j) = h(i,j) - d; {i=±1,j=±1}	\N	[{"name": "L", "alias": "长度(mm)"}, {"name": "W", "alias": "宽度(mm)"}]	{"input": ["θx", "θy"], "output": ["angX", "angY", "Ha", "Hb", "Hc", "Hd"]}	\N	{"input": [{"name": "θx"}, {"name": "θy"}], "output": [{"name": "angX"}, {"name": "angY"}, {"name": "Ha"}, {"name": "Hb"}, {"name": "Hc"}, {"name": "Hd"}]}	\N
213	雷达物位计干滩计算公式	l=(H-(h+hi))/s;s=((h01-hi1)-(h02-hi2))/L	\N	[{"name": "H", "alias": "滩顶高程(m)"}, {"name": "h", "alias": "水位计安装高程(m)"}, {"name": "h01", "alias": "雷达物位计1安装高程(m)"}, {"name": "h02", "alias": "雷达物位计2安装高程(m)"}, {"name": "L", "alias": "水平距离(m)"}]	{"input": ["hi"], "output": ["l"]}	\N	{"input": [{"name": "hi"}], "output": [{"name": "l"}]}	\N
214	单轴倾角仪测量双向角度		配置2个传感器,第一个代表X方向,第二个代表Y方向	[]	{"input": ["v"], "output": ["x", "y"]}	\N	{"input": [{"name": "v"}], "output": [{"name": "x"}, {"name": "y"}]}	\N
215	单向位移计测三向位移		配置3个传感器,第一个代表X方向,第二个代表Y方向,第三个代表Z方向	[]	{"input": ["v"], "output": ["x", "y", "z"]}	\N	{"input": [{"name": "v"}], "output": [{"name": "x"}, {"name": "y"}, {"name": "z"}]}	\N
103	水位公式	H=h+h0	\N	[{"name": "h0", "alias": "深度初值(m)"}]	{"input": ["h"], "output": ["H"]}	H=h+h0	{"input": [{"name": "h", "unit": "m"}], "output": [{"name": "H", "unit": "m"}]}	\N
126	系数修正	f=k*fi	\N	[{"name": "k", "alias": "修正系数"}]	{"input": ["fi"], "output": ["f"]}	f=k*fi	{"input": [{"name": "fi"}], "output": [{"name": "f"}]}	\N
127	相反数	p=-v	\N	[]	{"input": ["v"], "output": ["p"]}	p=-v	{"input": [{"name": "v"}], "output": [{"name": "p"}]}	\N
128	一元线性公式	p=(v-a)*b	\N	[{"name": "a", "alias": "初值"}, {"name": "b", "alias": "系数"}]	{"input": ["v"], "output": ["p"]}	p=(v-a)*b	{"input": [{"name": "v"}], "output": [{"name": "p"}]}	\N
129	露点计算公式	X=(0.66077+(7.5*温度/（237.3+温度））+（Lg（湿度）-2）;露点温度＝（（0.66077-X)*237.3)/(X-8.16077)	\N	[]	{"input": ["temperature", "humidity"], "output": ["dew"]}	dew=((0.66077-X)*237.3)/(X-8.16077),X=0.66077+(7.5*temperature/(237.3+temperature))+(log(humidity)-2)	{"input": [{"name": "temperature"}, {"name": "humidity"}], "output": [{"name": "dew"}]}	\N
101	测斜减初值公式	phy=DAQi-DAQ0	\N	[{"name": "x0", "alias": "初值1"}, {"name": "y0", "alias": "初值2"}]	{"input": ["xi", "yi"], "output": ["x", "y"]}	x=xi-x0;y=yi-y0	{"input": [{"name": "xi"}, {"name": "yi"}], "output": [{"name": "x"}, {"name": "y"}]}	\N
102	测斜公式	Δl=c*[sin(αi)-sin(α0)]	\N	[{"name": "c", "unit": "mm", "alias": "测斜杆间距离长(mm)"}, {"name": "xα0", "unit": "°", "alias": "x方向角度初值(°)"}, {"name": "yα0", "unit": "°", "alias": "y方向角度初值(°)"}]	{"input": ["αx", "αy"], "output": ["x", "y"]}	x=c*(sin(αx*π/180)-sin(xα0*π/180));y=c*(sin(αy*π/180)-sin(yα0*π/180))	{"input": [{"name": "αx", "unit": "°"}, {"name": "αy", "unit": "°"}], "output": [{"name": "x", "unit": "mm"}, {"name": "y", "unit": "mm"}]}	\N
104	压力变送器公式	Δh=(Pi-P0)/(ρ*g)+H0	\N	[{"name": "ρ", "unit": "10^3kg/m^3", "alias": "密度(10^3kg/m^3)"}, {"name": "P0", "unit": "kPa", "alias": "压强初值(kPa)"}, {"name": "H0", "unit": "mm", "alias": "安装高程(mm)", "default": 0.0}]	{"input": ["Pi"], "output": ["Δh"]}	Δh=(Pi-P0)*1000/(ρ*9.8)+H0	{"input": [{"name": "Pi", "unit": "KPa"}], "output": [{"name": "Δh", "unit": "mm"}]}	\N
106	渗流计算	v=k*(h1-h2)/L	\N	[{"name": "type", "type": "enum", "alias": "量水堰类型", "range": ["三角堰", "矩形堰", "梯形堰"]}, {"name": "h", "unit": "m", "alias": "底长(m)"}, {"name": "H0", "unit": "m", "alias": "堰上水头初始值(m)"}, {"name": "P0", "unit": "kPa", "alias": "压力初始值(kPa)"}, {"name": "ρ", "unit": "10^3kg/m^3", "alias": "密度(10^3kg/m^3)"}]	{"input": ["p"], "output": ["v"]}	\N	{"input": [{"name": "p", "unit": "kPa"}], "output": [{"name": "v", "unit": "m3/s"}]}	\N
109	三维位移转换公式	X=(y-y0)*sinθ-(x-x0)*cosθ;Y=(y-y0)*cosθ+(x-x0)*sinθ;Z=z-z0	\N	[{"name": "x0", "unit": "mm", "alias": "x方向初始大地坐标(mm)"}, {"name": "y0", "unit": "mm", "alias": "y方向初始大地坐标(mm)"}, {"name": "z0", "unit": "mm", "alias": "z方向初始大地坐标(mm)"}, {"name": "θ", "unit": "°", "alias": "偏角(°)"}]	{"input": ["xi", "yi", "zi"], "output": ["X", "Y", "Z"]}	X=(yi-y0)*sin(θ*π/180)-(xi-x0)*cos(θ*π/180);Y=(yi-y0)*cos(θ*π/180)+(xi-x0)*sin(θ*π/180);Z=zi-z0	{"input": [{"name": "xi", "unit": "mm"}, {"name": "yi", "unit": "mm"}, {"name": "zi", "unit": "mm"}], "output": [{"name": "X", "unit": "mm"}, {"name": "Y", "unit": "mm"}, {"name": "Z", "unit": "mm"}]}	\N
115	荷载分布	t=(sl+ql)/v	弃用公式	[{"name": "SL", "alias": "距离上桥距离(m)"}, {"name": "SRP", "type": "enum", "alias": "距离桥梁相对位置", "range": ["上桥", "下桥"]}]	{"input": [""], "output": [""]}	\N	\N	\N
117	初值基准值公式	phy=DAQi-DAQ0+D	\N	[{"name": "D", "unit": "mm", "alias": "初始裂缝宽度(mm)"}, {"name": "C0", "unit": "mm", "alias": "初值(mm)"}]	{"input": ["DAQi"], "output": ["phy"]}	phy=DAQi-C0+D	{"input": [{"name": "DAQi", "unit": "mm"}], "output": [{"name": "phy", "unit": "mm"}]}	\N
123	应变计算应力	σ=Eε	\N	[{"name": "E", "unit": "MPa", "alias": "弹性模量(MPa)"}]	{"input": ["ε"], "output": ["σ"]}	σ=ε*0.000001*E	{"input": [{"name": "ε", "unit": "με"}], "output": [{"name": "σ", "unit": "MPa"}]}	\N
201	激光测距	Δh=(len0-leni)*H/len0	\N	[{"name": "len0", "unit": "m", "alias": "初始位置(m)"}, {"name": "H", "unit": "m", "alias": "设备高程(m)"}]	{"input": ["leni"], "output": ["Δh"]}	Δh=(len0*1000-abs(leni))*H/len0	{"input": [{"name": "leni", "unit": "mm"}], "output": [{"name": "Δh", "unit": "mm"}]}	\N
207	应变花计算公式	Sr=1/2*E+1/(2*(1-μ))|Sr=1/3*E+1/(3*(1-μ))|Sr=1/4*E+1/(2*(1-μ))|Sr=1/2*E+4/(3*(1-μ))	需要配置3个关联传感器，安装位置对应的角度分别为0度，45度，90度	[{"name": "E", "alias": "弹性模量"}, {"name": "μ", "alias": "泊松比"}, {"name": "shape", "type": "enum", "alias": "应变花类型", "range": ["三片直角形", "三片等角形", "四片直角形", "T-△形"]}]	{"input": ["εi"], "output": ["σ", "ε", "α"]}	\N	{"input": [{"name": "εi"}], "output": [{"name": "σ"}, {"name": "ε"}, {"name": "α"}]}	\N
121	测斜垂直方向位移计算	Δl=c*[sin(αi)-sin(α0)]	工讯定制	[{"name": "xα0", "alias": "x方向角度初值(°)"}, {"name": "yα0", "alias": "y方向角度初值(°)"}, {"name": "c", "alias": "初始高(m)"}]	{"input": ["αx", "αy"], "output": ["x", "y"]}	x=c*1000*(sin(αx*π/180)-sin(xα0*π/180));y=c*1000*(sin(αy*π/180)-sin(yα0*π/180))	{"input": [{"name": "αx", "unit": "°"}, {"name": "αy", "unit": "°"}], "output": [{"name": "x", "unit": "mm"}, {"name": "y", "unit": "mm"}]}	\N
211	应变计计算钢筋混凝土支撑轴力	N=(Ec*Ac+Es*As)*ε;ε=AVG(εi);As=SUM(Ai)	\N	[{"name": "Ac", "alias": "混凝土截面积(mm^2)"}, {"name": "Ec", "alias": "混凝土弹性模量(kN/mm^2)"}, {"name": "Ai", "alias": "钢筋计截面积(mm^2)"}, {"name": "Es", "alias": "钢筋弹性模量(kN/mm^2)"}]	{"input": ["εi"], "output": ["N"]}	N=(Ec*Ac+Es*As)*ε;ε=AVG(εi);As=SUM(Ai)	{"input": [{"name": "εi"}], "output": [{"name": "N"}]}	\N
110	流量计算	Qi=vi*Δt	\N	[]	{"input": ["vi"], "output": ["Qi"]}	Qi=vi*Δt	{"input": [{"name": "vi", "unit": "m/s"}], "output": [{"name": "Qi", "unit": "m³"}]}	\N
112	库容计算	V=ax³+bx²+cx+d	\N	[{"name": "a", "alias": "3次项系数"}, {"name": "b", "alias": "2次项系数"}, {"name": "c", "alias": "1次项系数"}, {"name": "d", "alias": "常数项"}]	{"input": ["x"], "output": ["V"]}	V=a*x^3+b*x^2+c*x+d	{"input": [{"name": "x", "unit": "m"}], "output": [{"name": "V", "unit": "m³"}]}	\N
136	出水量计算	E=f(p)	\N	[]	{"input": ["p"], "output": ["E"]}	\N	{"input": [{"name": "p", "unit": "kPa"}], "output": [{"name": "E", "unit": "m^3/s"}]}	\N
137	三角堰经验公式	Q=C*(H-h1)^(5/2)	\N	[{"name": "h1", "unit": "cm", "alias": "传感器至三角堰下豁口高差(cm)"}]	{"input": ["H"], "output": ["Q"]}	\N	{"input": [{"name": "H", "unit": "cm"}], "output": [{"name": "Q", "unit": "L/s"}]}	\N
208	进水量计算	Qi=V_i - V_i_1 + Qo	\N	[]	{"input": ["Qo", "V_i"], "output": ["Qi"]}	Qi=V_i - V_i_1 + Qo	{"output": [{"name": "Qi", "unit": "m³"}]}	\N
138	三角堰经验公式(C)	Q=C*(H-h1)^(5/2)	\N	[{"name": "h1", "unit": "cm", "alias": "传感器至三角堰下豁口高差(cm)"}, {"name": "C", "unit": "", "alias": "系数"}]	{"input": ["H"], "output": ["Q"]}	Q=C*(H-h1)^(5/2)	{"input": [{"name": "H", "unit": "cm"}], "output": [{"name": "Q", "unit": "L/s"}]}	\N
139	减初值公式	X=xi-x0;Y=yi-y0;Z=zi-z0	\N	[{"name": "x0", "unit": "mm", "alias": "x方向初值(mm)"}, {"name": "y0", "unit": "mm", "alias": "y方向初值(mm)"}, {"name": "z0", "unit": "mm", "alias": "z方向初值(mm)"}]	{"input": ["xi", "yi", "zi"], "output": ["X", "Y", "Z"]}	X=xi-x0;Y=yi-y0;Z=zi-z0	{"input": [{"name": "xi", "unit": "mm"}, {"name": "yi", "unit": "mm"}, {"name": "zi", "unit": "mm"}], "output": [{"name": "X", "unit": "mm"}, {"name": "Y", "unit": "mm"}, {"name": "Z", "unit": "mm"}]}	\N
133	排放量计算公式	P=Q*C/1e6	\N	[]	{"input": ["Qn", "Qh", "Qv", "Qo", "C"], "output": ["Pn", "Ph", "Pv", "Po"]}	Pn=Qn*C/1e3;Ph=Qh*C/1e3;Pv=Qv*C/1e3;Po=Qo;	{"input": [{"name": "Qn", "unit": "ppm"}, {"name": "Qh", "unit": "ppm"}, {"name": "Qv", "unit": "ppm"}, {"name": "Qo", "unit": ""}, {"name": "C", "unit": ""}], "output": [{"name": "Pn", "unit": "g/h"}, {"name": "Ph", "unit": "g/h"}, {"name": "Pv", "unit": "g/h"}, {"name": "Po", "unit": ""}]}	{"type": "combine"}
135	力转应力(kN/mm^2)	σ=F/A	NULL	[{"name": "A", "unit": "mm^2", "alias": "钢筋计有效面积(mm^2)"}]	{"input": ["F"], "output": ["σ"]}	σ=F/A;Ai=A	{"input": [{"name": "F", "unit": "kN"}], "output": [{"name": "σ", "unit": "kN/mm^2"}, {"name": "Ai", "unit": "mm^2"}]}	\N
204	支撑轴力计算	Nc=δ(Ec*Ac/Ei+Ai),δ=(∑[k*(fi^2-f0^2)/Aj])/n	\N	[{"name": "Ec", "alias": "混凝土弹性模量(kN/mm^2)"}, {"name": "Es", "alias": "钢筋弹性模量(kN/mm^2)"}, {"name": "Ac", "alias": "混凝土净截面面积(mm^2)"}, {"name": "As", "alias": "钢筋总面积(mm^2)"}]	{"input": ["δi"], "output": ["Nc"]}	Nc=δ(Ec*Ac/Es+As),δ=AVG(δi)	{"input": [{"name": "δi", "unit": "kN/mm^2"}], "output": [{"name": "Nc", "unit": "kN"}]}	\N
216	管道轴向应力	σL=σt+σp+σe+σb	配置3个传感器,第一个代表L(9点钟)方向,第二个代表U(12点钟)方向,第三个代表R(3点钟)方向	[{"name": "E", "alias": "钢材弹性模量(GPa)"}, {"name": "σp", "alias": "内压波桑应力(MPa)"}]	{"input": ["v"], "output": ["σL"]}	\N	{"input": [{"name": "v", "unit": "uε"}], "output": [{"name": "σL", "unit": "MPa"}]}	\N
217	应变计计算轴力(组合)	F=A*E*[(∑εi)/n]+F0	\N	[{"name": "E", "unit": "kN/mm^2", "alias": "钢材弹性模量(kN/mm^2)"}, {"name": "A", "unit": "mm^2", "alias": "钢材截面积(mm^2)"}, {"name": "F0", "unit": "kN", "alias": "初值(kN)", "default": 0.0}]	{"input": ["εi"], "output": ["F"]}	F=ε*1e-6*E*A+F0,ε=AVG(εi)	{"input": [{"name": "εi", "unit": "με"}], "output": [{"name": "F", "unit": "kN"}]}	\N
218	钢筋混凝土支撑轴力计算	Nc=[δ(Ec*Ac/Ei+Ai)]/(Ai/n)，δ=(∑δi)/n	\N	[{"name": "Ec", "alias": "混凝土弹性模量(kN/mm^2)"}, {"name": "Ei", "alias": "钢筋弹性模量(kN/mm^2)"}, {"name": "Ac", "alias": "混凝土净截面面积(mm^2)"}, {"name": "Ai", "alias": "钢筋总面积(mm^2)"}, {"name": "n", "alias": "钢筋个数"}]	{"input": ["δi"], "output": ["Nc"]}	Nc=δ(Ec*Ac/Ei+Ai)/(Ai/n),δ=AVG(δi)	{"input": [{"name": "δi", "unit": "kN"}], "output": [{"name": "Nc", "unit": "kN"}]}	\N
140	轨心距计算公式	L=(X0*S1)/S-l+L0	\N	[{"name": "X0", "unit": "mm", "alias": "轨腰中点到设备安装点的水平距离X0(mm)"}, {"name": "S", "unit": "mm", "alias": "轨腰中点到设备安装点的距离S(mm)"}, {"name": "l", "unit": "mm", "alias": "帽沿宽度l(mm)"}, {"name": "L0", "unit": "mm", "alias": "轨距的一半L0(mm)"}]	{"input": ["S1"], "output": ["L"]}	L=(X0*S1)/S-l+L0	{"input": [{"name": "S1", "unit": "mm"}], "output": [{"name": "L", "unit": "mm"}]}	\N
141	振动等效声级计算	phy={soundLevel,arrAcc}	\N	[]	{"input": [""], "output": [""]}	\N	\N	\N
220	支撑轴力计算(温度平均)	Nc=δ(Ec*Ac/Ei+Ai),δ=(∑[k*(fi^2-f0^2)/Aj])/n;Δt=Δt,Δt=AVG(tv)	\N	[{"name": "Ec", "alias": "混凝土弹性模量(kN/mm^2)"}, {"name": "Es", "alias": "钢筋弹性模量(kN/mm^2)"}, {"name": "Ac", "alias": "混凝土净截面面积(mm^2)"}, {"name": "As", "alias": "钢筋总面积(mm^2)"}]	{"input": ["δi", "tv"], "output": ["Nc", "Δt"]}	Nc=δ(Ec*Ac/Es+As),δ=AVG(δi),Δt=AVG(tv)	{"input": [{"name": "δi", "unit": "kN/mm^2"}, {"name": "tv"}], "output": [{"name": "Nc", "unit": "kN"}, {"name": "Δt"}]}	\N
142	空气数据修正公式	V=k*x+c	\N	[{"name": "k_no2", "alias": "no2修正系数", "default": 1}, {"name": "c_no2", "alias": "no2修正常数项", "default": 0}, {"name": "k_so2", "alias": "so2修正系数", "default": 1}, {"name": "c_so2", "alias": "so2修正常数项", "default": 0}, {"name": "k_o3", "alias": "o3修正系数", "default": 1}, {"name": "c_o3", "alias": "o3修正常数项", "default": 0}, {"name": "k_co", "alias": "co修正系数", "default": 1}, {"name": "c_co", "alias": "co修正常数项", "default": 0}]	{"input": ["no2", "so2", "o3", "co"], "output": ["v_no2", "v_so2", "v_o3", "v_co"]}	v_no2=k_no2*no2+c_no2;v_so2=k_so2*so2+c_so2;v_o3=k_o3*o3+c_o3;v_co=k_co*co+c_co;	{"input": [{"name": "no2"}, {"name": "so2"}, {"name": "o3"}, {"name": "co"}], "output": [{"name": "v_no2"}, {"name": "v_so2"}, {"name": "v_o3"}, {"name": "v_co"}]}	\N
144	水位插值计算	Δh=(Pi-P0)/(ρ*g)+H0;V=(V2-V1)/(h2-h1)*(Δh-h1)+V1	\N	[{"name": "ρ", "unit": "10^3kg/m^3", "alias": "密度(10^3kg/m^3)"}, {"name": "P0", "unit": "kPa", "alias": "压强初值(kPa)"}, {"name": "H0", "unit": "m", "alias": "安装高程(m)"}, {"name": "_index", "alias": "插值队列索引"}]	{"input": ["Pi"], "output": ["V"]}	Δh=(Pi-P0)/(ρ*g)+H0;V=(V2-V1)/(h2-h1)*(Δh-h1)+V1	{"input": [{"name": "Pi", "unit": "KPa"}], "output": [{"name": "V"}]}	\N
145	昊胜静力水准仪沉降计算	ΔH=(H-h0)/ρ	\N	[{"name": "ρ", "unit": "", "alias": "防冻液密度和水密度的比值"}, {"name": "h0", "unit": "mm", "alias": "初始值(mm)"}]	{"input": ["H"], "output": ["ΔH"]}	ΔH=(H-h0)/ρ	{"input": [{"name": "H", "unit": "mm"}], "output": [{"name": "ΔH", "unit": "mm"}]}	\N
222	三向振动极值	x=pv(x);y=pv(y);z=pv(z);	\N	[]	{"input": [""], "output": [""]}	\N	\N	\N
147	三向测斜公式	Δl=c*[sin(αi)-sin(α0)]	\N	[{"name": "c", "unit": "mm", "alias": "杆间距离(mm)"}, {"name": "xα0", "unit": "°", "alias": "x方向角度初值(°)"}, {"name": "yα0", "unit": "°", "alias": "y方向角度初值(°)"}, {"name": "zα0", "unit": "°", "alias": "z方向角度初值(°)"}]	{"input": ["αx", "αy", "αz"], "output": ["x", "y", "z"]}	x=c*(sin(αx*π/180)-sin(xα0*π/180));y=c*(sin(αy*π/180)-sin(yα0*π/180));z=c*(sin(αz*π/180)-sin(zα0*π/180))	{"input": [{"name": "αx", "unit": "°"}, {"name": "αy", "unit": "°"}, {"name": "αz", "unit": "°"}], "output": [{"name": "x", "unit": "mm"}, {"name": "y", "unit": "mm"}, {"name": "z", "unit": "mm"}]}	\N
148	动应变计算公式	r=(i-p)*u/d	动应变计算公式	[{"name": "u", "unit": "mV/V", "alias": "灵敏度系数"}, {"name": "d", "unit": "V", "alias": "供电电压"}, {"name": "p", "unit": "mV", "alias": "原始电压值"}]	{"input": ["i"], "output": ["r"]}	r=(i-p)*u/d	{"input": [{"name": "i", "unit": "mV"}], "output": [{"name": "r"}]}	\N
150	水位系数公式	H=h/ρ+h0	\N	[{"name": "h0", "alias": "传感器安装高度(mm)"}, {"name": "ρ", "alias": "计算系数"}]	{"input": ["h"], "output": ["H"]}	H=h/ρ+h0	{"input": [{"name": "h", "unit": "mm"}], "output": [{"name": "H", "unit": "mm"}]}	\N
\.


--
-- Data for Name: t_factor_proto_device; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_factor_proto_device (id, proto, iota_product_code, formula, fields, multi, multi_formula, multi_fields, input_unitconvert) FROM stdin;
1	1004	3bf186e9-5049-40e4-ba57-b40d90cd1543	\N	{"temp": "temperature"}	f	\N	\N	\N
2	4006	d3245ff1-0781-49bd-b37c-e245a350a709	101	{"x": "angle", "angleX": "xi"}	f	\N	\N	\N
5	4007	1c210656-dc67-470f-b8c3-d653c82e3bb0	101	{"angleX": "xi", "angleY": "yi"}	f	\N	\N	\N
6	4005	c094bbbe-bc2a-4223-bba7-539edb03d3b0	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
7	4007	c094bbbe-bc2a-4223-bba7-539edb03d3b0	101	{"angleX": "xi", "angleY": "yi"}	f	\N	\N	\N
8	4005	d32b2513-a8bb-465c-aabf-0832f355ef6b	102	{"AngleX": "αx", "AngleY": "αy"}	f	\N	\N	\N
9	4007	d32b2513-a8bb-465c-aabf-0832f355ef6b	101	{"AngleX": "xi", "AngleY": "yi"}	f	\N	\N	\N
10	4007	7e6111e8-0a68-4af8-92ae-6238b7f3c631	101	{"angleX": "xi", "angleY": "yi"}	f	\N	\N	\N
11	1002	6f16c6fa-6d60-481b-95ec-e450227fe268	\N	{"humi": "humidity", "temp": "temperature"}	f	\N	\N	\N
12	1004	6f16c6fa-6d60-481b-95ec-e450227fe268	\N	{"temp": "temperature"}	f	\N	\N	\N
13	1006	6f16c6fa-6d60-481b-95ec-e450227fe268	\N	{"humi": "humidity"}	f	\N	\N	\N
14	4001	eb1c1781-cea9-411f-8c15-39aafc8ee62c	104	{"Δh": "displacement", "Pressure": "Pi"}	f	\N	\N	\N
15	4009	0357e07d-3afb-4d4b-b196-766688a5b2b2	117	{"phy": "expansion", "elongationIndicator": "DAQi"}	f	\N	\N	\N
19	1022	d523046b-7e32-486b-a1ab-cac779eb6209	\N	{"windSpeed": "speed"}	f	\N	\N	\N
21	1007	a8a32974-fa53-4e18-a264-58c885d3c409	\N	{"noise": "soundLevel"}	f	\N	\N	\N
22	4001	65bd339b-0469-4019-8c96-55a6dbc6b697	101	{"length": "displacement"}	f	\N	\N	\N
23	1003	003540d0-616c-4611-92c1-1cd31005eabf	\N	{"rainFall": "rainfall"}	f	\N	\N	\N
24	1002	c7528fab-94f4-4110-9aaf-8964afa09c20	\N	{"humi": "humidity", "temp": "temperature"}	f	\N	\N	\N
25	1004	c7528fab-94f4-4110-9aaf-8964afa09c20	\N	{"temp": "temperature"}	f	\N	\N	\N
26	1006	c7528fab-94f4-4110-9aaf-8964afa09c20	\N	{"humi": "humidity"}	f	\N	\N	\N
30	4005	ae93a369-2ef8-4e20-83d6-d2f89076b115	102	{"xDegree": "αx", "yDegree": "αy"}	f	\N	\N	\N
31	4007	ae93a369-2ef8-4e20-83d6-d2f89076b115	101	{"xDegree": "xi", "yDegree": "yi"}	f	\N	\N	\N
35	1002	f672fbb3-ce35-4c54-8e37-b50ce49c8978	\N	{"Hum": "humidity", "Temp": "temperature"}	f	\N	\N	\N
36	1004	f672fbb3-ce35-4c54-8e37-b50ce49c8978	\N	{"Temp": "temperature"}	f	\N	\N	\N
37	1006	f672fbb3-ce35-4c54-8e37-b50ce49c8978	\N	{"Hum": "humidity"}	f	\N	\N	\N
38	4001	584a210b-20f2-49cf-906a-9d6b4883af09	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
39	4004	584a210b-20f2-49cf-906a-9d6b4883af09	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
40	3001	abd08d4d-9de2-4f58-88be-94ec9aff0304	\N	{"force": "strain"}	f	\N	\N	\N
41	4008	a0bf9003-9dbd-4cc7-8bea-7da81ce69f32	116	{"phy": "crack", "elongationIndicator": "DAQi"}	f	\N	\N	\N
42	4009	a0bf9003-9dbd-4cc7-8bea-7da81ce69f32	116	{"phy": "expansion", "elongationIndicator": "DAQi"}	f	\N	\N	\N
43	4008	2bee8b28-3a7d-4a6d-96e7-e81b94afa48c	117	{"phy": "crack", "elongationIndicator": "DAQi"}	f	\N	\N	\N
44	4009	2bee8b28-3a7d-4a6d-96e7-e81b94afa48c	117	{"phy": "expansion", "elongationIndicator": "DAQi"}	f	\N	\N	\N
45	1001	1d4b6c8a-8a37-4ba0-9612-ad63ea6f1f3a	\N	{"windSpeed": "speed", "windDirection": "direction"}	f	\N	\N	\N
46	1022	1d4b6c8a-8a37-4ba0-9612-ad63ea6f1f3a	\N	{"windSpeed": "speed"}	f	\N	\N	\N
50	4001	0a25e0b7-784b-46fb-8fa3-d1a99593f343	111	{"phy": "displacement", "length": "Ci"}	f	\N	{}	\N
51	4011	0a25e0b7-784b-46fb-8fa3-d1a99593f343	\N	\N	f	\N	\N	\N
52	4005	28abcb7f-eb40-406b-a798-fc280b30638e	102	{"xDegree": "αx", "yDegree": "αy"}	f	\N	\N	\N
53	4007	28abcb7f-eb40-406b-a798-fc280b30638e	101	{"xDegree": "xi", "yDegree": "yi"}	f	\N	\N	\N
54	4005	3e462bff-8f09-4e70-90e3-231a08906309	102	{"xDegree": "αx", "YyDegree": "αy"}	f	\N	\N	\N
55	4007	3e462bff-8f09-4e70-90e3-231a08906309	101	{"xDegree": "xi", "YyDegree": "yi"}	f	\N	\N	\N
56	1002	b3f251c1-ab5e-4427-8b38-9180d6544783	\N	{"temp": "temperature", "humid": "humidity"}	f	\N	\N	\N
57	1004	b3f251c1-ab5e-4427-8b38-9180d6544783	\N	{"temp": "temperature"}	f	\N	\N	\N
58	1006	b3f251c1-ab5e-4427-8b38-9180d6544783	\N	{"humid": "humidity"}	f	\N	\N	\N
59	1004	193a9dcf-959d-4cd5-a186-637c11ae97a0	\N	{"temp": "temperature"}	f	\N	\N	\N
69	1004	131c98fc-2216-4f0f-9cd3-581d88f9affd	\N	{"temp": "temperature"}	f	\N	\N	\N
70	1006	131c98fc-2216-4f0f-9cd3-581d88f9affd	\N	{"humid": "humidity"}	f	\N	\N	\N
71	4001	38d818a3-1e2d-42bd-af74-e6ed5fe0c8fd	119	{"Δh": "displacement", "length": "Li"}	f	\N	\N	\N
72	1004	be246ea1-fd75-4151-92c6-54b278d11287	\N	{"temp": "temperature"}	f	\N	\N	\N
73	1002	34e17d2c-cfa7-42a7-88d0-fc64f13f68c2	\N	{"Hum": "humidity", "Temp": "temperature"}	f	\N	\N	\N
74	1004	34e17d2c-cfa7-42a7-88d0-fc64f13f68c2	\N	{"Temp": "temperature"}	f	\N	\N	\N
75	1006	34e17d2c-cfa7-42a7-88d0-fc64f13f68c2	\N	{"Hum": "humidity"}	f	\N	\N	\N
76	2004	002f9d36-6c13-406f-aa9d-c1c53e4c0d50	\N	{}	t	204	{"Nc": "force", "force": "δi"}	\N
78	4007	c52cea56-d5aa-4b14-ad9f-05fb6974e528	\N	{"xDegree": "x", "yDegree": "y"}	f	\N	\N	\N
79	4007	43e2a07a-c33e-4e54-ba5e-0a948ae4ba61	\N	{"xDegree": "x", "yDegree": "y"}	f	\N	\N	\N
80	1002	8ae3c80d-72ae-4e4f-b6e7-fd2dda6cc125	\N	{"humidity": "humidity", "temperature": "temperature"}	f	\N	\N	\N
81	1012	8ae3c80d-72ae-4e4f-b6e7-fd2dda6cc125	\N	{"pressure": "pressure"}	f	\N	\N	\N
82	1026	3f80f427-4615-44ae-b2e8-e783733d0ea5	\N	{"value": "concentration"}	f	\N	\N	\N
87	4007	96870c78-2ed9-4141-9438-e9415cd6eeb8	\N	{"xDegree": "x", "yDegree": "y"}	f	\N	\N	\N
94	4001	701ab719-e85b-4428-ad59-1b7adff31c56	117	{"phy": "displacement", "settlement": "DAQi"}	f	\N	\N	\N
66	2001	870242c3-963d-417d-85fa-21add06c9e0a	\N	{"cableforce": "cableForce"}	f	\N	\N	\N
16	1001	fd8e5a82-2b93-4d83-9132-4666b974079d	\N	{"windSpeed": "speed", "windDirection": "direction"}	f	\N	\N	\N
27	1002	497ca51c-dd0a-46cb-8651-ac4bb7bd45c0	\N	{"hum": "humidity", "temp": "temperature"}	f	\N	\N	\N
28	1004	497ca51c-dd0a-46cb-8651-ac4bb7bd45c0	\N	{"temp": "temperature"}	f	\N	\N	\N
29	1006	497ca51c-dd0a-46cb-8651-ac4bb7bd45c0	\N	{"hum": "humidity"}	f	\N	\N	\N
17	1022	fd8e5a82-2b93-4d83-9132-4666b974079d	\N	{"windSpeed": "speed"}	f	\N	\N	\N
18	4001	e833a38c-2409-474d-8d23-86ff4d45b199	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
33	4005	77d3bafd-4986-4848-b3c9-dfe847c6750e	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
34	4007	77d3bafd-4986-4848-b3c9-dfe847c6750e	101	{"angleX": "xi", "angleY": "yi"}	f	\N	\N	\N
68	1002	131c98fc-2216-4f0f-9cd3-581d88f9affd	\N	{"humidity": "humidity", "temperature": "temperature"}	f	\N	\N	\N
67	3001	9110f259-e269-446d-afa3-798069f4534d	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
47	4001	c9946e27-bce7-41eb-b341-d6b03a7f115f	102	{"x": "displacement", "anglex": "αx"}	f	\N	\N	\N
48	4005	c9946e27-bce7-41eb-b341-d6b03a7f115f	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
63	4006	9e8050a9-f38a-45c3-a02b-40670bdf19b7	\N	{"anglex": "angle"}	f	\N	\N	\N
62	4005	9e8050a9-f38a-45c3-a02b-40670bdf19b7	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
60	4001	9e8050a9-f38a-45c3-a02b-40670bdf19b7	102	{"x": "displacement", "anglex": "αx"}	f	\N	\N	\N
49	4007	c9946e27-bce7-41eb-b341-d6b03a7f115f	101	{"anglex": "xi", "angley": "yi"}	f	\N	\N	\N
3	4005	fd3ad887-4a33-4d80-b3bb-d5d48ced0e7b	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
4	4007	fd3ad887-4a33-4d80-b3bb-d5d48ced0e7b	101	{"anglex": "xi", "angley": "yi"}	f	\N	\N	\N
83	1018	f86c7d29-f504-474d-8665-d484e5c41e8a	\N	{"co2": "concentration"}	f	\N	\N	\N
84	1020	cff552ac-d565-4a44-8400-e0f4382ce853	\N	{"illuminance": "lumen"}	f	\N	\N	\N
85	4007	dfbedf15-8cef-4760-9cad-efaab883db3d	\N	{"xDegree": "x", "yDegree": "y"}	f	\N	\N	\N
86	4002	409f2510-dd44-4990-b530-096bf2bcb592	\N	{"strain": "y", "displacement": "x"}	f	\N	\N	\N
88	1027	abb38d23-09f3-48fc-b9ee-4dfaf1db995b	\N	{"PM10": "pm10", "PM25": "pm25"}	f	\N	\N	\N
89	2003	6aa982a5-d7a3-48ee-b1dc-afe4686ce796	\N	{"force": "pressure"}	f	\N	\N	\N
90	1027	61db6668-b790-47e8-9429-55bfa4f98b90	\N	{"TSP": "suspended", "PM10": "pm10", "PM25": "pm25"}	f	\N	\N	\N
92	4004	4d48086d-804a-426d-9867-0e87efdc74fe	\N	{"settlement": "deflection"}	f	\N	\N	\N
93	4003	7776a9dc-8e14-417c-a5fe-4b1dd1c869d7	109	{"x": "x", "y": "y", "z": "z"}	f	\N	\N	\N
91	4001	4d48086d-804a-426d-9867-0e87efdc74fe	117	{"phy": "displacement", "settlement": "DAQi"}	f	\N	\N	\N
95	1027	57bf451a-e6f5-4df5-a4a7-c2c42a46546f	\N	{"PM10": "pm10", "PM25": "pm25"}	f	\N	\N	\N
97	1028	7c1b8df9-4088-4cc7-b07b-3299d827d7d0	\N	{"temp": "temp", "thickness": "thickness"}	f	\N	\N	\N
98	1017	9604d366-28f8-4291-a5bd-5d049b1e90eb	\N	{"concentration": "concentration"}	f	\N	\N	\N
99	1018	9604d366-28f8-4291-a5bd-5d049b1e90eb	\N	{"concentration": "concentration"}	f	\N	\N	\N
103	4007	7c4c667b-dbf0-4c9b-9d7d-7ad9b61b200e	\N	{"xDegree": "x", "yDegree": "y"}	f	\N	\N	\N
104	1005	8e782506-4bab-4798-9e24-315107e3cc15	\N	{"pressure": "waterLevel"}	f	\N	\N	\N
105	1014	d51cfe97-0f8a-4f38-95fb-34208b171056	\N	{"flow": "instant", "cumulant": "total"}	f	\N	\N	\N
106	1014	ab34de76-f758-4311-8bfc-dc7054a58ecf	\N	{"standardTotalFlow": "total", "standardInstanceFlow": "instant"}	f	\N	\N	\N
107	1020	05d70310-6689-4174-b4ae-274ab5e8f287	\N	{"illumination": "lumen"}	f	\N	\N	\N
108	1018	ed599be6-4811-4a09-a065-4b29586a4c00	\N	{"concentration": "concentration"}	f	\N	\N	\N
109	4008	e7a84149-53b0-4ba3-88e7-fe7e0e0f21d4	\N	{"lvdt": "crack"}	f	\N	\N	\N
111	4005	fb1119c8-c430-4066-9f02-60a558d92a68	102	{"y": "y", "phy": "αy"}	f	\N	\N	\N
110	4001	112843b4-e834-4892-9ef3-260fe3d90c24	116	{"phy": "displacement", "height": "DAQi"}	f	\N	\N	\N
113	3001	9e56c900-b85f-4abd-b53f-3162016875ad	\N	{"value1": "strain"}	f	\N	\N	\N
125	1005	d8860bee-374c-497a-a33a-258af59e3690	103	{"H": "waterLevel", "physicalvalue": "h"}	f	\N	\N	\N
115	4007	c02185df-1224-4e63-aab4-3d284c8bb526	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
116	4007	42fbfa5f-4ca7-4e1d-b42f-08f4f641657a	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
117	4007	e47f8159-ee4b-45c0-b827-30b69d0328d8	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
118	4007	ff38a597-0318-47bb-a647-5ad78dd2dca8	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
119	4007	addad535-5578-4010-9d74-dbeab2b9e9eb	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
120	4007	70177dd0-b5ab-45c0-8338-a6f69138f85f	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
121	4007	72b0bf25-78ae-4ab5-995b-c83cfbf52484	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
122	4007	0bae88b4-e518-4869-96ea-c833160a9914	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
123	4007	0d123bba-3d2e-4252-a27e-af567da8aca1	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
132	1004	22d007b2-5200-4bf6-85dc-c755a7a75bcf	\N	{"temperature": "temperature"}	f	\N	\N	\N
133	2002	6f1f679a-d9b7-4fe3-945d-8b83105284a8	\N	\N	f	\N	\N	\N
134	4007	fb1119c8-c430-4066-9f02-60a558d92a68	\N	\N	t	214	\N	\N
135	4010	77d3bafd-4986-4848-b3c9-dfe847c6750e	\N	\N	t	212	{"Ha": "a", "Hb": "b", "Hc": "c", "Hd": "d", "angX": "x", "angY": "y", "angleX": "θx", "angleY": "θy"}	\N
136	4010	28abcb7f-eb40-406b-a798-fc280b30638e	\N	\N	t	212	{"Ha": "a", "Hb": "b", "Hc": "c", "Hd": "d", "angX": "x", "angY": "y", "xDegree": "θx", "yDegree": "θy"}	\N
137	4001	ac32d002-0463-4bc7-a307-86236e6307a7	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
138	4004	ac32d002-0463-4bc7-a307-86236e6307a7	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
139	4001	0aae766a-5d82-479a-bd71-7eb1e0e4e20f	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
140	4004	0aae766a-5d82-479a-bd71-7eb1e0e4e20f	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
141	4001	91372b00-3bf7-4eb0-9495-ad544dfb04ca	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
142	4004	91372b00-3bf7-4eb0-9495-ad544dfb04ca	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
143	4001	e8d9a100-9650-4afc-a260-9c7bcdea9263	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
144	4004	e8d9a100-9650-4afc-a260-9c7bcdea9263	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
145	4001	f3ad3df8-e1ad-4e05-b479-185ac5ae8602	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
146	4004	f3ad3df8-e1ad-4e05-b479-185ac5ae8602	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
147	4001	0c5d070d-fb83-4f78-acc0-a0bd12be6cc2	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
148	4004	0c5d070d-fb83-4f78-acc0-a0bd12be6cc2	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
149	4001	13126536-b6af-48d0-b43e-25144b65dd8d	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
150	4004	13126536-b6af-48d0-b43e-25144b65dd8d	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
77	1002	e5b27a73-2d4c-4b53-8bcd-86583097a730	\N	{"humi": "humidity", "temp": "temperature"}	f	\N	\N	\N
151	4001	16ca7eed-6c64-4c4b-a495-6c5f785b86cd	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
152	4004	16ca7eed-6c64-4c4b-a495-6c5f785b86cd	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
153	4001	4d523084-bf91-421f-bafc-f278a63c5541	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
154	4004	4d523084-bf91-421f-bafc-f278a63c5541	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
96	4001	b56e401a-75e7-47ea-84db-6638fd421792	117	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
156	4007	ef4d9187-0ca8-44c7-b7f5-42e6c0904fd5	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
157	4007	79ef29a0-9796-43ce-957d-952d3b16d70a	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
158	4007	abefa36d-6587-4818-bb39-e14a51c26b4e	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
160	4006	ef4d9187-0ca8-44c7-b7f5-42e6c0904fd5	\N	{"angleX": "angle"}	f	\N	\N	\N
161	4006	79ef29a0-9796-43ce-957d-952d3b16d70a	\N	{"angleX": "angle"}	f	\N	\N	\N
162	4006	abefa36d-6587-4818-bb39-e14a51c26b4e	\N	{"angleX": "angle"}	f	\N	\N	\N
164	1002	ddf17ba9-fcef-4ef4-97f0-c09e0503dfa3	\N	{"humi": "humidity", "temp": "temperature"}	f	\N	\N	\N
165	4008	3eb1b2e4-ba3a-4329-a821-33a7f5bec873	117	{"phy": "crack", "value": "DAQi"}	f	\N	\N	\N
166	1002	85ba72e3-3754-4b11-a144-757d7a01f1dc	\N	{"temp": "temperature", "value": "humidity"}	f	\N	\N	\N
114	4001	1f00228f-9138-4060-9b9b-1ae22f803af7	117	{"phy": "displacement", "level": "DAQi"}	f	\N	\N	\N
124	2003	660c0ba2-d714-4ad3-8166-a1fa25a9d7d1	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
112	3001	e8ccf6dc-5626-4bb7-9f88-9bf8972619b4	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
131	3001	d77b7e20-7877-47dc-aef4-37a663bac660	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
127	3001	17c35362-c638-46de-bea3-840893daf864	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
155	4008	10f69514-4a4b-4ecd-a318-f8bf0c81a965	\N	{"physicalvalue": "crack"}	f	\N	\N	\N
167	3001	70ed36c0-d58f-482d-8337-fafed8a2e6ac	100	{"phy": "strain", "value": "DAQi"}	f	\N	\N	\N
163	4006	c0b0b779-cafb-4d7f-b4ff-64534e422738	\N	{"anglex": "angle"}	f	\N	\N	\N
159	4007	c0b0b779-cafb-4d7f-b4ff-64534e422738	\N	{"anglex": "x", "angley": "y"}	f	\N	\N	\N
102	1004	235b7fe6-cf6f-4cf4-8d40-a3103cc0fba7	\N	{"physicalvalue": "temperature"}	f	\N	\N	\N
101	1012	dfffdb75-6ad1-4092-95d2-ac6596b3c4ce	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
130	2004	ecfacbbe-037c-42cb-89ce-68a2e6170758	\N	{}	t	214	\N	\N
168	4001	14f67669-6cec-42c0-a7ca-4b60950ec7b5	117	{"phy": "displacement", "value": "DAQi"}	f	\N	\N	\N
169	4001	e08c86d5-195d-4cf6-a1a5-1cfd113ddd52	117	{"phy": "displacement", "value": "DAQi"}	f	\N	\N	\N
170	4007	f5d141ad-ea96-4398-8712-2a802af988f8	\N	{"value": "x", "offsetValue": "y"}	f	\N	\N	\N
171	1005	931fef11-654a-4f36-bf37-dbc168c46e84	104	{"Δh": "waterLevel", "value": "Pi"}	f	\N	\N	\N
172	2003	931fef11-654a-4f36-bf37-dbc168c46e84	\N	{"value": "pressure"}	f	\N	\N	\N
173	2003	4d523084-bf91-421f-bafc-f278a63c5541	117	{"phy": "pressure", "pressure": "DAQi"}	f	\N	\N	\N
174	1022	745e1f26-ee66-45dd-9606-052a34a944fc	\N	{"windSpeed": "speed"}	f	\N	\N	\N
175	1018	67becf68-18c7-4ab3-83b2-d306f89bd25d	\N	{"smoke": "concentration"}	f	\N	\N	\N
176	4001	e58ee78a-e499-483c-acc8-a42683d62149	\N	{"phy": "displacement"}	f	\N	\N	\N
32	4001	f9cf9002-bdbd-458c-8534-37db6183e217	117	{"phy": "displacement", "distance": "DAQi"}	f	\N	\N	\N
178	4001	1c332609-ad1d-4066-b0fa-67df29181432	117	{"phy": "displacement", "distance": "DAQi"}	f	\N	\N	\N
179	2004	b1c85f0b-c610-4243-83a4-3a1e87b411ad	\N	{"phy": "force"}	f	\N	\N	\N
180	2004	f0b38ea6-f88e-4e79-b7bb-02d09ef2cf03	\N	{"phy": "force"}	f	\N	\N	\N
181	2004	92d06569-3e06-4ceb-91e5-d28589632145	\N	{"phy": "force"}	f	\N	\N	\N
235	2004	b77b1ad2-2546-4219-bbe8-dc6b71d7fe01	\N	{"physicalvalue": "force"}	f	\N	{}	\N
183	4011	1c332609-ad1d-4066-b0fa-67df29181432	117	{"phy": "displacement", "distance": "DAQi"}	f	\N	\N	\N
184	4001	d87be87a-12ba-4e65-97ba-816bcb3e2e62	\N	{"value": "displacement"}	f	\N	\N	\N
185	3001	c98659b5-30ec-471f-9654-41f5f8df47b0	\N	{"value": "strain"}	f	\N	\N	\N
186	4007	7fefd73e-8fd9-48a6-8d7a-76f5796a8197	\N	\N	t	214	{"value": "v"}	\N
187	4007	fdf34922-d64e-4616-9313-96d7d94b8412	\N	\N	t	214	{"value": "v"}	\N
188	1008	24b365fd-4e6e-4800-ad48-d3f082c9b2b8	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
189	1008	e015d9d3-542e-4d54-80c6-39db4ba20877	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
190	1008	65f4e736-8261-40cc-b3b8-948ab0e4252e	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
191	1008	6bd546bc-55b0-4ee4-8b58-34feec8cdb6c	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
192	1008	3462227d-e989-421c-9f48-c0ae7a573b78	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
193	1008	16ca7eed-6c64-4c4b-a495-6c5f785b86cd	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
194	1008	13126536-b6af-48d0-b43e-25144b65dd8d	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
195	1008	0c5d070d-fb83-4f78-acc0-a0bd12be6cc2	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
197	1008	e8d9a100-9650-4afc-a260-9c7bcdea9263	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
198	1008	d7912272-424d-4546-a3c1-43a24365dde0	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
199	1008	91372b00-3bf7-4eb0-9495-ad544dfb04ca	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
200	1008	0aae766a-5d82-479a-bd71-7eb1e0e4e20f	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
201	1008	ac32d002-0463-4bc7-a307-86236e6307a7	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
202	1008	584a210b-20f2-49cf-906a-9d6b4883af09	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
177	4004	d148ae2e-c0dd-4e57-a0e8-833d32107f31	100	{"phy": "deflection", "level": "DAQi"}	f	\N	\N	\N
204	4004	a8e0db23-0d35-4eb1-a5b8-deadd9c3d80d	117	{"phy": "deflection", "settlement": "DAQi"}	f	\N	\N	\N
208	1018	ad41eeec-8dff-4cbb-9a3a-8d42db92bca8	\N	{"concentration": "concentration"}	f	\N	\N	\N
209	1018	6bf32a53-c1d4-4014-b0b9-da1af43bda76	\N	{"concentration": "concentration"}	f	\N	\N	\N
210	1018	676795c3-0d71-441d-aa0e-62b82dff8193	\N	{"concentration": "concentration"}	f	\N	\N	\N
211	1018	ac8a15b2-1daa-48ce-b77f-52e2429c66bd	\N	{"concentration": "concentration"}	f	\N	\N	\N
212	1026	5e96e066-3520-443f-80a4-9a3a1a7badd6	\N	{"concentration": "concentration"}	f	\N	\N	\N
213	1026	2f8c4ab2-42a9-44d8-bd3d-cfa9d1f55252	\N	{"concentration": "concentration"}	f	\N	\N	\N
214	1004	1cdf6eb6-fcd9-4346-992d-6ddc41b956cf	\N	{"concentration": "temperature"}	f	\N	\N	\N
215	1006	3da31fde-9ea8-406f-9a1b-4a9932dbc2df	\N	{"concentration": "humidity"}	f	\N	\N	\N
216	1006	f55d7414-2db9-4c07-ad9b-34637318171e	\N	{"humi": "humidity"}	f	\N	\N	\N
217	1004	608c11f3-91d9-4d92-9459-a4f7eb20bf1d	\N	{"phy": "temperature"}	f	\N	\N	\N
218	3001	608c11f3-91d9-4d92-9459-a4f7eb20bf1d	\N	{"phy": "strain"}	f	\N	\N	\N
219	1004	947fdddf-6d80-4972-88cc-601559ca3458	\N	{"phy": "temperature"}	f	\N	\N	\N
220	3001	947fdddf-6d80-4972-88cc-601559ca3458	\N	{"phy": "strain"}	f	\N	\N	\N
221	4005	771be2fa-a2f9-4ba8-8c08-76b091627b87	102	{"xDegree": "αx", "yDegree": "αy"}	f	\N	\N	\N
222	1004	cb339f74-5895-4180-a0dc-a3cf12151b0b	\N	{"temp": "temperature"}	f	\N	\N	\N
225	4001	448efd11-ceec-4f64-93a0-ad7133e38b8d	\N	{"phy": "displacement"}	f	\N	\N	\N
227	4001	2e2456a6-9738-456c-abf1-94d5ebad124a	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
228	4001	0f4f59de-cde7-4aec-a402-703e5426bb76	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
229	4001	cef1d2a2-c44e-4143-84bd-2a65140e33d0	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
230	4001	9f610c4d-c4f6-4e5b-bafc-5fb720bd8ca8	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
231	3001	61165e71-48f1-4c09-835c-9b72dbc867b5	\N	{"force": "strain"}	f	\N	\N	\N
232	3001	5bac98f9-a11e-447c-a180-0f039480625e	\N	{"force": "strain"}	f	\N	\N	\N
233	3001	2e030981-497c-4ba5-9580-2438239e32bc	\N	{"force": "strain"}	f	\N	\N	\N
245	1005	157090bc-b53c-4ae3-94fc-4b3804ed6433	100	{"phy": "DAQi"}	f	\N	\N	\N
246	4007	684a2261-481c-4504-9f4b-665baf97aae6	\N	{"value1": "x", "value2": "y"}	f	\N	\N	\N
247	4005	684a2261-481c-4504-9f4b-665baf97aae6	102	{"value1": "αx", "value2": "αy"}	f	\N	\N	\N
248	1002	c36c08c3-4f22-474e-b748-c6c32288c802	\N	{"data1": "temperature", "data2": "humidity"}	f	\N	\N	\N
249	1002	2b6f224d-770e-41bc-b28b-5afbe3b213c4	\N	{"data1": "temperature", "data2": "humidity"}	f	\N	\N	\N
250	1022	09e8eef6-6b70-4cda-84c2-a7680f7a535f	\N	{"data2": "speed"}	f	\N	\N	\N
325	1002	2d16c6ea-ed14-4429-9fe7-88ca2e3cae4b	\N	{"temp": "temperature", "humidity": "humidity"}	f	\N	\N	\N
205	3001	cd2cc136-a81a-4c2d-a9cb-27fcb4b0aff3	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
224	2004	d14c6b02-4298-4713-b970-eba0aafee88b	113	{"F": "force", "physicalvalue": "ε"}	f	\N	\N	\N
223	4001	35d1f34b-ccac-4110-9bb6-7e0a3327ef18	\N	{"physicalvalue": "displacement"}	f	\N	\N	\N
234	2004	73a7b800-25d7-41ad-872d-96cc4f9430de	\N	{"physicalvalue": "force"}	f	\N	{}	\N
206	3001	11f0a3dc-13ad-4c40-ae16-1b2f1d139564	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
207	3001	13ee1f91-04cc-48af-820e-ffc0ed179b6c	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
412	1022	bfc79caf-826f-4f9d-a709-241529e118b5	\N	{"windSpeed": "speed"}	f	\N	\N	\N
203	4001	a8e0db23-0d35-4eb1-a5b8-deadd9c3d80d	117	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
196	1008	f3ad3df8-e1ad-4e05-b479-185ac5ae8602	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
226	4002	d32eacce-7db0-4c15-b17c-f1d870389c14	121	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
251	6001	2078f06f-be3c-4d10-90b1-200f3bdb00ae	\N	{"mainCurrt": "electricity", "mainSpeed": "rotateSpeed", "mainTorque": "torque", "mainWeight": "weight", "mainVoltage": "outputVoltage", "mainGVoltage": "busbarVoltage", "mainPosition": "location"}	f	\N	\N	\N
252	6002	2078f06f-be3c-4d10-90b1-200f3bdb00ae	\N	{"deputyWeight": "weight", "deputyPosition": "location"}	f	\N	\N	\N
253	6003	2078f06f-be3c-4d10-90b1-200f3bdb00ae	\N	{"lCarCurrt": "electricity", "lCarSpeed": "rotateSpeed", "lCarTorque": "torque", "lCarVoltage": "outputVoltage", "lCarGVoltage": "busbarVoltage", "lCarPosition": "location"}	f	\N	\N	\N
335	1004	b475bf8f-00a0-457f-ad96-95b187dba62f	\N	{"temp": "temperature"}	f	\N	\N	\N
336	1006	b475bf8f-00a0-457f-ad96-95b187dba62f	\N	{"humidity": "humidity"}	f	\N	\N	\N
254	6004	2078f06f-be3c-4d10-90b1-200f3bdb00ae	\N	{"sCarCurrt": "electricity", "sCarSpeed": "rotateSpeed", "sCarTorque": "torque", "sCarVoltage": "outputVoltage", "sCarGVoltage": "busbarVoltage", "sCarPosition": "location"}	f	\N	\N	\N
255	1002	5f908b85-0f3a-48c0-bc83-8e191731a754	\N	{"humi": "humidity", "temp": "temperature"}	f	\N	\N	\N
256	4011	38d818a3-1e2d-42bd-af74-e6ed5fe0c8fd	201	{"Δh": "displacement", "length": "leni"}	f	\N	\N	\N
263	2005	219cbb09-9c49-4167-846d-00a8bdfadb9a	\N	{"pressure": "gravity"}	f	\N	\N	\N
264	4001	24b365fd-4e6e-4800-ad48-d3f082c9b2b8	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
265	4004	24b365fd-4e6e-4800-ad48-d3f082c9b2b8	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
266	4001	e015d9d3-542e-4d54-80c6-39db4ba20877	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
267	4004	e015d9d3-542e-4d54-80c6-39db4ba20877	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
268	4001	65f4e736-8261-40cc-b3b8-948ab0e4252e	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
269	4004	65f4e736-8261-40cc-b3b8-948ab0e4252e	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
270	4001	6bd546bc-55b0-4ee4-8b58-34feec8cdb6c	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
271	4004	6bd546bc-55b0-4ee4-8b58-34feec8cdb6c	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
272	4001	3462227d-e989-421c-9f48-c0ae7a573b78	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
273	4004	3462227d-e989-421c-9f48-c0ae7a573b78	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
274	4001	d7912272-424d-4546-a3c1-43a24365dde0	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
275	4004	d7912272-424d-4546-a3c1-43a24365dde0	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
20	4001	5bc92012-60a1-48ac-840f-575cb4e94c48	100	{"phy": "displacement", "distance": "DAQi"}	f	\N	\N	\N
276	1013	8e782506-4bab-4798-9e24-315107e3cc15	\N	{"pressure": "liquidLevel"}	f	\N	\N	\N
278	4007	0c5bca0d-95b8-416e-865b-1f09bb49285f	101	{"xDegree": "xi", "yDegree": "yi"}	f	\N	\N	\N
279	4005	0c5bca0d-95b8-416e-865b-1f09bb49285f	102	{"xDegree": "αx", "yDegree": "αy"}	f	\N	\N	\N
280	1005	eccb6310-f340-4668-9469-3df210aa471d	\N	{"waterLevel": "waterLevel"}	f	\N	\N	\N
281	1005	6850f742-c5b7-4984-b1ef-d01b16015eb9	100	{"phy": "waterLevel", "waterLevel": "DAQi"}	f	\N	\N	\N
282	4004	6850f742-c5b7-4984-b1ef-d01b16015eb9	\N	{"waterLevel": "deflection"}	f	\N	\N	\N
283	1018	ac3a0caf-7018-44d2-9337-32c7194ec412	\N	{"concentration": "concentration"}	f	\N	\N	\N
284	1018	a96f169e-56b9-49c8-a5cd-caade25fbf14	\N	{"concentration": "concentration"}	f	\N	\N	\N
285	1018	3415a2e9-2c44-402f-872c-f0187cef058f	\N	{"concentration": "concentration"}	f	\N	\N	\N
286	4001	cdf69820-94cb-45a3-acfe-21aa83737595	100	{"phy": "displacement", "location1": "DAQi"}	f	\N	\N	\N
287	4004	cdf69820-94cb-45a3-acfe-21aa83737595	100	{"phy": "deflection", "location1": "DAQi"}	f	\N	\N	\N
288	4001	831ab1f7-fe76-4152-b7a0-3359bdf7c3bd	100	{"phy": "displacement", "Offset": "DAQi"}	f	\N	\N	\N
289	4004	831ab1f7-fe76-4152-b7a0-3359bdf7c3bd	100	{"phy": "deflection", "Offset": "DAQi"}	f	\N	\N	\N
290	4005	7e6111e8-0a68-4af8-92ae-6238b7f3c631	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
291	4002	7e6111e8-0a68-4af8-92ae-6238b7f3c631	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
292	2002	ca7ff65b-b5a0-49f3-ad0b-6821012604ce	\N	\N	f	\N	\N	\N
293	4008	fe65a1cd-2040-403c-bb6f-529d4063bc45	117	{"phy": "crack", "elongationIndicator": "DAQi"}	f	\N	\N	\N
294	4008	f2c96428-649e-47e9-9b6f-e5749195cb33	117	{"phy": "crack", "elongationIndicator": "DAQi"}	f	\N	\N	\N
295	1004	8d1d1382-984f-4aa9-8e57-c2a2c21e0c06	\N	{"temp": "temperature"}	f	\N	\N	\N
296	1022	e2d93988-c0e0-4581-b406-e43e455f7864	\N	{"windSpeed": "speed"}	f	\N	\N	\N
297	4001	93f84dd4-087b-46ef-bdda-9db4adfdb16b	100	{"phy": "displacement", "liquidLevel": "DAQi"}	f	\N	\N	\N
298	4004	93f84dd4-087b-46ef-bdda-9db4adfdb16b	100	{"phy": "deflection", "liquidLevel": "DAQi"}	f	\N	\N	\N
299	4001	40b8c657-2644-4ce2-b490-cf61523a4012	\N	{"length": "displacement"}	f	\N	\N	\N
300	4001	e889420f-f8d0-4e0d-aab2-1f2f965e75bb	\N	{"length": "displacement"}	f	\N	\N	\N
301	4007	6c19e60e-0ed7-4e22-abb4-ddc9caf20d91	\N	{"angleX": "x", "angleY": "y"}	f	\N	\N	\N
302	4005	6c19e60e-0ed7-4e22-abb4-ddc9caf20d91	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
303	4002	6c19e60e-0ed7-4e22-abb4-ddc9caf20d91	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
304	1013	21d99b83-6a52-4465-90c4-125d8330e1c1	\N	{"level": "liquidLevel"}	f	\N	\N	\N
305	2003	aa86893b-e991-4c57-94a7-b29e7349fe50	\N	{"weight": "pressure"}	f	\N	\N	\N
306	4007	7118fecd-555d-4d6c-9b3a-63b6ed0d2a45	101	{"xDegree": "xi", "yDegree": "yi"}	f	\N	\N	\N
307	4007	183c2cd5-5a53-4985-80aa-33a6ce2f82d4	101	{"angleX": "xi", "angleY": "yi"}	f	\N	\N	\N
308	1016	5fcd559a-c3dc-4c38-acde-b4b1749b4ab3	\N	{"ph": "ph"}	f	\N	\N	\N
309	4007	ef2cc4b4-23d3-4ff0-981b-84a8c98113ab	101	{"angleX": "xi", "angleY": "yi"}	f	\N	\N	\N
310	4002	ef2cc4b4-23d3-4ff0-981b-84a8c98113ab	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
311	4005	ef2cc4b4-23d3-4ff0-981b-84a8c98113ab	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
312	4011	d2e5e59c-47f9-4eb9-98ce-c6dc6f2f0d66	119	{"Δh": "displacement", "distance": "Li"}	f	\N	\N	\N
313	4011	0fc23377-9f3d-4511-ab1b-8b8df0259d2f	119	{"Δh": "displacement", "distance": "Li"}	f	\N	\N	\N
238	1005	c9eacd36-38d6-48b9-9672-e76406906ea3	124	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
239	1005	91766d07-1ae8-4f40-9fed-0d9a21eaf6f3	104	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
242	1005	c66d4e20-81b0-4a5c-b2de-6dcf7023dd0d	104	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
243	1005	37c046eb-9a0e-49b0-95fb-f0128338f381	104	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
241	1005	cb4eb310-0876-492a-9e06-8cd0a5542c5b	104	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
314	4011	14bab7df-524d-4a64-a618-23d4ebcc9b5e	119	{"Δh": "displacement", "distance": "Li"}	f	\N	\N	\N
315	4011	efcb4c3e-fc6f-447b-8f73-3fdff1d77fc6	119	{"Δh": "displacement", "distance": "Li"}	f	\N	\N	\N
316	4011	4255e295-7830-45af-ab7c-44fee1668641	119	{"Δh": "displacement", "diatance": "Li"}	f	\N	\N	\N
317	4011	ceed540f-d7a3-48bc-b8d0-e861e21499a4	119	{"Δh": "displacement", "distance": "Li"}	f	\N	\N	\N
318	4011	31cb6c0b-e369-46b0-9be4-1de3737503fc	119	{"Δh": "displacement", "distance": "Li"}	f	\N	\N	\N
319	4011	ea797ffb-87b5-4e0a-8da4-7f627c347b2f	119	{"Δh": "displacement", "distance": "Li"}	f	\N	\N	\N
320	4011	8583cb29-4726-4532-9530-a5b338d3483c	119	{"Δh": "displacement", "distance": "Li"}	f	\N	\N	\N
321	4011	dc5bdee9-14f3-4040-ad1c-faf008358890	119	{"Δh": "displacement", "distance": "Li"}	f	\N	\N	\N
322	1014	ef629030-d691-43fa-b6b4-b1465e60dace	\N	{"totalFlow": "total", "transientFlow": "instant"}	f	\N	\N	\N
323	4009	24064f03-7c7e-493b-99f2-c926717d28fc	100	{"phy": "expansion", "elongationIndicator": "DAQi"}	f	\N	\N	\N
324	4008	24064f03-7c7e-493b-99f2-c926717d28fc	100	{"phy": "crack", "elongationIndicator": "DAQi"}	f	\N	\N	\N
258	2003	424f45f6-916c-4383-bce4-c71153f82e63	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
259	2003	780ffe7d-7369-4d2f-9184-32790466f2ba	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
260	2003	ccb72dc5-f9bc-424d-a3ec-e6e9121bc534	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
261	2003	d2a5375c-0240-4435-9b8f-a62372fafaca	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
326	1004	2d16c6ea-ed14-4429-9fe7-88ca2e3cae4b	\N	{"temp": "temperature"}	f	\N	\N	\N
327	1006	2d16c6ea-ed14-4429-9fe7-88ca2e3cae4b	\N	{"humidity": "humidity"}	f	\N	\N	\N
328	1002	10018134-99f1-486e-8071-dc652f44d152	\N	{"temp": "temperature", "humidity": "humidity"}	f	\N	\N	\N
329	1004	10018134-99f1-486e-8071-dc652f44d152	\N	{"temp": "temperature"}	f	\N	\N	\N
330	1006	10018134-99f1-486e-8071-dc652f44d152	\N	{"humidity": "humidity"}	f	\N	\N	\N
331	1002	5cd62211-11dd-4deb-83bf-2873ae7dd42f	\N	{"temp": "temperature", "humidity": "humidity"}	f	\N	\N	\N
332	1004	5cd62211-11dd-4deb-83bf-2873ae7dd42f	\N	{"temp": "temperature"}	f	\N	\N	\N
333	1006	5cd62211-11dd-4deb-83bf-2873ae7dd42f	\N	{"humidity": "humidity"}	f	\N	\N	\N
334	1002	b475bf8f-00a0-457f-ad96-95b187dba62f	\N	{"temp": "temperature", "humidity": "humidity"}	f	\N	\N	\N
337	1002	63b7958b-9b1b-49ca-b01c-62ebe4df6376	\N	{"temp": "temperature", "humidity": "humidity"}	f	\N	\N	\N
338	1004	63b7958b-9b1b-49ca-b01c-62ebe4df6376	\N	{"temp": "temperature"}	f	\N	\N	\N
339	1006	63b7958b-9b1b-49ca-b01c-62ebe4df6376	\N	{"humidity": "humidity"}	f	\N	\N	\N
340	1002	41da65aa-dd1b-4a8f-8758-13f624e45dad	\N	{"temp": "temperature", "humidity": "humidity"}	f	\N	\N	\N
341	1004	41da65aa-dd1b-4a8f-8758-13f624e45dad	\N	{"temp": "temperature"}	f	\N	\N	\N
342	1006	41da65aa-dd1b-4a8f-8758-13f624e45dad	\N	{"humidity": "humidity"}	f	\N	\N	\N
343	1002	16f7e5ff-fb7a-4aa6-a701-9776f7638689	\N	{"temp": "temperature", "humidity": "humidity"}	f	\N	\N	\N
344	1004	16f7e5ff-fb7a-4aa6-a701-9776f7638689	\N	{"temp": "temperature"}	f	\N	\N	\N
345	1006	16f7e5ff-fb7a-4aa6-a701-9776f7638689	\N	{"humidity": "humidity"}	f	\N	\N	\N
346	4002	a30d283e-1af2-4531-ab6b-be1186799eea	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
347	4005	a30d283e-1af2-4531-ab6b-be1186799eea	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
348	4007	a30d283e-1af2-4531-ab6b-be1186799eea	101	{"angleX": "xi", "angleY": "yi"}	f	\N	\N	\N
349	1015	0eb7e920-0359-4b8b-b604-14bc1136e8f5	\N	{"turbidity": "corrosion"}	f	\N	\N	\N
350	1018	466241f9-ceea-4552-b9c6-114413124018	\N	{"concentration": "concentration"}	f	\N	\N	\N
351	1002	6af0f3be-6cb5-43c8-a588-490e10fdf4b7	\N	{"temp": "temperature", "humid": "humidity"}	f	\N	\N	\N
352	1004	6af0f3be-6cb5-43c8-a588-490e10fdf4b7	\N	{"temp": "temperature"}	f	\N	\N	\N
353	1006	6af0f3be-6cb5-43c8-a588-490e10fdf4b7	\N	{"humid": "humidity"}	f	\N	\N	\N
357	1009	0530f690-1f3c-430e-97c7-6dc82f96fd47	104	{"phy": "Pi", "Δh": "waterLevel"}	f	\N	\N	\N
363	1009	607fa5aa-d8d7-48be-bf60-b8a6d0de2e8e	104	{"phy": "Pi", "Δh": "waterLevel"}	f	\N	\N	\N
365	1009	49b0b2b7-b6e7-4ec8-adf8-4c94dcfb2eae	104	{"phy": "Pi", "Δh": "waterLevel"}	f	\N	\N	\N
367	2003	efc6301f-2fc6-4a50-bd12-7e8bc5781548	\N	{"force": "pressure"}	f	\N	\N	\N
368	2003	9cc32a4d-ed64-4c32-b842-9f26e1e8ed23	\N	{"force": "pressure"}	f	\N	\N	\N
369	2003	3373edde-44d6-4f67-b601-26c2259f2985	\N	{"force": "pressure"}	f	\N	\N	\N
370	2003	ef58c31b-1e6e-45a2-810e-2262ef946d6e	\N	{"force": "pressure"}	f	\N	\N	\N
371	2003	3789ab33-cabd-4aa8-95e4-ca757f9c6879	\N	{"force": "pressure"}	f	\N	\N	\N
372	3001	9abfc35c-6cff-489a-8257-b868954725f4	\N	{"phy": "strain"}	f	\N	\N	\N
377	3001	5267450d-6f94-457a-b539-4cc950707872	\N	{"force": "strain"}	f	\N	\N	\N
378	3001	84cbcd56-78c4-4ff3-9dbe-f21ac6c736ba	\N	{"force": "strain"}	f	\N	\N	\N
381	1004	bc476c11-0887-40fb-ae9e-06ab514a44c0	\N	{"temp": "temperature"}	f	\N	\N	\N
382	1006	bc476c11-0887-40fb-ae9e-06ab514a44c0	\N	{"humid": "humidity"}	f	\N	\N	\N
383	1002	bc476c11-0887-40fb-ae9e-06ab514a44c0	\N	{"temp": "temperature", "humid": "humidity"}	f	\N	\N	\N
384	1002	5c0f41c9-bbf5-416b-a77e-8fc5cabf06ed	\N	{"temp": "temperature", "humid": "humidity"}	f	\N	\N	\N
385	1004	5c0f41c9-bbf5-416b-a77e-8fc5cabf06ed	\N	{"temp": "temperature"}	f	\N	\N	\N
386	1006	5c0f41c9-bbf5-416b-a77e-8fc5cabf06ed	\N	{"humid": "humidity"}	f	\N	\N	\N
387	3001	5eb050b5-8b57-4528-adce-b3633e613b6c	\N	{"phy": "strain"}	f	\N	\N	\N
388	2003	7802bcc3-5fdb-441d-a57a-a89ca2ec158b	\N	{"phy": "pressure"}	f	\N	\N	\N
389	2004	d55af283-4d11-4eb7-8099-890d98bfcc0c	\N	{"phy": "force"}	f	\N	\N	\N
390	2003	223ac440-c7b0-4005-8144-f33ce926d9bf	\N	{"phy": "pressure"}	f	\N	\N	\N
391	2003	e3713c95-6aa3-4a2e-ad89-579a16cb1a03	\N	{"phy": "pressure"}	f	\N	\N	\N
392	4009	8e812d09-7b95-4c07-ad74-d4c66104e7a7	\N	{"phy": "expansion"}	f	\N	\N	\N
393	4008	8e812d09-7b95-4c07-ad74-d4c66104e7a7	\N	{"phy": "crack"}	f	\N	\N	\N
394	4008	3c8c9002-2d60-43f0-9a2c-52daa53cab54	\N	{"phy": "crack"}	f	\N	\N	\N
395	3001	5c18688a-731b-40d0-b4dd-4ba002026bb3	\N	{"phy": "strain"}	f	\N	\N	\N
396	3001	9bdf8d5c-e571-4dd4-9614-0099745b0a73	\N	{"phy": "strain"}	f	\N	\N	\N
398	3001	44c42c98-a486-411a-8813-c6ba48aab00c	\N	{"phy": "strain"}	f	\N	\N	\N
244	2003	1f3f14a2-a6d4-44a5-859b-3406794e7b37	\N	{"phy": "pressure"}	f	\N	\N	\N
399	4008	e55e2ee6-c58a-481c-9bd3-9df2b38dfa3f	\N	{"elongationIndicator": "crack"}	f	\N	\N	\N
400	4008	4253e350-b64f-4b81-b19b-bcd45c6181ad	\N	{"elongationIndicator": "crack"}	f	\N	\N	\N
402	4001	962c0a4a-535e-4f86-a25c-f38e3aa6f144	\N	{"phy": "displacement"}	f	\N	\N	\N
403	3001	f5f27d3f-b8fd-44ee-97e2-8a78748a424f	\N	{"phy": "strain"}	f	\N	\N	\N
404	2004	e2d104b1-9c57-4a16-8d05-07817bc8b785	\N	{"phy": "force"}	f	\N	\N	\N
405	4001	666e753c-f0b0-478d-b5f5-839117db13f9	119	{"Δh": "displacement", "lvdt": "Li"}	f	\N	\N	\N
406	4001	f9331a24-582f-45b8-bea8-b919ffd48516	119	{"Δh": "displacement", "lvdt": "Li"}	f	\N	\N	\N
407	4001	8ea772de-0c69-4a35-bbbb-7e0fb97d7c2f	119	{"Δh": "displacement", "lvdt": "Li"}	f	\N	\N	\N
408	4001	03db4d1f-c0bf-47b0-9f10-0a0a5d6cfca3	119	{"Δh": "displacement", "lvdt": "Li"}	f	\N	\N	\N
560	2004	df68d6a9-c963-4bc4-a122-332e3d1435ac	\N	{"physicalvalue": "force"}	f	\N	\N	\N
409	4001	d3ae39b6-419c-4d57-a353-69768f82908a	119	{"Δh": "displacement", "lvdt": "Li"}	f	\N	\N	\N
410	1022	f446b0ec-ee0f-40bb-a6fc-9767fbd78a2b	\N	{"windSpeed": "speed"}	f	\N	\N	\N
411	1022	de0bfd26-fb8e-4f9d-8e0a-0119650952c6	\N	{"windSpeed": "speed"}	f	\N	\N	\N
413	1004	a54c400e-8b31-47ec-9820-550d04916f47	\N	{"temp": "temperature"}	f	\N	\N	\N
373	2004	a306aea9-07ce-4e58-a228-bd9cc769f099	\N	\N	f	\N	{}	\N
374	2004	2ed7c823-4bfa-426a-92e3-08a05afc3017	\N	\N	f	\N	{}	\N
375	2004	3f953006-06c8-41a6-a6ae-55b9991e284b	\N	\N	f	\N	{}	\N
376	2004	147442dd-5edb-439c-aa56-d592cf1fa32f	\N	\N	f	\N	{}	\N
397	2004	f90de97b-b6e8-417a-b628-7b8e4bb9e335	\N	{"phy": "force"}	f	\N	{}	\N
366	1005	e6a3a1f5-2a8f-48a0-9758-407065bae1e9	\N	{"physicalvalue": "waterLevel"}	f	\N	\N	\N
364	1005	49b0b2b7-b6e7-4ec8-adf8-4c94dcfb2eae	104	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
362	1005	607fa5aa-d8d7-48be-bf60-b8a6d0de2e8e	104	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
356	1005	0530f690-1f3c-430e-97c7-6dc82f96fd47	104	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
358	2003	27f99320-b0dc-4b93-bc24-f5ccf9337356	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
354	3001	30da8546-87f0-4a5c-bd4f-f9919c954c82	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
359	4001	b750e865-af38-40e9-a478-16fefb4cb618	\N	{"physicalvalue": "displacement"}	f	\N	\N	\N
355	4008	feb1fe0d-208d-41cf-9533-596f78fa835c	\N	{"physicalvalue": "crack"}	f	\N	\N	\N
360	3001	5f4e4e99-20b3-4bf7-95cb-a2f507595b2d	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
380	4007	d32eacce-7db0-4c15-b17c-f1d870389c14	101	{"anglex": "xi", "angley": "yi"}	f	\N	\N	\N
100	1013	6039a6d8-af54-411e-a520-451b20b6d089	\N	{"physicalvalue": "liquidLevel"}	f	\N	\N	\N
379	3001	2d9520e9-143b-48c2-960f-5c9dca7a21b4	\N	{}	t	202	{"Δh": "strain", "physicalvalue": "pv"}	\N
414	1004	933a027b-e620-4a6e-8340-d10c7aa29009	\N	{"temp": "temperature"}	f	\N	\N	\N
415	4007	a3b4fd36-dd87-463c-84af-254647a24cc5	101	{"xDegree": "xi", "yDegree": "yi"}	f	\N	\N	\N
416	4007	e718c1a2-1c56-4da0-8cb3-36445c6b4f26	101	{"xDegree": "xi", "yDegree": "yi"}	f	\N	\N	\N
417	4007	c7f01571-7f09-4bef-99d3-fdc2da5fcaa2	101	{"xDegree": "xi", "yDegree": "yi"}	f	\N	\N	\N
418	1004	5f908b85-0f3a-48c0-bc83-8e191731a754	\N	{"temp": "temperature"}	f	\N	\N	\N
419	1006	5f908b85-0f3a-48c0-bc83-8e191731a754	\N	{"humi": "humidity"}	f	\N	\N	\N
422	1003	db974c14-3d61-403d-b847-e0523ad53964	\N	{"phy": "rainfall"}	f	\N	\N	\N
433	4001	38b81b7d-bb3e-4885-aaea-6035faf20d1b	\N	{"distance": "displacement"}	f	\N	\N	\N
434	4001	11a0df92-8921-470b-af9c-d7593b8b1f78	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
435	4004	11a0df92-8921-470b-af9c-d7593b8b1f78	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
436	4001	75c932d0-2df0-4628-81dd-0e9c1f11ff60	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
437	4004	75c932d0-2df0-4628-81dd-0e9c1f11ff60	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
438	4001	9b8ef29d-23a7-423f-9e4b-4a4fa9dbebec	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
439	4004	9b8ef29d-23a7-423f-9e4b-4a4fa9dbebec	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
440	4001	76288807-186e-4444-a1ce-6be599aacfd2	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
441	4004	76288807-186e-4444-a1ce-6be599aacfd2	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
442	1004	780de52c-47eb-46cb-b77b-3d919bae5ffb	\N	{"temp": "temperature"}	f	\N	\N	\N
182	4001	5ecfc751-afb0-4596-a6f7-85a31eca40c3	117	{"phy": "displacement", "level": "DAQi"}	f	\N	\N	\N
448	4006	7fefd73e-8fd9-48a6-8d7a-76f5796a8197	\N	{"value": "angle"}	f	\N	\N	\N
449	4001	9137c92c-6de6-4b00-bafc-a995288280f7	\N	{"value": "displacement"}	f	\N	\N	\N
450	4006	fdf34922-d64e-4616-9313-96d7d94b8412	\N	{"value": "angle"}	f	\N	\N	\N
451	4006	b53146b9-7737-46cd-a305-e2c9cb286d3d	\N	{"value": "angle"}	f	\N	\N	\N
452	4007	b53146b9-7737-46cd-a305-e2c9cb286d3d	\N	\N	t	214	{"value": "v"}	\N
453	4001	12adcb99-432b-46f5-9240-dad30ec75ea6	100	{"phy": "displacement", "lvdt": "DAQi"}	f	\N	\N	\N
454	4008	12adcb99-432b-46f5-9240-dad30ec75ea6	\N	{"lvdt": "crack"}	f	\N	\N	\N
455	4001	bcc5cadb-0395-464b-8ead-ac3917b49e30	100	{"phy": "displacement", "lvdt": "DAQi"}	f	\N	\N	\N
456	4008	bcc5cadb-0395-464b-8ead-ac3917b49e30	\N	{"lvdt": "crack"}	f	\N	\N	\N
457	4001	8e752366-9256-4bab-a79b-276a89aea484	100	{"phy": "displacement", "lvdt": "DAQi"}	f	\N	\N	\N
458	4008	8e752366-9256-4bab-a79b-276a89aea484	\N	{"lvdt": "crack"}	f	\N	\N	\N
459	4001	87bf38c3-0b08-4bcf-98b4-12060fd9a345	100	{"phy": "displacement", "lvdt": "DAQi"}	f	\N	\N	\N
461	4001	167d20c6-d128-4532-9974-d4a55788823e	100	{"phy": "displacement", "lvdt": "DAQi"}	f	\N	\N	\N
463	4001	10ac4010-ff56-4d05-9e45-55f84f4292aa	100	{"phy": "displacement", "lvdt": "DAQi"}	f	\N	\N	\N
464	4008	10ac4010-ff56-4d05-9e45-55f84f4292aa	\N	{"lvdt": "crack"}	f	\N	\N	\N
465	4001	1f16c362-1f8e-4cbc-8b2c-8f43dd306390	100	{"phy": "displacement", "lvdt": "DAQi"}	f	\N	\N	\N
466	4008	1f16c362-1f8e-4cbc-8b2c-8f43dd306390	\N	{"lvdt": "crack"}	f	\N	\N	\N
467	4001	8571c1b0-8472-45b5-955f-5a7614a2f08c	100	{"phy": "displacement", "lvdt": "DAQi"}	f	\N	\N	\N
468	4008	8571c1b0-8472-45b5-955f-5a7614a2f08c	\N	{"lvdt": "crack"}	f	\N	\N	\N
469	4001	a570a2de-ca66-488a-a078-6c6b14b71f2a	100	{"phy": "displacement", "lvdt": "DAQi"}	f	\N	\N	\N
470	4008	a570a2de-ca66-488a-a078-6c6b14b71f2a	\N	{"lvdt": "crack"}	f	\N	\N	\N
472	4008	d54f6d25-04dc-4847-8dda-9c54d54b2d8f	\N	{"lvdt": "crack"}	f	\N	\N	\N
473	4001	c69575ab-795c-45ec-8901-f370255beff1	\N	{"liquidLevel": "displacement"}	f	\N	\N	\N
475	4006	965b3938-ddd0-422d-9716-bdb2d44f8c56	\N	{"phy": "angle"}	f	\N	\N	\N
476	2004	68cb03f4-a381-4eaa-9068-d375ae3500e8	\N	{"phy": "force"}	f	\N	\N	\N
477	2004	3a8c62b6-14dc-497e-90e8-68c2160e7d08	\N	{"phy": "force"}	f	\N	\N	\N
129	2004	c50b3ecc-a416-4991-b64f-f2c79d8d1848	\N	{"physicalvalue": "force"}	f	\N	\N	\N
128	2004	abfa6634-cca0-4696-b67e-1c2eb2e57c9b	\N	{"physicalvalue": "force"}	f	\N	\N	\N
423	3001	4696ff30-0685-4f87-bc16-25d640a014a6	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
478	1002	b3b4f0f1-7cdc-4892-9e6a-f4936931472c	\N	{"humidity": "humidity", "temperature": "temperature"}	f	\N	\N	\N
479	4006	874e1ee5-94fe-49aa-94b0-6d6bfef680bc	\N	{"xDegree": "angle"}	f	\N	\N	\N
480	3001	1f6ae927-989f-48b3-9fa4-18518326953b	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
481	1001	4d5a3f58-0eda-4443-9dcc-c64bb1785d88	\N	{"speedofWind": "speed", "azimuthofWind": "direction"}	f	\N	\N	\N
482	1022	4d5a3f58-0eda-4443-9dcc-c64bb1785d88	\N	{"speedofWind": "speed"}	f	\N	\N	\N
483	1029	4d5a3f58-0eda-4443-9dcc-c64bb1785d88	\N	{"azimuthofWind": "direction"}	f	\N	\N	\N
484	4009	9137c92c-6de6-4b00-bafc-a995288280f7	\N	{"value": "expansion"}	f	\N	\N	\N
485	1005	e7a84149-53b0-4ba3-88e7-fe7e0e0f21d4	100	{"phy": "waterLevel", "lvdt": "DAQi"}	f	\N	\N	\N
471	4001	d54f6d25-04dc-4847-8dda-9c54d54b2d8f	116	{"phy": "displacement", "lvdt": "DAQi"}	f	\N	\N	\N
460	4008	87bf38c3-0b08-4bcf-98b4-12060fd9a345	100	{"phy": "crack", "lvdt": "DAQi"}	f	\N	\N	\N
486	4010	43e2a07a-c33e-4e54-ba5e-0a948ae4ba61	\N	\N	t	212	{"Ha": "a", "Hb": "b", "Hc": "c", "Hd": "d", "angX": "x", "angY": "y", "xDegree": "θx", "yDegree": "θy"}	\N
487	1011	7c42d86a-5801-4ef2-94df-2b5c702ff7f5	\N	{"pressure": "electricity"}	f	\N	\N	\N
488	2003	b6d1b7db-4a04-40af-a1e9-ed944a65b0b8	\N	{"pressure": "pressure"}	f	\N	\N	\N
489	1004	61f09dd0-ba56-40e4-a2d1-45dab1143900	\N	{"phy": "temperature"}	f	\N	\N	\N
490	3001	12a0ae21-df74-42b4-94ce-492125b941bd	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
491	4004	14f67669-6cec-42c0-a7ca-4b60950ec7b5	117	{"phy": "deflection", "value": "DAQi"}	f	\N	\N	\N
492	4004	e08c86d5-195d-4cf6-a1a5-1cfd113ddd52	117	{"phy": "deflection", "value": "DAQi"}	f	\N	\N	\N
493	5002	fbc83633-74fd-494b-b1b7-75d289358b27	\N	\N	f	\N	\N	\N
494	4007	ba349741-3d03-49c6-a2cf-9e2156fd36c4	\N	{"anglex": "x", "angley": "y"}	f	\N	\N	\N
495	4002	ba349741-3d03-49c6-a2cf-9e2156fd36c4	\N	{"changedx": "x", "changedy": "y"}	f	\N	\N	\N
496	4005	ba349741-3d03-49c6-a2cf-9e2156fd36c4	\N	{"changedx": "x", "changedy": "y"}	f	\N	\N	\N
236	2004	473aee20-7c00-41cd-bd6e-b44c35c758ea	\N	{"physicalvalue": "force"}	f	\N	{}	\N
237	2004	0dcf5869-2683-44e4-a0c0-ddd8e9adb8f1	\N	{"physicalvalue": "force"}	f	\N	{}	\N
420	2001	537cf41f-69a4-47de-81ee-63485ab8df1d	\N	{"force": "cableForce"}	f	\N	\N	\N
424	2004	90a2bc12-2214-43ff-9154-9b9212de2c10	\N	{"physicalvalue": "force"}	f	\N	\N	\N
425	2004	5dc26bc7-d2a8-42e8-9bf1-48505ee2b3f8	\N	{"physicalvalue": "force"}	f	\N	\N	\N
426	2004	5e7775c1-0766-436e-b701-b1102833b98d	\N	{"physicalvalue": "force"}	f	\N	\N	\N
446	4001	e5f12d4b-bb3c-4158-b98e-8af3579bd2cc	100	{"phy": "displacement", "physicalvalue": "DAQi"}	f	\N	\N	\N
445	4001	27930598-2f6e-4932-a816-9685f17969b5	100	{"phy": "displacement", "physicalvalue": "DAQi"}	f	\N	\N	\N
443	4001	1d48c633-6d83-4b96-a572-6f59a0100c9b	100	{"phy": "displacement", "physicalvalue": "DAQi"}	f	\N	\N	\N
126	2004	6c0d843c-169e-49b8-8dde-188699cc3077	\N	{}	t	204	{"Nc": "force", "physicalvalue": "δi"}	\N
498	2005	717279c9-81b5-4bfe-8dd3-906297d70e41	\N	{"elongationIndicator": "gravity"}	f	\N	\N	\N
257	2003	abaf6bf4-288f-4d21-9fab-515213e6dcac	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
427	2004	099c6283-519f-4946-aa9d-f0059a76b832	\N	{"physicalvalue": "force"}	f	\N	\N	\N
361	3001	b6095ab3-88ff-4a71-8f42-f0656b301e1e	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
447	4001	362018b7-e626-4eab-a6ad-214d85cfcc03	100	{"phy": "displacement", "physicalvalue": "DAQi"}	f	\N	\N	\N
444	4001	50600703-5c4c-4ceb-a44d-d0b79882b1dc	100	{"phy": "displacement", "physicalvalue": "DAQi"}	f	\N	\N	\N
65	4010	9e8050a9-f38a-45c3-a02b-40670bdf19b7	\N	{}	t	212	{"Ha": "a", "Hb": "b", "Hc": "c", "Hd": "d", "angX": "x", "angY": "y", "anglex": "θx", "angley": "θy"}	\N
499	4012	1e20c41f-4f52-4d61-94e4-ae8496163aed	\N	{"anglex": "x", "angley": "y", "anglez": "z"}	f	\N	\N	\N
500	4012	00b58795-1a49-4171-b60f-a0e32a25f6f6	\N	{"anglex": "x", "angley": "y", "anglez": "z"}	f	\N	\N	\N
504	5002	09252236-560b-47e1-bf81-f774d303ba26	\N	\N	f	\N	\N	\N
505	1030	1489127c-8f48-448b-a86e-1604f08894ce	\N	{"length": "visibility"}	f	\N	\N	\N
506	1027	1e7003bf-2cd1-4dcb-9ad9-116151f49ae6	\N	{"airq_pm10": "pm10", "airq_pm2_5": "pm25"}	f	\N	\N	\N
507	1030	1e7003bf-2cd1-4dcb-9ad9-116151f49ae6	\N	{"airq_pm10": "visibility"}	f	\N	\N	\N
508	5003	09252236-560b-47e1-bf81-f774d303ba26	\N	\N	f	\N	\N	\N
510	4008	4142b1cc-3576-456b-b0e4-31e68cc16b32	117	{"phy": "crack", "length": "DAQi"}	f	\N	\N	\N
517	4001	8185c197-338c-42e3-acfc-acba2bb1b180	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
518	1003	6def140f-5189-490c-ab4c-57e84dfcd3bf	\N	{"雨量": "rainfall"}	f	\N	\N	\N
519	4006	c15c6be6-83b0-47ea-ac05-38d625eb8ac8	\N	{"anglex": "angle"}	f	\N	\N	\N
520	4007	f4976287-96c1-42a2-aedf-0d8e8ab739c5	101	{"anglex": "xi", "angley": "yi"}	f	\N	\N	\N
521	4005	f4976287-96c1-42a2-aedf-0d8e8ab739c5	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
522	4008	83d8bf62-35f8-48c5-afa2-0d454cb19f70	117	{"phy": "crack", "length": "DAQi"}	f	\N	\N	\N
523	4007	8c2579cd-6aca-4902-a9d6-61e916a4541e	101	{"anglex": "xi", "angley": "yi"}	f	\N	\N	\N
524	4005	8c2579cd-6aca-4902-a9d6-61e916a4541e	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
525	1002	65b984f5-c294-49fa-8433-510d38416095	\N	{"humidity": "humidity", "temperature": "temperature"}	f	\N	\N	\N
526	2003	f30482b9-b518-4048-8217-bd64158911e6	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
527	2003	0c5218a3-4fe6-437c-bfee-0c7b4d8d5b83	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
528	2003	3aba791d-d6b2-4175-bb20-109f210f4065	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
529	2003	a9d42f6d-8409-415c-937e-aea8bebf7a50	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
530	2003	fa5f7d2a-71d9-4ee5-9150-c4db8d3a6e45	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
540	3001	388cca81-7338-40d3-ba1f-89ec9d5aa2f7	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
541	4003	526c42ea-d9a9-48d1-9862-b3118a7ef211	\N	\N	f	\N	\N	\N
542	1002	63429c67-5b55-4b88-998c-65d4464623c8	\N	{"data1": "temperature", "data2": "humidity"}	f	\N	\N	\N
543	1001	b55b3b15-5db9-4946-a5a9-b0d352de6a24	\N	{"data1": "speed", "data2": "direction"}	f	\N	\N	\N
544	4007	d52af3c0-c4b0-4091-96c6-ac3e97535f92	101	{"anglex": "xi", "angley": "yi"}	f	\N	\N	\N
545	4007	4a0f1cd5-1e52-4ec3-8976-0b1f82031d28	101	{"anglex": "xi", "angley": "yi"}	f	\N	\N	\N
546	4005	4a0f1cd5-1e52-4ec3-8976-0b1f82031d28	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
547	3001	28d8942e-d1ab-40ee-878a-c3b2f60da896	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
548	3001	4d3ecec5-32b4-4d9b-aa02-a08275dd10c7	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
549	2003	4af8678b-8f9b-48e6-b8f0-ea7ec7ed53ee	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
550	1005	aa6f3b0e-9bd2-41e8-801d-730aca3e32fb	105	{"h": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
551	3001	5d399cb2-7e5a-4a27-bff0-e1769f43499d	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
552	3001	384f80e3-ad51-400e-b0aa-8a3885961cec	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
553	2005	21c691a7-7a5a-4262-a3fe-cedb0c37e5fe	\N	{"pressure": "gravity"}	f	\N	\N	\N
554	1022	85f5b6fd-92cc-4d22-9dff-952c59003e3f	\N	{"physicalvalue": "speed"}	f	\N	\N	\N
555	1029	0beb606c-f306-4476-8526-31646c8107e5	\N	{"physicalvalue": "direction"}	f	\N	\N	\N
556	1006	92bad770-f845-4bd8-8e2b-55e5343a2201	\N	{"physicalvalue": "humidity"}	f	\N	\N	\N
557	1003	6e1d3878-3ea2-4c73-9137-0ef98781be0c	\N	\N	f	\N	\N	\N
558	2004	20ff998d-3014-4f62-ad12-37b56883c435	\N	{"physicalvalue": "force"}	f	\N	\N	\N
559	2004	c60cc02d-8c37-447a-9f9d-947aa66b7f39	\N	{"physicalvalue": "force"}	f	\N	\N	\N
421	2001	2dead818-122a-42d9-8f52-3aa8d92ab0c3	\N	{"cableforce": "cableForce"}	f	\N	\N	\N
561	2004	84deac79-cd1d-4320-bcc6-3a0cdd4451da	\N	{"physicalvalue": "force"}	f	\N	\N	\N
566	3001	d75d2473-6ed4-437c-8509-682f55d0d407	\N	{"value": "strain"}	f	\N	\N	\N
567	1026	8fb33fdb-3378-44a4-8e48-ec79ff29a37e	\N	{"pmstandard": "concentration"}	f	\N	\N	\N
568	1026	cda0b115-60d6-4169-8f45-4a92d6801fb3	\N	{"pmstandard": "concentration"}	f	\N	\N	\N
569	4007	c15c6be6-83b0-47ea-ac05-38d625eb8ac8	\N	\N	t	214	{"anglex": "v"}	\N
570	4007	874e1ee5-94fe-49aa-94b0-6d6bfef680bc	\N	\N	t	214	{"anglex": "v"}	\N
765	2003	c9eacd36-38d6-48b9-9672-e76406906ea3	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
429	2004	bbfa13d3-fd42-4230-97e6-792463dbaf85	\N	{"physicalvalue": "force"}	t	202	{"Δh": "force", "force": "pv"}	\N
428	2004	c0cde67c-9734-4a3c-bb52-0caba0ae8724	\N	{"physicalvalue": "force"}	t	202	{"Δh": "force", "force": "pv"}	\N
431	2004	1bcd78b8-bd96-4c95-8e19-27a1ac7356c9	\N	{"physicalvalue": "force"}	t	202	{"Δh": "force", "force": "pv"}	\N
571	4007	d3245ff1-0781-49bd-b37c-e245a350a709	100	{"phy": "v", "angleX": "DAQi"}	t	214	{}	\N
572	1017	5efb0ea9-ca31-4a41-9389-be6c24b3ad2c	\N	{"physicalvalue": "concentration"}	f	\N	\N	\N
573	1019	ae8d62c1-09f0-4fcd-bc62-add087919ff0	\N	{"physicalvalue": "lel"}	f	\N	\N	\N
574	2001	219cbb09-9c49-4167-846d-00a8bdfadb9a	\N	{"pressure": "cableForce"}	f	\N	\N	\N
575	4001	d148ae2e-c0dd-4e57-a0e8-833d32107f31	100	{"phy": "displacement", "level": "DAQi"}	f	\N	\N	\N
516	1005	f0da34c8-bf8b-49c3-b9d0-3e72f5b2ef9d	124	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
514	1005	624610fd-38ca-4e72-92c8-0492eb66412a	124	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
513	1005	ea2cc9e5-072a-4994-a232-f79655536c64	124	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
512	1005	7f76a800-a32e-483a-a948-919fc9e7d075	124	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
511	1005	3f493145-8216-487c-b145-d58dacf9c570	124	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
565	2004	7674c64d-e09e-4257-8726-c64a26ed309a	\N	{}	t	202	{"Δh": "force", "physicalvalue": "pv"}	\N
564	2004	4a7b8b8f-6ba0-4731-af44-8f3f6d30a928	\N	{}	t	202	{"Δh": "force", "physicalvalue": "pv"}	\N
563	2004	4fbfd1e0-1a1a-4d6f-b99b-f6254cf21d66	\N	{}	t	202	{"Δh": "force", "physicalvalue": "pv"}	\N
562	2004	110a38a6-8cb9-43c5-9682-4b1ba0e9d01f	\N	{}	t	202	{"Δh": "force", "physicalvalue": "pv"}	\N
531	2004	d3763c4f-94ba-4ae4-b35e-ccff2340c16a	\N	{}	t	202	{"Δh": "force", "physicalvalue": "pv"}	\N
534	2004	ca6af9e3-f1dc-4992-8029-d0e438ef99b5	\N	{}	t	202	{"Δh": "force", "physicalvalue": "pv"}	\N
539	3001	02513eed-ba94-456b-86e0-89ea996b879d	\N	{}	t	202	{"Δh": "strain", "physicalvalue": "pv"}	\N
538	3001	2e0d00cd-a321-4504-b716-41813848cbdb	\N	{}	t	202	{"Δh": "strain", "physicalvalue": "pv"}	\N
535	3001	9297adfa-1972-45e3-a5c4-0f31a0acbe84	\N	{}	t	202	{"Δh": "strain", "physicalvalue": "pv"}	\N
576	1031	fbe11da9-a717-4a5e-bd90-93f394b46ccc	\N	{"physicalvalue": "concentration"}	f	\N	\N	\N
577	1001	1cfa35c8-129a-45eb-9304-2b105bc22380	\N	{"speed": "speed", "direction": "direction"}	f	\N	\N	\N
578	4007	901073b9-b411-427c-9eb6-43a935ec8c27	\N	{"anglex": "x", "angley": "y"}	f	\N	\N	\N
579	4006	077f4241-fe27-4cbc-9918-cf5b8d1c8283	\N	{"physicalvalue": "angle"}	f	\N	\N	\N
581	1004	d77b7e20-7877-47dc-aef4-37a663bac660	\N	{"temperature": "temperature"}	f	\N	\N	\N
582	2003	40a69ace-03f8-4acf-8cf7-6acf43ac2de8	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
583	4007	9d6f5e3b-2821-48f0-b5c5-997baf346f39	101	{"anglex": "xi", "angley": "yi"}	f	\N	\N	\N
584	1022	7c2ff6f1-5bb6-4736-91cd-1bd068e760aa	\N	{"physicalvalue": "speed"}	f	\N	\N	\N
585	4006	200655be-879b-4a82-8a17-1ff1ccb9f961	\N	{"physicalvalue": "angle"}	f	\N	\N	\N
586	3003	d77b7e20-7877-47dc-aef4-37a663bac660	123	{"σ": "stress", "physicalvalue": "ε"}	f	\N	\N	\N
587	4001	563221c8-bdb4-4511-b781-25cab72585a7	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
588	2003	d8860bee-374c-497a-a33a-258af59e3690	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
626	1009	0aae766a-5d82-479a-bd71-7eb1e0e4e20f	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
616	1009	0c5d070d-fb83-4f78-acc0-a0bd12be6cc2	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
589	5001	51654fb3-cd61-405e-890f-ade3931c8b7e	122	\N	f	\N	\N	\N
590	5002	51654fb3-cd61-405e-890f-ade3931c8b7e	122	\N	f	\N	\N	\N
591	4008	bff19d80-ce20-4c3d-b158-df091a1fb5ac	117	{"phy": "crack", "length": "DAQi"}	f	\N	\N	\N
592	4011	260e307b-9a7c-4f75-90cd-79710a7d0221	119	{"Δh": "displacement", "length": "Li"}	f	\N	\N	\N
593	4011	66717a8f-3c59-41e0-ab21-bf6bcdde55ea	119	{"Δh": "displacement", "length": "Li"}	f	\N	\N	\N
594	4001	66717a8f-3c59-41e0-ab21-bf6bcdde55ea	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
595	4001	260e307b-9a7c-4f75-90cd-79710a7d0221	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
596	4001	fb7bb438-ec7d-41fa-b7f5-737c395901bc	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
597	4001	e458516d-60cf-4395-8ec5-df491ae97d3e	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
598	4011	fb7bb438-ec7d-41fa-b7f5-737c395901bc	119	{"Δh": "displacement", "length": "Li"}	f	\N	\N	\N
599	4011	e458516d-60cf-4395-8ec5-df491ae97d3e	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
600	4001	5ac91988-c93a-4176-9f33-7c6ba110590f	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
601	4004	5ac91988-c93a-4176-9f33-7c6ba110590f	100	{"phy": "deflection", "length": "DAQi"}	f	\N	\N	\N
502	5001	c8fd3080-b416-4381-8bcc-e84c12471281	\N	{"pv": "pv", "ppv": "ppv", "rms": "trms"}	f	\N	\N	\N
501	5002	c8fd3080-b416-4381-8bcc-e84c12471281	\N	{"pv": "pv", "ppv": "ppv", "rms": "trms"}	f	\N	\N	\N
632	4007	c9a11ba9-fb0d-4a82-b480-7539948c9b56	102	{"x": "x", "y": "y", "xDegree": "αy", "yDegree": "αx"}	f	\N	\N	\N
633	4001	83881bee-4e8c-4ad6-a11f-45810d035b3d	100	{"phy": "displacement", "level": "DAQi"}	f	\N	\N	\N
606	1009	65f4e736-8261-40cc-b3b8-948ab0e4252e	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
614	1009	13126536-b6af-48d0-b43e-25144b65dd8d	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
618	1009	f3ad3df8-e1ad-4e05-b479-185ac5ae8602	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
620	1009	e8d9a100-9650-4afc-a260-9c7bcdea9263	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
610	1009	3462227d-e989-421c-9f48-c0ae7a573b78	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
612	1009	16ca7eed-6c64-4c4b-a495-6c5f785b86cd	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
622	1009	d7912272-424d-4546-a3c1-43a24365dde0	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
624	1009	91372b00-3bf7-4eb0-9495-ad544dfb04ca	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
628	1009	ac32d002-0463-4bc7-a307-86236e6307a7	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
604	1009	e015d9d3-542e-4d54-80c6-39db4ba20877	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
603	1009	24b365fd-4e6e-4800-ad48-d3f082c9b2b8	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
630	1009	584a210b-20f2-49cf-906a-9d6b4883af09	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
608	1009	6bd546bc-55b0-4ee4-8b58-34feec8cdb6c	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
609	1010	6bd546bc-55b0-4ee4-8b58-34feec8cdb6c	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
627	1010	0aae766a-5d82-479a-bd71-7eb1e0e4e20f	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
625	1010	91372b00-3bf7-4eb0-9495-ad544dfb04ca	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
629	1010	ac32d002-0463-4bc7-a307-86236e6307a7	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
623	1010	d7912272-424d-4546-a3c1-43a24365dde0	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
631	1010	584a210b-20f2-49cf-906a-9d6b4883af09	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
602	1010	24b365fd-4e6e-4800-ad48-d3f082c9b2b8	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
613	1010	16ca7eed-6c64-4c4b-a495-6c5f785b86cd	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
615	1010	13126536-b6af-48d0-b43e-25144b65dd8d	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
605	1010	e015d9d3-542e-4d54-80c6-39db4ba20877	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
621	1010	e8d9a100-9650-4afc-a260-9c7bcdea9263	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
619	1010	f3ad3df8-e1ad-4e05-b479-185ac5ae8602	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
611	1010	3462227d-e989-421c-9f48-c0ae7a573b78	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
617	1010	0c5d070d-fb83-4f78-acc0-a0bd12be6cc2	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
607	1010	65f4e736-8261-40cc-b3b8-948ab0e4252e	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
277	4002	0c5bca0d-95b8-416e-865b-1f09bb49285f	102	{"x": "x", "y": "y", "xDegree": "αx", "yDegree": "αy"}	f	\N	\N	\N
634	4008	b15a4ae0-8100-4809-978d-50914fdc2f32	117	{"phy": "crack", "physicalvalue": "DAQi"}	f	\N	\N	\N
635	4001	1991c0ef-7dd2-4290-ad34-c8bc82161d2f	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
636	4001	b2d406aa-3d16-4f6a-a0cf-201673678a8f	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
637	4001	9fbee940-6591-45b4-a3a9-83abc9c76e85	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
638	4008	b2d406aa-3d16-4f6a-a0cf-201673678a8f	100	{"phy": "crack", "length": "DAQi"}	f	\N	\N	\N
639	4004	aa4c3887-4040-4ac1-a908-4ae45f754c3b	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
515	1005	cf54dd7a-2c8a-4f16-9f92-7484af585f13	124	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
537	3001	1bda935e-56de-4365-b60e-f02d19299795	\N	{}	t	202	{"Δh": "strain", "physicalvalue": "pv"}	\N
640	2004	6c650368-cf3e-4a75-a30d-01b2a37356fb	\N	\N	t	202	{"Δh": "force", "physicalvalue": "pv"}	\N
641	2004	2e0d00cd-a321-4504-b716-41813848cbdb	\N	\N	t	211	{"F": "force", "physicalvalue": "εi"}	\N
642	2004	02513eed-ba94-456b-86e0-89ea996b879d	\N	\N	t	211	{"F": "force", "physicalvalue": "εi"}	\N
643	2004	2d9520e9-143b-48c2-960f-5c9dca7a21b4	\N	\N	t	211	{"F": "force", "physicalvalue": "εi"}	\N
644	4007	a045d540-6405-495e-af5f-ea705c094472	\N	{"anglex": "x", "angley": "y"}	f	\N	\N	\N
580	2001	d14c6b02-4298-4713-b970-eba0aafee88b	113	{"F": "cableForce", "physicalvalue": "ε"}	f	\N	\N	\N
532	2004	aab61193-270e-4d06-9bdf-9da5194c744a	\N	{}	t	202	{"Δh": "force", "physicalvalue": "pv"}	\N
533	2004	0b09cbd9-3881-4b4a-8910-0e8730d5d935	\N	{}	t	202	{"Δh": "force", "physicalvalue": "pv"}	\N
645	2006	d3763c4f-94ba-4ae4-b35e-ccff2340c16a	125	{"σ": "δi", "physicalvalue": "F"}	t	204	{"Nc": "force"}	\N
646	2006	aab61193-270e-4d06-9bdf-9da5194c744a	125	{"σ": "δi", "physicalvalue": "F"}	t	204	{"Nc": "force"}	\N
647	2006	0b09cbd9-3881-4b4a-8910-0e8730d5d935	125	{"σ": "δi", "physicalvalue": "F"}	t	204	{"Nc": "force"}	\N
648	2006	ca6af9e3-f1dc-4992-8029-d0e438ef99b5	125	{"σ": "δi", "physicalvalue": "F"}	t	204	{"Nc": "force"}	\N
649	1005	d56a9be3-7a4a-4c75-91ec-f524bb273574	100	{"phy": "waterLevel", "pressure": "DAQi"}	f	\N	\N	\N
650	1004	948c741a-f999-4abe-ae1f-64c23e27462c	\N	{"temperature": "temperature"}	f	\N	\N	\N
651	2003	7f76a800-a32e-483a-a948-919fc9e7d075	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
652	2003	3f493145-8216-487c-b145-d58dacf9c570	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
653	2003	ea2cc9e5-072a-4994-a232-f79655536c64	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
654	2003	624610fd-38ca-4e72-92c8-0492eb66412a	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
655	2003	cf54dd7a-2c8a-4f16-9f92-7484af585f13	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
656	2003	f0da34c8-bf8b-49c3-b9d0-3e72f5b2ef9d	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
657	1032	0f179575-cae8-4888-a644-1b66be3f8de2	\N	{"CO": "CO", "O3": "O3", "NO2": "NO2", "SO2": "SO2", "PM10": "PM10", "PM25": "PM2.5", "TVOC": "TVOC", "humidity": "humidity", "temperature": "temp"}	f	\N	\N	\N
658	1004	20e28988-ea9b-4757-9f79-22dce525207a	\N	{"temperature": "temperature"}	f	\N	\N	\N
659	4004	b56e401a-75e7-47ea-84db-6638fd421792	100	{"phy": "deflection", "length": "DAQi"}	f	\N	\N	\N
660	4004	515030fd-3993-442a-89f7-ca844c5671c0	100	{"phy": "deflection", "length": "DAQi"}	f	\N	\N	\N
661	4001	515030fd-3993-442a-89f7-ca844c5671c0	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
663	4007	427e8976-edd3-4467-8900-587c12fbf6cf	101	{"anglex": "xi", "angley": "yi"}	f	\N	\N	\N
664	4005	427e8976-edd3-4467-8900-587c12fbf6cf	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
665	4001	70dd7ed7-45de-4c9c-a299-7c0686775dc3	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
666	4004	70dd7ed7-45de-4c9c-a299-7c0686775dc3	100	{"phy": "deflection", "length": "DAQi"}	f	\N	\N	\N
667	4007	0f6fd3af-59cc-4fa8-8ff5-f42f173ac9fa	101	{"anglex": "xi", "angley": "yi"}	f	\N	\N	\N
668	4005	0f6fd3af-59cc-4fa8-8ff5-f42f173ac9fa	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
669	4001	aa4c3887-4040-4ac1-a908-4ae45f754c3b	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
670	1022	8f52b7da-f1a6-49c7-a4ac-cd4bf7ee3aea	\N	{"speed": "speed"}	f	\N	\N	\N
671	1029	a6d30b7e-a718-4cbf-80be-2ddefa2445ab	\N	{"direction": "direction"}	f	\N	\N	\N
672	1033	9fab42c0-0c95-4fd2-a470-08437473a2f4	\N	\N	f	\N	\N	\N
673	2004	8fcb81d8-34ce-41b8-93c9-69d15060fa40	\N	{"physicalvalue": "force"}	f	\N	\N	\N
674	2004	f9f9d2f0-2a96-491a-b5cc-f2a4875e5d17	\N	{"physicalvalue": "force"}	f	\N	{}	\N
675	4002	d52af3c0-c4b0-4091-96c6-ac3e97535f92	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
678	1034	4a1c835d-1f99-4d95-8d21-ceab11c714d3	\N	\N	f	\N	\N	\N
679	1034	e1f36777-486a-4527-a30f-61d17b7a8796	\N	{"pm10": "pm10", "pm25": "pm25", "noise": "noise", "speed": "speed", "direction": "direction"}	f	\N	\N	\N
680	7001	8e67e334-231e-467c-8868-c41461d9463e	\N	\N	f	\N	\N	\N
681	7002	6b4905df-caae-4bcc-a8a7-c99cb7866e06	\N	\N	f	\N	\N	\N
682	7003	705738a1-f330-4875-a2a0-23c30ec9f5d4	\N	\N	f	\N	\N	\N
683	4007	77a4b2d1-adf0-4cab-be7e-5f4635e4063f	\N	\N	f	\N	\N	\N
684	4001	0e7784d1-0cbf-46aa-b156-e3361a3251e4	201	{"Δh": "displacement", "length": "Li"}	f	\N	\N	\N
686	5001	e32efbee-3c36-4be6-a4d3-d5058acf1fda	122	\N	f	\N	\N	\N
687	5002	e32efbee-3c36-4be6-a4d3-d5058acf1fda	122	\N	f	\N	\N	\N
688	4014	ba3d723e-88ac-4e9a-976f-43d43081e621	\N	{"speed": "speed", "height": "height", "radius": "range", "rotation": "angle", "curweight": "load", "obliquity": "obliquity"}	f	\N	\N	\N
689	4001	19bb2b93-6e2e-4861-95df-67a68bc71fc4	\N	{"length": "displacement"}	f	\N	\N	\N
690	4008	19bb2b93-6e2e-4861-95df-67a68bc71fc4	100	{"p": "crack", "length": "ci"}	f	\N	\N	\N
691	1005	177e7e33-3dae-4163-8d7d-1778e70b4a8b	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
763	1005	68885fd4-0280-410a-bf22-3afadec546f2	103	{"H": "waterLevel", "level": "h"}	f	\N	\N	\N
764	1048	390e46cc-b69d-4966-89f4-d305afdd4649	\N	{"alarmCode": "stateCode"}	f	\N	\N	\N
64	4007	9e8050a9-f38a-45c3-a02b-40670bdf19b7	101	{"x": "x", "y": "y", "anglex": "xi", "angley": "yi"}	f	\N	\N	\N
692	1034	3ad4be85-c6f9-46b8-97dd-39d01e4ef858	\N	{"pm10": "pm10", "pm25": "pm25", "temp": "temperature", "noise": "noise", "winddir": "direction", "humidity": "humidity", "windspeed": "speed"}	f	\N	\N	\N
677	4014	039664c3-5d24-4edb-b251-7540c98dc2ce	\N	{"height": "height", "radius": "range", "loadValue": "load", "obliquity": "obliquity", "windSpeed": "speed", "rotationAngle": "angle", "torquePercent": "moment"}	f	\N	\N	\N
693	8001	27503c42-1dec-4321-ad45-eab67190afb5	\N	{"co": "co", "o3": "o3", "pm": "pm2_5", "no2": "no2", "so2": "so2", "pm10": "pm10"}	f	\N	\N	\N
694	8002	c1831563-faaf-4e2a-9d49-6b483abbd040	\N	{"ph": "ph", "oxygen": "do", "turbidity": "turb", "temperature": "temp", "conductivity": "tds"}	f	\N	\N	\N
695	1034	24946992-8d23-4862-ab23-0844e246fb46	\N	{"pm10": "pm10", "pm25": "pm25", "noise": "noise", "speed": "speed", "humidity": "humidity", "direction": "direction", "temperature": "temperature"}	f	\N	\N	\N
696	8002	55d8d331-c61d-4523-886d-2d69f350cde0	\N	{"PH": "ph", "oxy": "do", "temp": "temp", "turbidity": "turb", "conductivity": "tds"}	f	\N	\N	\N
697	1034	7734e171-78b3-4a47-bccf-b812a1cf30f3	\N	{"pm10": "pm10", "pm25": "pm25", "noise": "noise", "humidity": "humidity", "windSpeed": "speed", "temperature": "temperature", "windDirection": "direction"}	f	\N	\N	\N
699	4015	5f1f2736-2744-4339-b456-50c5626ea641	\N	\N	f	\N	\N	\N
700	9002	b440e042-3173-43c6-887c-3cf4ce8a49e4	\N	{"readingNumber": "total"}	f	\N	\N	\N
701	9001	4a91ace7-e5da-44c8-843d-43fb6a130847	\N	{"readingNumber": "total"}	f	\N	\N	\N
702	0001	3bae74f8-5224-45f9-bbcd-f40968ed1ce2	\N	{"urinalstate": "state"}	f	\N	\N	\N
703	0001	a5dda81c-6a85-4e7b-97f3-be45b980646e	\N	{"pitstate": "state"}	f	\N	\N	\N
704	9004	b03b1516-7e4a-41a4-9765-a1a485bb998a	\N	{"NH3": "nh3", "humidity": "humidity", "temperature": "temperature"}	f	\N	\N	\N
705	9003	d5bfb91e-3d09-4068-ac33-5974e8b7f039	\N	\N	f	\N	\N	\N
706	1034	a820a6a6-2302-4291-bf8a-e6beb3e7f663	\N	\N	f	\N	\N	\N
707	1016	0209176c-7c91-4fe0-9a00-e751fe24c8f8	\N	{"ph": "ph"}	f	\N	\N	\N
708	1018	800e5478-374c-4de8-ab05-d9aa4be45cdb	\N	{"concentration": "concentration"}	f	\N	\N	\N
709	1002	3b867352-5d0b-4016-a55f-4d68d0dcbaa4	\N	\N	f	\N	\N	\N
710	1020	dff02ef2-0438-415d-9327-cdd883c38c81	\N	{"intensity": "lumen"}	f	\N	\N	\N
711	1041	d199daf3-83a4-4bcc-b23b-b6ca37fba927	\N	\N	f	\N	\N	\N
676	4002	af1cd7e8-52e1-4411-9c9a-20bc82a2786d	102	{"angleX": "αx", "angleY": "αy"}	f	\N	\N	\N
61	4002	9e8050a9-f38a-45c3-a02b-40670bdf19b7	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
262	4007	af1cd7e8-52e1-4411-9c9a-20bc82a2786d	101	{"angleX": "xi", "angleY": "yi"}	f	\N	\N	\N
712	1001	495526a7-7701-4e9c-8dfd-bbfd7e0b163b	\N	{"windspeed": "speed", "winddirection": "direction"}	f	\N	\N	\N
713	1035	11c61b7f-9d36-4273-b679-898a09fe21e9	\N	{"pm10": "pm10", "pm25": "pm25", "temp": "temperature", "noise": "noise", "humidy": "humidity"}	f	\N	\N	\N
734	5002	56c84083-d705-4aa0-94d2-34b731f75f97	122	\N	f	\N	\N	\N
714	2003	7efbc3e8-ff6b-433b-9041-c76b9df89644	104	{"Δh": "pressure", "pressure": "Pi"}	f	\N	\N	\N
715	6010	d5ce913e-4a89-473e-b69b-bdfbc0fa6753	\N	\N	f	\N	\N	\N
474	4003	a1923ce2-b8a5-45cb-9d98-6a42901cee7c	109	{"X": "x", "Y": "y", "Z": "z", "x": "xi", "y": "yi", "z": "zi"}	f	\N	\N	\N
716	8003	e996ef32-944e-448f-9370-862fd5ed719d	\N	\N	f	\N	\N	\N
717	8004	3d8fcd19-8b2a-4d02-8dd3-de8e2c082dcc	\N	\N	f	\N	\N	\N
718	8005	9db37a62-7896-4477-a3c4-7d317d28f26e	\N	\N	f	\N	\N	\N
719	8006	4eb4d7ed-2199-4514-9411-9c12d59f72e3	\N	\N	f	\N	\N	\N
720	8007	a91dd10c-af61-4fcf-8294-1d200a035664	\N	\N	f	\N	\N	\N
721	8008	a23e3c37-7ab4-4ed4-b73b-a791c96d596c	\N	\N	f	\N	\N	\N
722	8009	ccfcd1c0-1cf5-4123-9be8-ca521b1e79d3	\N	\N	f	\N	\N	\N
723	7007	0794ccbd-2a6e-49b6-9b42-abf93957b33c	\N	\N	f	\N	\N	\N
725	2003	b21b534c-d8f1-4caf-a405-1682a99dc1a9	128	{"p": "pressure", "voltage": "v"}	f	\N	\N	\N
726	8010	7f8fac16-3dbd-4d0a-bf38-322c5818e096	\N	\N	f	\N	\N	\N
728	1034	bb3ec092-4644-42eb-93ba-f9ae9b4b6601	\N	{"pm10": "pm10", "pm25": "pm25"}	f	\N	\N	\N
729	9005	9aa975c7-a3d4-42ec-a384-17d0425e602a	\N	\N	f	\N	\N	\N
730	4018	3027f2cf-70b8-4ff6-92ee-7432a8b26887	\N	{"arch": "arch", "tunnelface": "tunnelface"}	f	\N	\N	\N
731	4001	9922afa7-509c-4ee2-8cfa-094233cf6eb1	\N	{"length": "displacement"}	f	\N	\N	\N
733	4018	85e05ea0-94ca-4806-9393-78780b771a4b	\N	{"arch": "arch", "tunnelface": "tunnelface"}	f	\N	\N	\N
735	1008	11a0df92-8921-470b-af9c-d7593b8b1f78	106	{"v": "seepage", "pressure": "p"}	f	\N	\N	\N
738	4011	9922afa7-509c-4ee2-8cfa-094233cf6eb1	\N	{"length": "displacement"}	f	\N	\N	\N
740	1002	d5bf6f22-3d7a-4ab0-9043-1020e9516bcc	\N	{"Temp": "temperature", "humidy": "humidity"}	f	\N	\N	\N
741	9004	89fb363a-19d1-4e23-a9af-b2a2c310eb4f	\N	{"NH3": "nh3"}	f	\N	\N	\N
742	9010	a9dc9dd4-9a62-4dfa-968a-69e2c4472a0a	\N	{"inflow": "inflow", "outflow": "outflow"}	f	\N	\N	\N
743	8007	ff67a769-94ed-4f3d-b944-b1f4d4468eec	\N	{"latitude": "lat", "longitude": "lon"}	f	\N	\N	\N
744	6010	ff67a769-94ed-4f3d-b944-b1f4d4468eec	\N	{"speed": "speed", "latitude": "lang", "longitude": "long"}	f	\N	\N	\N
745	1009	2aba0129-a2af-4e99-ad8e-ca8e20aa62f6	103	{"H": "waterLevel", "physicalvalue": "h"}	f	\N	\N	\N
746	1010	2aba0129-a2af-4e99-ad8e-ca8e20aa62f6	107	{"L": "beachWidth", "physicalvalue": "hi"}	f	\N	\N	\N
739	4011	82e60098-d956-499c-97c8-810ba64a8589	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
732	4001	82e60098-d956-499c-97c8-810ba64a8589	100	{"phy": "displacement", "length": "DAQi"}	f	\N	{}	\N
747	2005	82ec14e4-a0ee-4d21-9fcb-24cde7cf551b	\N	{"Weight": "gravity", "WeightPercent": "weightPercent"}	f	\N	\N	\N
750	1047	f929d6c9-de63-4cb0-89f9-f9e7a22cbadb	110	{"Qi": "Qo", "ssagee": "vi"}	t	208	{"Qi": "volume"}	\N
751	1047	6bc95aa6-88cd-4473-98fc-7f4a1d76fc4a	112	{"V": "V_i", "waterlevel": "x"}	t	208	{"Qi": "volume"}	\N
752	4004	7efbc3e8-ff6b-433b-9041-c76b9df89644	104	{"Δh": "deflection", "pressure": "Pi"}	f	\N	\N	\N
736	1005	6bc95aa6-88cd-4473-98fc-7f4a1d76fc4a	103	{"H": "waterLevel", "waterlevel": "h"}	f	\N	\N	\N
748	1046	6bc95aa6-88cd-4473-98fc-7f4a1d76fc4a	112	{"V": "volume", "waterlevel": "x"}	f	\N	{}	\N
749	1045	f929d6c9-de63-4cb0-89f9-f9e7a22cbadb	136	{"E": "flow", "pressure": "p"}	f	\N	\N	\N
727	8011	0f3aa84f-d64b-4135-8ce1-f3a704751a4c	142	{"v_co": "co", "v_o3": "o3", "v_no2": "no2", "v_so2": "so2"}	f	\N	\N	\N
724	1005	c6a59efb-40c2-4104-9b26-7895bb8e072d	100	{"phy": "waterLevel", "length": "DAQi"}	f	\N	\N	\N
401	4008	0eab3179-48cc-4e55-8ec9-b7516415aa75	116	{"phy": "crack", "elongationIndicator": "DAQi"}	f	\N	\N	\N
761	8001	0f3aa84f-d64b-4135-8ce1-f3a704751a4c	142	{"v_co": "co", "v_o3": "o3", "v_no2": "no2", "v_so2": "so2"}	f	\N	\N	\N
756	4001	53070eae-7839-46df-9492-f1b4c0b0b101	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
757	4001	7efbc3e8-ff6b-433b-9041-c76b9df89644	104	{"Δh": "displacement", "pressure": "Pi"}	f	\N	\N	\N
758	8012	e8b1dd32-dd34-4923-a91d-e21f81210749	\N	\N	t	133	{"Ph": "H2S", "Pn": "NH3", "Po": "Odor", "Pv": "VOCS", "H2S": "Qh", "NH3": "Qn", "Odor": "Qo", "VOCS": "Qv"}	\N
759	8012	676c48ff-13c3-426f-9871-989570d76ef9	\N	\N	t	133	{"runoff": "C"}	\N
760	3001	4fa8750d-807d-4c0c-9526-2662418f6f2f	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
762	1005	c8b20fe8-531f-47aa-96cd-3d48ea0bc238	103	{"H": "waterLevel", "pressure": "h"}	f	\N	\N	\N
767	2006	73a7b800-25d7-41ad-872d-96cc4f9430de	\N	{"physicalvalue": "force"}	t	204	{"Nc": "force", "physicalvalue": "δi"}	\N
768	2006	473aee20-7c00-41cd-bd6e-b44c35c758ea	\N	{}	t	204	{"Nc": "force", "physicalvalue": "δi"}	\N
769	2006	0dcf5869-2683-44e4-a0c0-ddd8e9adb8f1	\N	{}	t	204	{"Nc": "force", "physicalvalue": "δi"}	\N
771	1003	8c23f875-86cf-4fe7-a315-526c7a1d0187	\N	{"physicalvalue": "rainfall"}	f	\N	\N	\N
774	3003	b77b1ad2-2546-4219-bbe8-dc6b71d7fe01	125	{"σ": "stress", "physicalvalue": "F"}	f	\N	\N	\N
770	3001	b77b1ad2-2546-4219-bbe8-dc6b71d7fe01	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
775	4003	c3ed0f20-828b-46bd-b8ef-b7821cd0fcce	109	{"X": "x", "Y": "y", "Z": "z", "x": "xi", "y": "yi", "z": "zi"}	f	\N	\N	\N
776	1005	0a341896-3c5d-4e60-af19-fe5f645c6967	124	{"pressure": "Pi"}	f	\N	\N	\N
777	1005	aa630d67-b466-4f6a-9a04-fe5744954d20	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
778	1005	e600502e-b2ff-466a-9fa6-b9e9e554647c	124	{"Δh": "waterLevel", "pressure": "Pi"}	f	\N	\N	\N
779	3006	11f0a3dc-13ad-4c40-ae16-1b2f1d139564	\N	\N	t	216	{"σL": "stress", "physicalvalue": "v"}	\N
780	1002	c89d02cd-f052-4004-aa3e-93906248a62b	\N	{"humidity": "humidity", "temperature": "temperature"}	f	\N	\N	\N
781	4004	53070eae-7839-46df-9492-f1b4c0b0b101	104	{"Δh": "deflection", "physicalvalue": "Pi"}	f	\N	\N	\N
782	4009	bff19d80-ce20-4c3d-b158-df091a1fb5ac	117	{"phy": "expansion", "length": "DAQi"}	f	\N	\N	\N
783	4009	d54f6d25-04dc-4847-8dda-9c54d54b2d8f	117	{"phy": "expansion", "lvdt": "DAQi"}	f	\N	\N	\N
698	4014	5e44f909-0d21-4d00-82f5-d3502e192e18	\N	{"Angle": "angle", "Height": "height", "Moment": "moment", "RRange": "range", "Weight": "load", "isOnline": "online", "Obliguity": "obliquity", "WindSpeed": "speed"}	f	\N	\N	\N
784	1003	c96dced7-2915-4087-9ba5-b6f9bdc35f89	\N	{"rain": "rainfall"}	f	\N	\N	\N
785	1004	673195ba-381a-4dea-93e1-4f65f4d84079	\N	{"temperature": "temperature"}	f	\N	\N	\N
786	4020	53070eae-7839-46df-9492-f1b4c0b0b101	104	{"Δh": "x", "physicalvalue": "Pi"}	f	\N	\N	\N
787	3003	11f0a3dc-13ad-4c40-ae16-1b2f1d139564	123	{"σ": "stress", "physicalvalue": "ε"}	f	\N	\N	\N
788	8013	6cb2c0f8-0c45-42e6-97ca-56d97a4a3484	\N	\N	f	\N	\N	\N
509	4008	0bf78d42-85ee-486c-bf43-c62c3168ee33	116	{"phy": "crack", "length": "DAQi"}	f	\N	\N	\N
240	1005	2aba0129-a2af-4e99-ad8e-ca8e20aa62f6	104	{"Δh": "waterLevel", "physicalvalue": "Pi"}	f	\N	\N	\N
773	1005	6039a6d8-af54-411e-a520-451b20b6d089	103	{"H": "waterLevel", "physicalvalue": "h"}	f	\N	\N	\N
737	1008	f929d6c9-de63-4cb0-89f9-f9e7a22cbadb	138	{"Q": "seepage", "ssagee": "H"}	f	\N	\N	\N
790	1005	b86fdc56-591d-40c5-b4f8-cb5b2a265be8	100	{"phy": "waterLevel", "length": "DAQi"}	f	\N	\N	\N
791	4013	6431292f-5b95-41f0-8291-ff902e58b376	139	{"X": "x", "Y": "y", "Z": "h", "height": "zi", "easting": "xi", "northing": "yi"}	f	\N	\N	\N
792	3003	73a7b800-25d7-41ad-872d-96cc4f9430de	125	{"σ": "stress", "physicalvalue": "F"}	f	\N	\N	\N
793	1005	407a002b-de7c-4a76-9732-e4e8aaaafec3	100	{"phy": "waterLevel", "length": "DAQi"}	f	\N	\N	\N
794	4001	0e96ddaf-1acc-419b-afca-18854f8c25d8	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
795	4001	5b338441-75c4-4186-9fc3-23aa8d614e19	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
796	4001	4698f1de-2051-4283-9fe5-2c62b1687239	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
797	4001	446a08d7-c237-4f0b-acfb-3d9310da742d	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
798	4001	b1353bed-cda0-44a5-b1e9-94cb166962a5	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
799	4001	ee878563-3f80-4c7d-8888-319c875c8a5e	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
800	4001	e1118b87-bfea-42be-b365-1c99d35511cc	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
801	4001	43060aae-0e85-4ec6-9fc9-b05216b11e13	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
802	4001	868f47ed-fe83-49c4-be2c-70731b436220	102	{"x": "displacement", "anglex": "αx"}	f	\N	\N	\N
803	4002	a0d06bbf-dedc-47dc-8d1e-52e2a282a93a	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
804	4007	a0d06bbf-dedc-47dc-8d1e-52e2a282a93a	100	{"anglex": "x", "angley": "y"}	f	\N	\N	\N
805	4006	868f47ed-fe83-49c4-be2c-70731b436220	100	{"phy": "DAQi", "anglex": "DAQi"}	f	\N	\N	\N
806	1002	6f6f83fa-1af9-4e4c-8d3f-53c2a4d1b4ca	\N	{"humidity": "humidity", "temperature": "temperature"}	f	\N	\N	\N
849	1052	12f885d6-8a49-4495-909e-8a938e23ec8b	\N	\N	f	\N	\N	\N
807	2004	cd2cc136-a81a-4c2d-a9cb-27fcb4b0aff3	\N	{}	t	217	{"F": "force", "physicalvalue": "εi"}	\N
808	1010	6039a6d8-af54-411e-a520-451b20b6d089	\N	{"physicalvalue": "waterLevel"}	f	\N	\N	\N
809	1009	6bc95aa6-88cd-4473-98fc-7f4a1d76fc4a	\N	{"waterlevel": "waterLevel"}	f	\N	\N	\N
810	1034	7e5507c8-b21b-47c0-b9de-f79f09875fc7	\N	{"pm10": "pm10", "pm25": "pm25", "noise": "noise", "speed": "speed", "humidity": "humidity", "direction": "direction", "temperature": "temperature"}	f	\N	\N	\N
812	7008	1c9756ed-dcf4-4156-9a43-09ce478d2038	140	{"L": "distance", "length": "S1"}	f	\N	\N	\N
813	7009	213e2ff2-285b-445d-8661-24f6f91bf7b8	\N	{"trash": "trash", "signal": "signal", "weight": "weight", "electric": "electric", "latitude": "latitude", "stateCode": "stateCode ", "temprature": "temprature", "stateMessage": "stateMessage", "usedelectric": "usedelectric"}	f	\N	\N	\N
814	4001	6431292f-5b95-41f0-8291-ff902e58b376	100	{"phy": "displacement", "height": "DAQi"}	f	\N	\N	\N
815	4021	6431292f-5b95-41f0-8291-ff902e58b376	101	{"x": "y", "y": "z", "height": "yi", "northing": "xi"}	f	\N	\N	\N
850	2001	56c84083-d705-4aa0-94d2-34b731f75f97	120	{"force": "cableForce"}	f	\N	\N	\N
816	1004	7d9b7e21-42e2-4040-86d7-4bdbba095e43	\N	{"temperature": "temperature"}	f	\N	\N	\N
817	4001	bff19d80-ce20-4c3d-b158-df091a1fb5ac	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
818	3003	cd2cc136-a81a-4c2d-a9cb-27fcb4b0aff3	123	{"σ": "stress", "physicalvalue": "ε"}	f	\N	\N	\N
819	4001	31be3fb7-3369-4966-8e26-b561dc31b6fd	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
820	1001	1d7e6445-a676-42b9-9314-837415832451	\N	{"windSpeed": "speed", "windDirection": "direction"}	f	\N	\N	\N
821	1001	a8dd8956-f9ae-40d0-b207-8f5cf9669545	\N	{"windSpeed": "speed", "windDirection": "direction"}	f	\N	\N	\N
822	1005	79d3e66b-d0ad-4c0f-b724-11eca0d0c0cb	103	{"H": "waterLevel", "waterLever": "h"}	f	\N	\N	\N
823	1003	52c7f175-bdd6-4c4c-948d-aa2a7868cd82	\N	{"hourRainfall": "rainfall"}	f	\N	\N	\N
824	4008	ff8195ce-78e0-4668-81bb-8f26e83411a9	100	{"phy": "crack", "displacement": "DAQi"}	f	\N	\N	\N
825	4009	bcc5cadb-0395-464b-8ead-ac3917b49e30	100	{"phy": "expansion", "lvdt": "DAQi"}	f	\N	\N	\N
826	2001	1bcd78b8-bd96-4c95-8e19-27a1ac7356c9	\N	\N	t	202	{"Δh": "cableForce", "physicalvalue": "pv"}	\N
847	2001	e32efbee-3c36-4be6-a4d3-d5058acf1fda	120	{"force": "cableForce"}	f	\N	\N	\N
851	2001	09252236-560b-47e1-bf81-f774d303ba26	\N	{}	t	222	\N	\N
828	1007	afba576d-0e5e-48cf-a9fa-18a3f986d812	\N	{"ein": "soundLevel", "maxnf": "max", "minnf": "min"}	f	\N	\N	\N
827	5005	56c84083-d705-4aa0-94d2-34b731f75f97	141	{}	f	\N	\N	\N
829	4005	868f47ed-fe83-49c4-be2c-70731b436220	102	{"anglex": "αy"}	f	\N	\N	\N
830	1050	c1e63dc1-8a68-4dad-a180-c652ea587e83	\N	{"totalPhosphorus": "totalPhosphorus"}	f	\N	\N	\N
831	2014	0b09cbd9-3881-4b4a-8910-0e8730d5d935	125	{"σ": "δi", "physicalvalue": "F"}	t	220	{"Nc": "force", "Δt": "temperature", "temperature": "tv"}	\N
832	2014	ca6af9e3-f1dc-4992-8029-d0e438ef99b5	125	{"σ": "δi", "physicalvalue": "F"}	t	220	{"Nc": "force", "Δt": "temperature", "temperature": "tv"}	\N
833	2014	d3763c4f-94ba-4ae4-b35e-ccff2340c16a	125	{"σ": "δi", "physicalvalue": "F"}	t	220	{"Nc": "force", "Δt": "temperature", "temperature": "tv"}	\N
834	2014	aab61193-270e-4d06-9bdf-9da5194c744a	125	{"σ": "δi", "physicalvalue": "F"}	t	220	{"Nc": "force", "Δt": "temperature", "temperature": "tv"}	\N
835	3007	4fa8750d-807d-4c0c-9526-2662418f6f2f	\N	{"physicalvalue": "force"}	f	\N	\N	\N
836	4005	a0d06bbf-dedc-47dc-8d1e-52e2a282a93a	102	{"anglex": "αx", "angley": "αy"}	f	\N	\N	\N
837	1007	20d96ea0-8995-453b-aa12-191acb05eced	\N	{"noise": "soundLevel"}	f	\N	\N	\N
839	4008	31be3fb7-3369-4966-8e26-b561dc31b6fd	100	{"phy": "crack", "length": "DAQi"}	f	\N	\N	\N
841	1004	d31031ab-0237-41a5-adc0-867c1e9952f7	\N	{"temperature": "temperature"}	f	\N	\N	\N
843	1002	fd94699e-65db-45b8-bbe9-88c147ba1e0a	\N	{"humidity": "humidity", "temperature": "temperature"}	f	\N	\N	\N
844	1026	c730d30c-6a9d-4e3e-b347-7dfbe40a217d	\N	{"realTimeGasCon": "concentration"}	f	\N	\N	\N
845	1032	0f3aa84f-d64b-4135-8ce1-f3a704751a4c	142	{"v_co": "co", "v_o3": "o3", "v_no2": "no2", "v_so2": "so2"}	f	\N	\N	\N
846	3003	0dcf5869-2683-44e4-a0c0-ddd8e9adb8f1	125	{"σ": "stress", "physicalvalue": "F"}	f	\N	\N	\N
859	1002	a2a6365d-ec0a-453a-be54-35e11b324d63	\N	{"humidity": "humidity", "temperature": "temperature"}	f	\N	\N	\N
848	1051	a21dbc9a-38d2-4468-8149-8324e875fc8a	\N	\N	f	\N	\N	\N
852	4003	39e6fe98-3dea-458b-9f64-143d18617cc4	\N	{"height": "z", "easting": "x", "northing": "y"}	f	\N	\N	\N
853	4013	39e6fe98-3dea-458b-9f64-143d18617cc4	139	{"X": "x", "Y": "y", "Z": "h", "height": "zi", "easting": "xi", "northing": "yi"}	f	\N	\N	\N
854	4021	39e6fe98-3dea-458b-9f64-143d18617cc4	101	{"x": "y", "y": "z", "height": "yi", "northing": "xi"}	f	\N	\N	\N
855	4022	e867f531-f1a3-44c8-9876-368efe947b7d	\N	{"OU": "OU", "NH3": "NH3", "VOC": "VOC", "PM10": "PM10", "PM25": "PM2.5", "C2H5OH": "C2H5OH"}	f	\N	\N	\N
856	4023	d86466d8-8892-45e2-a86a-56e283df30ac	\N	{"OU": "OU", "CH4": "CH4", "H2S": "H2S", "NH3": "NH3"}	f	\N	\N	\N
857	4001	39e6fe98-3dea-458b-9f64-143d18617cc4	100	{"phy": "displacement", "height": "DAQi"}	f	\N	\N	\N
858	4024	e867f531-f1a3-44c8-9876-368efe947b7d	\N	{"OU": "OU", "NH3": "NH3", "VOC": "VOC", "C2H5OH": "C2H5OH"}	f	\N	\N	\N
860	1046	91766d07-1ae8-4f40-9fed-0d9a21eaf6f3	144	{"V": "volume", "physicalvalue": "Pi"}	f	\N	\N	\N
861	1005	1a7f1970-6142-4919-a1e7-110829051ba9	\N	{"physicalvalue": "waterLevel"}	f	\N	\N	\N
862	4008	43060aae-0e85-4ec6-9fc9-b05216b11e13	100	{"phy": "crack", "length": "DAQi"}	f	\N	{}	\N
462	4008	167d20c6-d128-4532-9974-d4a55788823e	100	{"phy": "crack", "lvdt": "DAQi"}	f	\N	\N	\N
863	4003	ff948ead-5a62-4990-b5c9-a440be471988	109	{"x": "x", "y": "y", "z": "z", "dx": "xi", "dy": "yi", "dz": "zi"}	f	\N	\N	\N
864	8002	07977267-d666-4b82-8976-d533e9afde5b	\N	{"PH": "temp", "oxy": "do", "turbidity": "turb", "temperature": "ph", "conductivity": "tds"}	f	\N	\N	\N
865	1048	1dcd0084-9a2d-43ef-9b10-1e8305ce8b06	\N	{"cidCode": "stateCode", "signals": "signals", "voltage": "voltage", "cidMessage": "stateMessage"}	f	\N	\N	\N
866	4026	d86466d8-8892-45e2-a86a-56e283df30ac	\N	\N	f	\N	\N	\N
867	9001	11b16ed9-a251-4907-b941-5a31ea559da1	\N	{"readingNumber": "total"}	f	\N	\N	\N
868	1046	c9eacd36-38d6-48b9-9672-e76406906ea3	144	{"V": "volume", "physicalvalue": "Pi"}	f	\N	\N	\N
869	4007	d9aab088-57f5-43ba-b30b-3342219a4b75	\N	{"X": "x", "Y": "y"}	f	\N	\N	\N
870	5002	12253047-b588-4225-9f55-e6282003788a	122	\N	f	\N	\N	\N
871	4014	e4de5a5f-c4cc-4e7e-bb0b-b34c28a89925	\N	{"speed": "speed", "height": "height", "moment": "moment", "radius": "moment", "weight": "angle", "rotation": "angle", "obliquity": "obliquity"}	f	\N	\N	\N
838	4002	d2e74fbe-59fe-420d-b127-c61ba8236f42	\N	{"anglex": "x", "angley": "y"}	f	\N	\N	\N
872	3001	73a7b800-25d7-41ad-872d-96cc4f9430de	\N	{"physicalvalue": "strain"}	f	\N	\N	\N
879	1003	c51512a6-3e90-4b6e-8a21-987464b10ca9	\N	{"physicalvalue": "rainfall"}	f	\N	\N	\N
685	4001	1c9756ed-dcf4-4156-9a43-09ce478d2038	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
880	4001	2d0ff832-a7e0-4029-94bf-d7203c1fa793	\N	{"length": "displacement"}	f	\N	\N	\N
884	9010	085307b7-181b-4059-9e81-1cbfff8fa061	\N	{"data_in": "inflow", "data_out": "outflow"}	f	\N	\N	\N
875	9010	f3a9238e-8d1c-4876-a81d-f2bb05755585	\N	{"inCount": "inflow", "outCount": "outflow"}	f	\N	\N	\N
874	1005	b7dd781d-dba7-4228-b49f-8aee75e42625	\N	{"waterlevel": "waterLevel"}	f	\N	\N	\N
878	2003	90e48651-6ab9-4f11-95e9-c2c7eb4c3c15	\N	{"physicalvalue": "pressure"}	f	\N	\N	\N
877	4001	c991c138-3b47-4a21-af81-9ba1df554176	\N	{"anglex": "displacement"}	f	\N	\N	\N
876	4002	c991c138-3b47-4a21-af81-9ba1df554176	\N	{"anglex": "x", "angley": "y"}	f	\N	\N	\N
873	4001	0b84defc-2160-4d4a-8d71-6f350b4d6666	\N	{"length": "displacement"}	f	\N	\N	\N
840	4003	e92738ba-66bf-4ec9-85c5-c1f2b4d7780e	\N	{"x": "x", "y": "y", "z": "z"}	f	\N	\N	\N
503	5001	09252236-560b-47e1-bf81-f774d303ba26	122	\N	t	122	\N	\N
881	5001	56c84083-d705-4aa0-94d2-34b731f75f97	122	\N	t	122	\N	\N
885	3001	56c84083-d705-4aa0-94d2-34b731f75f97	148	{"r": "strain", "physicalvalue": "i"}	f	\N	\N	\N
766	2006	b77b1ad2-2546-4219-bbe8-dc6b71d7fe01	135	{"σ": "δi", "physicalvalue": "F"}	t	204	{"Nc": "force"}	\N
882	5006	56c84083-d705-4aa0-94d2-34b731f75f97	\N	\N	t	222	\N	\N
883	5006	09252236-560b-47e1-bf81-f774d303ba26	\N	\N	t	222	\N	\N
536	3001	d31031ab-0237-41a5-adc0-867c1e9952f7	\N	{"physicalvalue": "strain"}	t	202	{"Δh": "strain", "physicalvalue": "pv"}	\N
842	4011	1c9756ed-dcf4-4156-9a43-09ce478d2038	201	{"Δh": "displacement", "length": "leni"}	f	\N	\N	\N
886	5003	56c84083-d705-4aa0-94d2-34b731f75f97	148	{"r": "trms", "physicalvalue": "i"}	f	\N	\N	\N
888	1005	e2ad2fb6-75a3-490f-82ae-eac117102885	\N	{"waterlevel": "waterLevel"}	f	\N	\N	\N
889	1006	c677c2a2-bc09-4171-ad9c-f9ddfbf3d046	\N	{"waterrate": "humidity"}	f	\N	\N	\N
890	1004	d1b7163a-96fb-4364-a1ec-73b29be3dbc0	\N	{"temperature": "temperature"}	f	\N	\N	\N
891	4012	ecf4b234-2797-4fbc-bf0d-0f3f41dbd017	\N	{"x": "x", "y": "y", "z": "z"}	f	\N	\N	\N
892	4003	7d999707-8940-47f8-995e-f50b44e48ede	\N	{"gx": "x", "gy": "y", "gz": "z"}	f	\N	\N	\N
887	1001	27e93aa0-1ec0-40df-aa0e-de4152459a66	\N	{"windSpeed": "speed", "windDirection": "direction"}	f	\N	\N	\N
894	4012	7c054865-5f77-4df5-9d1b-ed2c6f1bb27e	\N	{"anglex": "x", "angley": "y", "anglez": "z"}	f	\N	\N	\N
430	2004	f6b98e0f-0bfe-4a95-808c-d6d10b4c803b	\N	{"physicalvalue": "force"}	t	202	{"Δh": "force", "force": "pv"}	\N
901	4007	7c054865-5f77-4df5-9d1b-ed2c6f1bb27e	\N	{"anglex": "x", "angley": "y"}	f	\N	\N	\N
902	4001	dadaf677-ed6c-4f61-ba61-d030f157dd14	100	{"phy": "displacement", "length": "DAQi"}	f	\N	\N	\N
899	5002	8f03b15b-fbb7-4bca-ae92-2230abf071b7	122	\N	f	\N	\N	\N
898	5002	5ab5659c-c875-43de-a5cb-c2c09a6b738d	122	{}	f	\N	\N	\N
900	5002	a7e6bd92-16dd-49b0-a4c1-115a6c8b272f	122	\N	f	\N	\N	\N
811	2002	ba311e19-eea2-4eff-8674-1a146dab66c3	\N	{"speed": "carSpeed", "axisNum": "axleCount", "overload": "strOverload", "axisSpeed": "license", "crossRoad": "lane", "direction": "direction", "axieWeight": "axleLoad", "grossWeight": "load"}	f	\N	\N	\N
662	2002	32349c76-d117-4331-8a10-9b7ea057c2ab	\N	{"axisnum": "axleCount", "licence": "license", "overload": "strOverload", "axieSpeed": "carSpeed", "crossRoad": "lane", "direction": "direction", "axieWeight": "axleLoad", "grossWeight": "load"}	f	\N	\N	\N
903	9010	c892bb1b-57aa-4b52-b1eb-79172e95a8fb	\N	{"inCount": "inflow", "outCount": "outflow"}	f	\N	\N	\N
904	7030	f8803e24-c7c9-4089-8f06-5a00433131b1	\N	{"frequency": "frequency", "A_phase_volt": "A_phase_volt", "B_phase_volt": "B_phase_volt", "C_phase_volt": "C_phase_volt", "total_energy": "total_energy", "A_active_power": "A_active_power", "A_power_factor": "A_power_factor", "B_active_power": "B_active_power", "B_power_factor": "B_power_factor", "C_active_power": "C_active_power", "C_power_factor": "C_power_factor", "A_phase_current": "A_phase_current", "B_phase_current": "B_phase_current", "C_phase_current": "C_phase_current", "total_active_power": "total_active_power", "total_power_factor": "total_power_factor", "total_phase_current": "total_phase_current"}	f	\N	\N	\N
905	4009	31be3fb7-3369-4966-8e26-b561dc31b6fd	100	{"phy": "expansion", "length": "DAQi"}	f	\N	\N	\N
432	2004	8bab3e11-dc23-4082-97ec-a04e78fa19c3	\N	{"physicalvalue": "force"}	t	202	{"Δh": "force", "force": "pv"}	\N
\.


--
-- Data for Name: t_factor_proto_item; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_factor_proto_item (id, proto, name, field_name, "precision") FROM stdin;
1	1001	风速	speed	\N
2	1001	风向	direction	\N
3	1002	温度	temperature	\N
4	1002	湿度	humidity	\N
5	1003	降雨量	rainfall	\N
6	1004	温度	temperature	\N
8	1006	湿度	humidity	\N
9	1007	等效声级	soundLevel	\N
10	1007	最小	min	\N
11	1007	最大	max	\N
12	1008	渗流量	seepage	\N
13	1009	地下水位	waterLevel	\N
14	1010	干滩长度	beachWidth	\N
15	1010	库水位	waterLevel	\N
16	1011	电流	electricity	\N
17	1012	压强	pressure	\N
18	1013	液位	liquidLevel	\N
19	1014	累计流量	total	\N
20	1014	瞬时流量	instant	\N
21	1015	蚀度	corrosion	\N
22	1016	ph值	ph	\N
23	1017	浓度	concentration	\N
24	1018	浓度	concentration	\N
25	1019	爆炸下限	lel	\N
26	1020	流明	lumen	\N
27	1021	辐射强度	radiation	\N
28	1022	风速	speed	\N
29	1023	浓度	concentration	\N
30	1024	井底液位	liquidLevel	\N
31	1024	井口液位	liquidLevel	\N
32	1025	主用液位	liquidLevel	\N
33	1025	备用液位	liquidLevel	\N
34	2001	索力	cableForce	\N
35	2002	车重	load	\N
37	2003	压力	pressure	\N
38	2004	受力	force	\N
39	3001	应变	strain	\N
40	3002	最大主应力	stress	\N
41	3002	主应力方向	direction	\N
42	3003	应力	stress	\N
44	4002	X方向位移	x	\N
45	4002	Y方向位移	y	\N
46	4003	X方向位移	x	\N
47	4003	Y方向位移	y	\N
48	4003	Z方向位移	z	\N
49	4004	挠度	deflection	\N
50	4005	X方向位移	x	\N
51	4005	Y方向位移	y	\N
52	4005	X方向累积位移	xTotal	\N
53	4005	Y方向累积位移	yTotal	\N
54	4006	角度	angle	\N
57	4008	裂缝	crack	\N
58	4009	伸缩缝	expansion	\N
59	4010	X方向倾角	x	\N
60	4010	Y方向倾角	y	\N
61	4010	顶升高度A	a	\N
62	4010	顶升高度B	b	\N
63	4010	顶升高度C	c	\N
64	4010	顶升高度D	d	\N
66	5001	峰峰值	ppv	\N
67	5001	有效值	trms	\N
69	5002	峰峰值	ppv	\N
70	5002	有效值	trms	\N
72	5003	峰峰值	ppv	\N
73	5003	有效值	trms	\N
74	6001	主起变频输出转速	rotateSpeed	\N
75	6001	主起变频输出电流	electricity	\N
76	6001	主起变频输出转矩	torque	\N
77	6001	主起变频输出电压	outputVoltage	\N
78	6001	主起变频母线电压	busbarVoltage	\N
79	6001	主起位置	location	\N
80	6001	主起重量	weight	\N
81	6002	副起位置	location	\N
82	6002	副起重量	weight	\N
83	6003	大车变频输出转速	rotateSpeed	\N
84	6003	大车变频输出电流	electricity	\N
85	6003	大车变频输出转矩	torque	\N
86	6003	大车变频输出电压	outputVoltage	\N
87	6003	大车变频母线电压	busbarVoltage	\N
88	6003	大车位置	location	\N
89	6004	小车变频输出转速	rotateSpeed	\N
90	6004	小车变频输出电流	electricity	\N
91	6004	小车变频输出转矩	torque	\N
92	6004	小车变频输出电压	outputVoltage	\N
93	6004	小车变频母线电压	busbarVoltage	\N
94	6004	主起位置	location	\N
95	4011	位移	displacement	\N
96	1026	浓度	concentration	\N
97	1027	PM2.5	pm25	\N
98	1027	PM10	pm10	\N
99	1027	悬浮物	suspended	\N
100	1028	温度	temp	\N
101	1028	结冰厚度	thickness	\N
103	1029	风向	direction	\N
104	2005	重量	gravity	\N
105	4012	X轴角度	x	\N
106	4012	Y轴角度	y	\N
107	4012	Z轴角度	z	\N
108	1030	能见度	visibility	\N
109	1031	浓度	concentration	\N
111	2002	车道	lane	\N
112	2002	车牌	license	\N
113	2002	方向	direction	\N
114	2002	轴数	axleCount	\N
115	2002	轴重	axleLoad	\N
68	5002	峰值	pv	\N
65	5001	峰值	pv	\N
71	5003	峰值	pv	\N
116	4013	横向变化量	horz	\N
117	4013	纵向变化量	vert	\N
118	4013	位移变化量	position	\N
119	4013	高程变化量	height	\N
120	4013	X北坐标	x	\N
121	4013	Y横坐标	y	\N
122	4013	H高程	h	\N
123	2006	支撑轴力	force	\N
124	1032	PM2.5浓度	PM2.5	\N
125	1032	PM10浓度	PM10	\N
126	1032	SO2浓度	SO2	\N
127	1032	NO2浓度	NO2	\N
128	1032	CO浓度	CO	\N
129	1032	O3浓度	O3	\N
130	1032	总挥发性有机物浓度	TVOC	\N
131	1032	温度	temp	\N
132	1032	湿度	humidity	\N
133	1033	露点	dewpoint	\N
134	1033	光辐射	radiation	\N
137	1033	温度	temperature	\N
138	1033	湿度	humidity	\N
135	1033	CO2浓度	CO2	\N
43	4001	位移	displacement	2
55	4007	X方向角度	x	2
159	4014	载重	load	\N
160	4014	幅度	range	\N
161	4014	风速	speed	\N
162	4014	角度	angle	\N
163	4014	高度	height	\N
164	1034	温度	temperature	\N
165	1034	湿度	humidity	\N
166	1034	PM2.5	pm25	\N
167	1034	PM10	pm10	\N
168	1034	风速	speed	\N
169	1034	噪声	noise	\N
170	7001	X方向角度	x	\N
171	7001	Y方向角度	y	\N
172	7001	轴力	force	\N
173	7002	X方向角度	x	\N
174	7002	Y方向角度	y	\N
175	7002	支架水平位移	displacement	\N
176	7003	X方向角度	x	\N
177	7003	Y方向角度	y	\N
178	7003	模板沉降	settling	\N
179	1034	风向	direction	\N
180	4014	倾斜	obliquity	\N
181	8001	SO2	so2	\N
182	8001	NO2	no2	\N
183	8001	CO	co	\N
184	8001	O3	o3	\N
185	8001	PM10	pm10	\N
186	8001	PM2.5	pm2_5	\N
187	8001	VOCs	vocs	\N
188	4014	力矩	moment	\N
206	9001	电表示数	total	\N
207	9002	水表示数	total	\N
208	9003	女厕驻留人数	female_stay	\N
209	9003	女厕出流量	female_out	\N
210	9003	女厕进流量	female_in	\N
211	9003	男厕驻留人数	male_stay	\N
212	9003	男厕出流量	male_out	\N
213	9003	男厕进流量	male_in	\N
214	9004	温度	temperature	\N
215	9004	湿度	humidity	\N
216	9004	氨气浓度	nh3	\N
217	0001	状态	state	\N
219	4015	风级	windLevel	\N
220	4015	风速	windSpeed	\N
221	4015	倾角X	obliguityX	\N
222	4015	倾角Y	obliguityY	\N
223	4015	楼层	floor	\N
224	4015	高度	height	\N
225	4015	速度	speed	\N
226	4015	载重	weight	\N
227	4015	人数	peopleCnt	\N
218	4015	笼门开关状态	doorState	\N
228	1041	盐分	saltContent	\N
229	1041	电导率	conductivity	\N
230	6010	经度	lang	\N
231	6010	纬度	long	\N
232	6010	电量	power	\N
233	1035	PM2.5	pm25	\N
234	1035	PM10	pm10	\N
235	1035	噪声	noise	\N
236	1035	温度	temperature	\N
237	1035	湿度	humidity	\N
238	4016	高程	height	\N
239	8003	间隔	interval	\N
240	8003	次数	total	\N
241	8003	结束时间	timeEnd	\N
242	8003	开始时间	timeBegin	\N
243	8004	心跳	heartrate	\N
244	8004	纬度	lat	\N
245	8004	经度	lon	\N
246	8004	地址	address	\N
247	8004	城市	city	\N
248	8005	电量	power	\N
249	8006	纬度	lat	\N
250	8006	经度	lon	\N
251	8006	地址	address	\N
252	8006	城市	city	\N
253	8007	纬度	lat	\N
254	8007	经度	lon	\N
255	8007	地址	address	\N
256	8007	城市	city	\N
257	8008	心率	heartrate	\N
258	8009	步数	stepvalue	\N
259	8003	次数	count	\N
260	8003	睡眠类型	sleeptype	\N
261	7007	塑料垃圾容量	high1	\N
262	7007	纸类垃圾容量	high2	\N
263	7007	金属垃圾容量	high3	\N
264	7007	衣服垃圾容量	high4	\N
265	7007	玻璃垃圾容量	high5	\N
266	7007	有害垃圾容量	high6	\N
267	7007	电子垃圾容量	high7	\N
268	7007	纸塑品垃圾容量	high8	\N
269	7007	餐厨垃圾容量	high9	\N
270	7007	可回收垃圾容量	high10	\N
271	7007	塑料垃圾容量	high11	\N
272	7007	瓶罐垃圾容量	high12	\N
273	7007	不可回收垃圾容量	high13	\N
274	8010	NH3	nh3	\N
275	8010	VOC	voc	\N
276	8010	H2S	h2s	\N
277	8011	温度	temperature	\N
278	8011	湿度	humidity	\N
279	8011	PM100浓度	pm100	\N
280	8011	PM2.5浓度	pm2_5	\N
281	8011	PM10浓度	pm10	\N
282	8011	经度	longitude	\N
283	8011	纬度	latitude	\N
284	8011	SO2浓度	so2	\N
285	8011	NO2浓度	no2	\N
286	8011	O3浓度	o3	\N
287	8011	CO浓度	co	\N
288	8011	VOC浓度	voc	\N
289	9005	门1	DI1	\N
290	9005	门2	DI2	\N
291	9005	门3	DI3	\N
292	4018	仰拱安全步距	arch	\N
293	4018	掌子面安全步距	tunnelface	\N
294	9010	进入流量	inflow	\N
295	9010	出去流量	outflow	\N
296	6010	速度	speed	\N
297	2005	载重百分比	weightPercent	\N
299	1045	流量	flow	\N
301	1047	进水量	volume	\N
302	8012	恶臭	Odor	\N
303	8012	氨气	NH3	\N
304	8012	硫化氢	H2S	\N
305	8012	VOCS	VOCS	\N
306	1048	状态码	stateCode	\N
110	2002	超载	strOverload	\N
307	3006	应力	stress	\N
308	4014	在线状态	online	\N
309	4020	沉降	x	\N
310	4020	相邻沉降	diffX	\N
311	8013	运行时长	runtime	\N
312	8013	有功电能	pEnergy	\N
313	8013	在线状态(0不在线,1在线)	online	\N
314	8013	电压	voltage	\N
315	8013	状态(1开灯,0关灯)	on	\N
316	8013	亮度(百分比)	bri	\N
317	8013	频率	frequency	\N
318	8013	灯杆编号	lampPoleNumber	\N
319	5041	状态码	stateCode	\N
189	8002	PH值	ph	2
190	8002	电导	tds	2
191	8002	溶解氧	do	2
192	8002	浊度	turb	2
193	8002	温度	temp	2
320	1048	状态信息	stateMessage	\N
321	1048	电压	voltage	\N
322	1048	信号强度	signals	\N
323	7008	轨心距	distance	\N
324	5041	状态信息	stateMessage	\N
325	5041	电压	voltage	\N
326	5041	信号强度	signals	\N
327	8013	告警状态	alarm_status	\N
328	8013	纬度	latitude	\N
329	8013	经度	longitude	\N
330	8013	网关名称	gatewayName	\N
331	7009	重量	weight	\N
332	7009	垃圾量	trash	\N
333	7009	温度	temprature	\N
334	7009	日用电量	usedelectric	\N
335	7009	日充电量	electric	\N
336	7009	信号强度	signal	\N
337	7009	纬度	latitude	\N
338	7009	经度	longitude	\N
339	7009	状态码	stateCode 	\N
340	7009	状态信息	stateMessage	\N
342	4021	Y方向位移	y	\N
343	4021	Z方向位移	z	\N
344	2002	车速	carSpeed	\N
346	5005	振动加速度级	arrAcc	\N
347	1050	总磷	totalPhosphorus	\N
348	2014	受力	force	\N
349	2014	温度	temperature	\N
345	5005	分频最大振级	soundLevel	\N
350	3007	应力	force	\N
351	1052	太阳辐射值	solarRadiation	\N
352	1051	温度	temperature	\N
353	1051	湿度	humidity	\N
354	1051	气压	pressure	\N
355	4023	氨气	NH3	\N
356	4023	硫化氢	H2S	\N
357	4023	甲烷	CH4	\N
358	4023	臭气	OU	\N
359	4022	氨气	NH3	\N
360	4022	乙醇	C2H5OH	\N
361	4022	PM2.5	PM2.5	\N
362	4022	PM10	PM10	\N
363	4022	VOC	VOC	\N
364	4022	臭气	OU	\N
365	4024	氨气	NH3	\N
366	4024	乙醇	C2H5OH	\N
367	4024	VOC	VOC	\N
368	4024	臭气	OU	\N
56	4007	Y方向角度	y	2
369	7010	水压	pressure	\N
370	7010	倾斜角度	angle	\N
371	7011	电流	current	\N
372	7011	温度	temperature	\N
373	4025	X轴角度	x	\N
374	4025	Y轴角度	y	\N
375	4025	Z轴角度	z	\N
376	4025	X轴加速度	xAcc	\N
377	4025	Y轴加速度	yAcc	\N
378	4025	Z轴加速度	zAcc	\N
379	4025	信号	signal	\N
380	4025	电压	Voltage	\N
381	4025	传感器状态	state	\N
382	4026	氨气	NH3	\N
383	4026	硫化氢	H2S	\N
384	4026	臭气	OU	\N
7	1005	水位	waterLevel	2
300	1046	库容	volume	2
385	8022	一氧化碳	CO	\N
386	8022	氨气	CH4	\N
387	8022	硫化氢	H2S	\N
388	8022	臭氧	O3	\N
389	8022	温度	temp	\N
390	8022	湿度	humidity	\N
391	5006	X峰值	x	\N
392	5006	Y峰值	y	\N
393	5006	Z峰值	z	\N
394	8033	标签与基站距离	distance	\N
395	8033	标签状态	state	\N
396	8033	基站ID	station_id	\N
397	7030	A相电压	A_phase_volt	\N
398	7030	B相电压	B_phase_volt	\N
399	7030	C相电压	C_phase_volt	\N
400	7030	A相电流	A_phase_current	\N
401	7030	B相电流	B_phase_current	\N
402	7030	C相电流	C_phase_current	\N
403	7030	三相电流矢量和	total_phase_current	\N
404	7030	A相有功功率	A_active_power	\N
405	7030	B相有功功率	B_active_power	\N
406	7030	C相有功功率	C_active_power	\N
407	7030	总有功功率	total_active_power	\N
408	7030	A相功率因数	A_power_factor	\N
409	7030	B相功率因数	B_power_factor	\N
410	7030	C相功率因数	C_power_factor	\N
411	7030	总相功率因数	total_power_factor	\N
412	7030	频率	frequency	\N
413	7030	频率	total_energy	\N
\.


--
-- Data for Name: t_filter_method; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_filter_method (id, type, name, params) FROM stdin;
1	1	取中值	{"窗口": "正整数"}
2	1	限幅	{"波幅": "正数"}
3	1	滑动平均	{"窗口": "正整数"}
4	2	方差判断平均	{"倍数": "正数", "窗口": "正整数"}
5	2	滤波算法	{"D": "正整数", "K": "正数", "ReCalc": "正整数", "窗口": "正整数"}
6	2	去极值移动平均	{"上限": "数字", "下限": "数字", "窗口": "正整数"}
7	2	加权滑动平均	{"窗口": "正整数"}
8	2	中值平均	{"窗口": "正整数"}
9	2	限幅平均	{"波幅": "正数", "窗口": "正整数"}
9999	3	SJTH	{}
\.


--
-- Data for Name: t_group_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_group_type (type_code, name, description, params, present) FROM stdin;
001	展示分组	普通展示分组	{}	t
101	浸润线分组	浸润线展示分组	{"height": {"name": "高度", "type": "number", "unit": "m"}}	t
102	索力分组	索力展示分组	{"location": {"name": "位置", "type": "number", "unit": "m"}}	t
103	挠度分组	挠度展示分组	{"location": {"name": "位置", "type": "number", "unit": "m"}}	t
104	深层水平位移分组	深层水平位移展示分组	{"depth": {"name": "深度", "type": "number", "unit": "m"}}	t
201	深层水平位移计算分组	深层水平位移计算分组	{"depth": {"name": "深度", "type": "number", "unit": "m"}}	f
202	压差测沉降计算分组	压差连通管计算分组	{"base": {"name": "基准点", "type": "boolean", "unit": ""}}	f
\.


--
-- Data for Name: t_group_type_factor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_group_type_factor (id, group_type, proto) FROM stdin;
1	101	1009
2	102	2001
3	103	4004
4	104	4005
\.


--
-- Data for Name: t_item_unit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_item_unit (id, name, item, if_default, transform) FROM stdin;
1	m/s	1	t	1.000000
2	°	2	t	1.000000
3	℃	3	t	1.000000
4	%RH	4	t	1.000000
5	mm	5	t	1.000000
6	℃	6	t	1.000000
7	m	7	t	1.000000
8	%RH	8	t	1.000000
9	dB	9	t	1.000000
10	dB	10	t	1.000000
11	dB	11	t	1.000000
12	m3/s	12	t	1.000000
13	m	13	t	1.000000
14	m	14	t	1.000000
15	m	15	t	1.000000
16	A	16	t	1.000000
17	kPa	17	t	1.000000
18	m	18	t	1.000000
19	m^3	19	t	1.000000
20	Nm^3h	20	t	1.000000
21	NTU	21	t	1.000000
22	ph	22	t	1.000000
23	%Vol	23	t	1.000000
24	ppm	24	t	1.000000
25	%LEL	25	t	1.000000
26	Lux	26	t	1.000000
27	W/sr	27	t	1.000000
28	m/s	28	t	1.000000
29	ms/cm	29	t	1.000000
30	m	30	t	1.000000
31	m	31	t	1.000000
32	mm	32	t	1.000000
33	mm	33	t	1.000000
34	kN	34	t	1.000000
35	T	35	t	1.000000
37	kN	38	t	1.000000
38	με	39	t	1.000000
39	MPa	40	t	1.000000
40	°	41	t	1.000000
41	MPa	42	t	1.000000
42	mm	43	t	1.000000
43	mm	44	t	1.000000
44	mm	45	t	1.000000
45	mm	46	t	1.000000
46	mm	47	t	1.000000
47	mm	48	t	1.000000
48	mm	49	t	1.000000
49	mm	50	t	1.000000
50	mm	51	t	1.000000
51	mm	52	t	1.000000
52	mm	53	t	1.000000
53	°	54	t	1.000000
54	°	55	t	1.000000
55	°	56	t	1.000000
56	mm	57	t	1.000000
57	mm	58	t	1.000000
58	°	59	t	1.000000
59	°	60	t	1.000000
60	mm	61	t	1.000000
61	mm	62	t	1.000000
62	mm	63	t	1.000000
63	mm	64	t	1.000000
64	cm/s	65	t	1.000000
65	cm/s	66	t	1.000000
66	cm/s	67	t	1.000000
67	gal	68	t	1.000000
68	gal	69	t	1.000000
69	gal	70	t	1.000000
70	με	71	t	1.000000
71	με	72	t	1.000000
72	με	73	t	1.000000
73	r/min	74	t	1.000000
74	A	75	t	1.000000
75	%	76	t	1.000000
76	V	77	t	1.000000
77	V	78	t	1.000000
78	m	79	t	1.000000
79	T	80	t	1.000000
80	m	81	t	1.000000
81	T	82	t	1.000000
82	r/min	83	t	1.000000
83	A	84	t	1.000000
84	%	85	t	1.000000
85	V	86	t	1.000000
86	V	87	t	1.000000
87	m	88	t	1.000000
88	r/min	89	t	1.000000
89	A	90	t	1.000000
90	%	91	t	1.000000
91	V	92	t	1.000000
92	V	93	t	1.000000
93	m	94	t	1.000000
94	mm	95	t	1.000000
95	μg/m3	96	t	1.000000
96	μg/m3	97	t	1.000000
97	μg/m3	98	t	1.000000
98	μg/m3	99	t	1.000000
99	℃	100	t	1.000000
100	mm	101	t	1.000000
101	°	103	t	1.000000
102	kg	104	t	1.000000
103	°	105	t	1.000000
104	°	106	t	1.000000
105	°	107	t	1.000000
106	m	108	t	1.000000
107	μmol/mol	109	t	1.000000
108		110	t	1.000000
109		111	t	1.000000
110		112	t	1.000000
111		113	t	1.000000
112		114	t	1.000000
121	kN	123	t	1.000000
122	ug/m3	124	t	1.000000
123	ug/m3	125	t	1.000000
124	ppb	126	t	1.000000
125	ppb	127	t	1.000000
126	ppm	128	t	1.000000
127	ppb	129	t	1.000000
128	ppm	130	t	1.000000
129	℃	131	t	1.000000
130	%RH	132	t	1.000000
131	℃	133	t	1.000000
132	μM/m^2	134	t	1.000000
133	ppm	135	t	1.000000
134	℃	137	t	1.000000
135	%	138	t	1.000000
156	T	159	t	1.000000
157	m	160	t	1.000000
158	m/s	161	t	1.000000
159	°	162	t	1.000000
160	m	163	t	1.000000
167	°	170	t	1.000000
168	°	171	t	1.000000
169	kN	172	t	1.000000
170	°	173	t	1.000000
171	°	174	t	1.000000
172	mm	175	t	1.000000
173	°	176	t	1.000000
174	°	177	t	1.000000
175	mm	178	t	1.000000
163	μg/m3	166	t	1.000000
164	μg/m3	167	t	1.000000
161	℃	164	t	1.000000
162	%RH	165	t	1.000000
165	m/s	168	t	1.000000
166	dB	169	t	1.000000
36	KPa	37	t	1.000000
114	mm	116	t	1.000000
113	T	115	t	1.000000
177	°	180	t	1.000000
178	μg/m3	181	t	1.000000
179	μg/m3	182	t	1.000000
180	mg/m3	183	t	1.000000
181	μg/m3	184	t	1.000000
182	μg/m3	185	t	1.000000
183	μg/m3	186	t	1.000000
184	μg/m3	187	t	1.000000
185	%	188	t	1.000000
186	pH	189	t	1.000000
187	μS/cm	190	t	1.000000
188	mg/L	191	t	1.000000
189	NTU	192	t	1.000000
190	℃	193	t	1.000000
203	kW·h	206	t	1.000000
204	m3	207	t	1.000000
205	人	208	t	1.000000
206	人	209	t	1.000000
207	人	210	t	1.000000
208	人	211	t	1.000000
209	人	212	t	1.000000
210	人	213	t	1.000000
211	℃	214	t	1.000000
212	%RH	215	t	1.000000
213	ppm	216	t	1.000000
214		217	t	1.000000
215	 	218	t	1.000000
216	级	219	t	1.000000
217	级	220	t	1.000000
218	°	221	t	1.000000
219	°	222	t	1.000000
220	层	223	t	1.000000
221	m	224	t	1.000000
222	m/s	225	t	1.000000
223	t	226	t	1.000000
224	人	227	t	1.000000
176	°	179	t	1.000000
225	mg/L	228	t	1.000000
226	mS/cm	229	t	1.000000
227	°	230	t	1.000000
228	°	231	t	1.000000
229	%	232	t	1.000000
230	μg/m3	233	t	1.000000
231	μg/m3	234	t	1.000000
232	dB	235	t	1.000000
233	℃	236	t	1.000000
234	%RH	237	t	1.000000
235	m	238	t	1.000000
236	min	239	t	1.000000
237	次	240	t	1.000000
238		241	t	1.000000
239		242	t	1.000000
240	bpm	243	t	1.000000
241	°	244	t	1.000000
242	°	245	t	1.000000
243		246	t	1.000000
244		247	t	1.000000
245	%	248	t	1.000000
246	°	249	t	1.000000
247	°	250	t	1.000000
248		251	t	1.000000
249		252	t	1.000000
250	°	253	t	1.000000
251	°	254	t	1.000000
252		255	t	1.000000
253		256	t	1.000000
254	bpm	257	t	1.000000
255	步	258	t	1.000000
256	次	259	t	1.000000
257		260	t	1.000000
258	%	261	t	1.000000
259	%	262	t	1.000000
260	%	263	t	1.000000
261	%	264	t	1.000000
262	%	265	t	1.000000
263	%	266	t	1.000000
264	%	267	t	1.000000
265	%	268	t	1.000000
266	%	269	t	1.000000
267	%	270	t	1.000000
268	%	271	t	1.000000
269	%	272	t	1.000000
270	%	273	t	1.000000
271	mg/m3	274	t	1.000000
272	mg/m3	275	t	1.000000
273	mg/m3	276	t	1.000000
274	℃	277	t	1.000000
275	%RH	278	t	1.000000
276	μg/m3	279	t	1.000000
277	μg/m3	280	t	1.000000
278	μg/m3	281	t	1.000000
279	°	282	t	1.000000
280	°	283	t	1.000000
281	μg/m3	284	t	1.000000
282	μg/m3	285	t	1.000000
283	μg/m3	286	t	1.000000
284	μg/m3	287	t	1.000000
285	μg/m3	288	t	1.000000
286		289	t	1.000000
287		290	t	1.000000
288		291	t	1.000000
289	cm	292	t	1.000000
290	cm	293	t	1.000000
291	人	294	t	1.000000
292	人	295	t	1.000000
293	m/s	296	t	1.000000
294	%	297	t	1.000000
298	m³	301	t	1.000000
299		302	t	1.000000
300	g/h	303	t	1.000000
301	g/h	304	t	1.000000
302	g/h	305	t	1.000000
303		306	t	1.000000
304	MPa	307	t	1.000000
305		308	t	1.000000
306	mm	309	t	1.000000
307	mm	310	t	1.000000
308	h	311	t	1.000000
309	KW	312	t	1.000000
310	 	313	t	1.000000
311	V	314	t	1.000000
312	 	315	t	1.000000
313	%	316	t	1.000000
314	HZ	317	t	1.000000
315	 	318	t	1.000000
316		319	t	1.000000
317	 	320	t	1.000000
318	V	321	t	1.000000
319	dB	322	t	1.000000
297	万m³	300	t	1.000000
320	mm	323	t	1.000000
115	mm	117	t	1.000000
116	mm	118	t	1.000000
117	mm	119	t	1.000000
118	mm	120	t	1.000000
119	mm	121	t	1.000000
120	mm	122	t	1.000000
321	 	324	t	1.000000
322	V	325	t	1.000000
323	dB	326	t	1.000000
324	 	327	t	1.000000
325	 	328	t	1.000000
326	 	329	t	1.000000
327	 	330	t	1.000000
328	kg	331	t	1.000000
329	%	332	t	1.000000
330	℃	333	t	1.000000
331	瓦	334	t	1.000000
332	瓦	335	t	1.000000
333	dB	336	t	1.000000
334	°	337	t	1.000000
335		339	t	1.000000
336		340	t	1.000000
337	mm	342	t	1.000000
338	mm	343	t	1.000000
339	°	338	t	1.000000
340	km/h	344	t	1.000000
341	dB	345	t	1.000000
342	dB	346	t	1.000000
343	mg/L	347	t	1.000000
344	kN	348	t	1.000000
345	℃	349	t	1.000000
346	kPa	350	t	1.000000
347	W/㎡	351	t	1.000000
348	℃	352	t	1.000000
349	%RH	353	t	1.000000
350	Kpa	354	t	1.000000
367	mA	371	t	1.000000
355	mg/m3	359	t	1.000000
356	mg/m3	360	t	1.000000
357	mg/m3	361	t	1.000000
361	mg/m3	365	t	1.000000
362	mg/m3	366	t	1.000000
364		368	t	1.000000
365	MPa	369	t	1.000000
366	°	370	t	1.000000
360		364	t	1.000000
359	mg/m3	363	t	1.000000
368	℃	372	t	1.000000
358	mg/m3	362	t	1.000000
351	mg/m3	355	t	1.000000
353	mg/m3	357	t	1.000000
352	mg/m3	356	t	1.000000
363	mg/m3	367	t	1.000000
354		358	t	1.000000
369	°	373	t	1.000000
370	°	374	t	1.000000
371	°	375	t	1.000000
372	mg	376	t	1.000000
373	mg	377	t	1.000000
374	mg	378	t	1.000000
375		379	t	1.000000
376	V	380	t	1.000000
377		381	t	1.000000
378	mg/m3	382	t	1.000000
379	mg/m3	383	t	1.000000
380		384	t	1.000000
296	m³/s	299	t	1.000000
381	ppm	385	t	1.000000
382	ppm	386	t	1.000000
383	ppm	387	t	1.000000
384	ppm	388	t	1.000000
385	℃	389	t	1.000000
386	%	390	t	1.000000
387	cm/s	391	t	1.000000
388	cm/s	392	t	1.000000
389	cm/s	393	t	1.000000
390	m	394	t	1.000000
391	 	395	t	1.000000
392	 	396	t	1.000000
393	V	397	t	1.000000
394	V	398	t	1.000000
395	V	399	t	1.000000
396	A	400	t	1.000000
397	A	401	t	1.000000
398	A	402	t	1.000000
399	A	403	t	1.000000
400	KW	404	t	1.000000
401	KW	405	t	1.000000
402	KW	406	t	1.000000
403	KW	407	t	1.000000
404	 	408	t	1.000000
405	 	409	t	1.000000
406	 	410	t	1.000000
407	 	411	t	1.000000
408	HZ	412	t	1.000000
409	KW	413	t	1.000000
\.


--
-- Data for Name: t_layout_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_layout_type (id, name) FROM stdin;
1	2d整体
2	2d部件
3	3d整体
4	3d部件
\.


--
-- Data for Name: t_message_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_message_type (id, name) FROM stdin;
1	系统公告
\.


--
-- Data for Name: t_project_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_project_type (id, type_name, description) FROM stdin;
1	smartsite	智慧工地
2	bridge	中小桥
4	community	小区
5	smartToilet	智慧公厕
6	smartWorkSafety	智慧安监
7	smartFireControl	智慧消防
\.


--
-- Data for Name: t_type_report_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_type_report_type (id, name, description) FROM stdin;
0	日报	\N
1	周报	\N
2	月报	\N
3	年报	\N
\.


--
-- Data for Name: t_report_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_report_template (id, name, description, handler, file_link, factor_proto, structure, report_type, manual, cells, struct_type, structs, params) FROM stdin;
4	通用日报模板	通用模板	temp_comm	daily/daily.xlsx	\N	\N	0	f	{"data": {"count": 7, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "init-value", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "last-mv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "current-mv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "last-cv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "current-cv", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "current-accum-cv", "coords_col": 6, "factor_items": ""}], "sortByExt": null, "coords_row": 5}, "tempType": "daily", "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 1, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 2, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 2, "colum": 4}}, {"name": "[itemName]", "coords": {"row": 4, "colum": 1}}, {"name": "[unit]", "coords": {"row": 4, "colum": 1}}, {"name": "[itemName]", "coords": {"row": 4, "colum": 2}}, {"name": "[unit]", "coords": {"row": 4, "colum": 2}}, {"name": "[itemName]", "coords": {"row": 4, "colum": 3}}, {"name": "[unit]", "coords": {"row": 4, "colum": 3}}, {"name": "[itemName]", "coords": {"row": 4, "colum": 4}}, {"name": "[unit]", "coords": {"row": 4, "colum": 4}}, {"name": "[itemName]", "coords": {"row": 4, "colum": 5}}, {"name": "[unit]", "coords": {"row": 4, "colum": 5}}, {"name": "[itemName]", "coords": {"row": 4, "colum": 6}}, {"name": "[unit]", "coords": {"row": 4, "colum": 6}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	\N
6	通用周报模板	\N	temp_comm	weekly/weekly.xlsx	\N	\N	1	f	{"data": {"count": 11, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "init-value", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "every-accum-cv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "current-cv", "coords_col": 9, "factor_items": ""}, {"index": 4, "valueType": "current-accum-cv", "coords_col": 10, "factor_items": ""}], "sortByExt": null, "coords_row": 7}, "tempType": "weekly", "head_items": [{"name": "[factorName]", "coords": {"row": 2, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 0, "colum": 0}}, {"name": "[dateFrom]", "coords": {"row": 3, "colum": 0}}, {"name": "[dateTo]", "coords": {"row": 3, "colum": 0}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 1}}, {"name": "[unit]", "coords": {"row": 6, "colum": 1}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 2}}, {"name": "[unit]", "coords": {"row": 6, "colum": 2}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 3}}, {"name": "[unit]", "coords": {"row": 6, "colum": 3}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 4}}, {"name": "[unit]", "coords": {"row": 6, "colum": 4}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 5}}, {"name": "[unit]", "coords": {"row": 6, "colum": 5}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 6}}, {"name": "[unit]", "coords": {"row": 6, "colum": 6}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 7}}, {"name": "[unit]", "coords": {"row": 6, "colum": 7}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 8}}, {"name": "[unit]", "coords": {"row": 6, "colum": 8}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 9}}, {"name": "[unit]", "coords": {"row": 6, "colum": 9}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 10}}, {"name": "[unit]", "coords": {"row": 6, "colum": 10}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	\N
7	通用月报模板	\N	temp_comm	monthly/monthly.xlsx	\N	\N	2	f	{"data": {"count": 11, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "init-value", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "every-accum-cv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "current-cv", "coords_col": 33, "factor_items": ""}, {"index": 4, "valueType": "current-accum-cv", "coords_col": 34, "factor_items": ""}, {"index": 5, "valueType": "c-speed", "coords_col": 35, "factor_items": ""}], "sortByExt": null, "coords_row": 7}, "tempType": "monthly", "head_items": [{"name": "[factorName]", "coords": {"row": 2, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 0, "colum": 0}}, {"name": "[dateFrom]", "coords": {"row": 3, "colum": 0}}, {"name": "[dateTo]", "coords": {"row": 3, "colum": 0}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 1}}, {"name": "[unit]", "coords": {"row": 6, "colum": 1}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 2}}, {"name": "[unit]", "coords": {"row": 6, "colum": 2}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 3}}, {"name": "[unit]", "coords": {"row": 6, "colum": 3}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 4}}, {"name": "[unit]", "coords": {"row": 6, "colum": 4}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 5}}, {"name": "[unit]", "coords": {"row": 6, "colum": 5}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 6}}, {"name": "[unit]", "coords": {"row": 6, "colum": 6}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 7}}, {"name": "[unit]", "coords": {"row": 6, "colum": 7}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 8}}, {"name": "[unit]", "coords": {"row": 6, "colum": 8}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 9}}, {"name": "[unit]", "coords": {"row": 6, "colum": 9}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 10}}, {"name": "[unit]", "coords": {"row": 6, "colum": 10}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 11}}, {"name": "[unit]", "coords": {"row": 6, "colum": 11}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 12}}, {"name": "[unit]", "coords": {"row": 6, "colum": 12}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 13}}, {"name": "[unit]", "coords": {"row": 6, "colum": 13}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 14}}, {"name": "[unit]", "coords": {"row": 6, "colum": 14}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 15}}, {"name": "[unit]", "coords": {"row": 6, "colum": 15}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 16}}, {"name": "[unit]", "coords": {"row": 6, "colum": 16}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 17}}, {"name": "[unit]", "coords": {"row": 6, "colum": 17}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 18}}, {"name": "[unit]", "coords": {"row": 6, "colum": 18}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 19}}, {"name": "[unit]", "coords": {"row": 6, "colum": 19}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 20}}, {"name": "[unit]", "coords": {"row": 6, "colum": 20}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 21}}, {"name": "[unit]", "coords": {"row": 6, "colum": 21}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 22}}, {"name": "[unit]", "coords": {"row": 6, "colum": 22}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 23}}, {"name": "[unit]", "coords": {"row": 6, "colum": 23}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 24}}, {"name": "[unit]", "coords": {"row": 6, "colum": 24}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 25}}, {"name": "[unit]", "coords": {"row": 6, "colum": 25}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 26}}, {"name": "[unit]", "coords": {"row": 6, "colum": 26}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 27}}, {"name": "[unit]", "coords": {"row": 6, "colum": 27}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 28}}, {"name": "[unit]", "coords": {"row": 6, "colum": 28}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 29}}, {"name": "[unit]", "coords": {"row": 6, "colum": 29}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 30}}, {"name": "[unit]", "coords": {"row": 6, "colum": 30}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 31}}, {"name": "[unit]", "coords": {"row": 6, "colum": 31}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 32}}, {"name": "[unit]", "coords": {"row": 6, "colum": 32}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 33}}, {"name": "[unit]", "coords": {"row": 6, "colum": 33}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 34}}, {"name": "[unit]", "coords": {"row": 6, "colum": 34}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 35}}, {"name": "[unit]", "coords": {"row": 6, "colum": 35}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	\N
8	通用人工监测日报模板	通用模板	temp_mcomm	daily/mc-daily.xlsx	\N	\N	0	t	{"data": {"count": 11, "station": [{"index": 0, "valueType": "data-index", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "location", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "init-value", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "last-mv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "current-mv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "current-cv", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "c-speed", "coords_col": 6, "factor_items": ""}, {"index": 7, "valueType": "current-accum-cv", "coords_col": 7, "factor_items": ""}], "sortByExt": null, "coords_row": 7}, "tempType": "daily", "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 6, "colum": 3}}, {"name": "[thisMonitorDate]", "coords": {"row": 3, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 6, "colum": 4}}, {"name": "[unit]", "coords": {"row": 5, "colum": 2}}, {"name": "[unit]", "coords": {"row": 5, "colum": 3}}, {"name": "[unit]", "coords": {"row": 5, "colum": 4}}, {"name": "[unit]", "coords": {"row": 5, "colum": 5}}, {"name": "[unit]", "coords": {"row": 5, "colum": 6}}, {"name": "[unit]", "coords": {"row": 5, "colum": 7}}, {"name": "[unit]", "coords": {"row": 5, "colum": 8}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 9, "endRow": 21, "startCol": 0, "startRow": 20}, "factorItem": ""}], "extGroupItems": null}	{}	{}	\N
5	内部位移	通用模板	temp_internal_displacement-comm	daily/daily.xlsx	\N	\N	0	f	{"data": {"count": 20, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "last-mv", "coords_col": 2, "factor_items": "xTotal,yTotal"}, {"index": 3, "valueType": "current-mv", "coords_col": 4, "factor_items": "xTotal,yTotal"}, {"index": 5, "valueType": "current-cv", "coords_col": 6, "factor_items": "xTotal,yTotal"}], "sortByExt": "depth", "coords_row": 5}, "tempType": "daily", "head_items": [{"name": "[structureName]", "coords": {"row": 1, "colum": 0}}, {"name": "[LastDate]", "coords": {"row": 2, "colum": 0}}, {"name": "[ThisDate]", "coords": {"row": 2, "colum": 6}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 10, "endRow": 25, "startCol": 8, "startRow": 3}, "factorItem": "xTotal"}, {"coords": {"endCol": 13, "endRow": 25, "startCol": 11, "startRow": 3}, "factorItem": "yTotal"}], "extGroupItems": [{"name": "depth", "colum": 1}]}	{}	{}	\N
11	Word报表通用模板	\N			\N	\N	0	f	{"body": [{"index": 1, "title": "项目概况", "content": "structure"}, {"index": 2, "title": "监测数据分析", "content": "factors"}, {"index": 4, "title": "结论与建议", "content": "summary"}], "covers": [{"row": 3, "index": 1, "content": "$structure_name$自动化监测报告"}]}	{}	{}	\N
12	刘家坪日模板	\N	temp_daily_ljp	daily/ljp-daily.xlsx	\N	\N	0	f	{"data": {"count": 25, "station": [{"index": 0, "valueType": "current-mv", "coords_col": 1, "factor_items": ""}, {"index": 1, "valueType": "data_time", "coords_col": 0, "factor_items": ""}], "sortByExt": null, "coords_row": 4}, "tempType": "daily", "head_items": [{"name": "[structureName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 1, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 29, "colum": 5}}, {"name": "[unit]", "coords": {"row": 3, "colum": 1}}, {"name": "[factorName]", "coords": {"row": 3, "colum": 1}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	\N
13	刘家坪月模板	\N	temp_month_ljp	daily/ljp-daily.xlsx	\N	\N	2	f	{"data": {"count": 1, "station": [{"index": 0, "valueType": "current-mv", "coords_col": 1, "factor_items": ""}], "sortByExt": null, "coords_row": 4}, "tempType": "monthly", "head_items": [{"name": "[structureName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 1, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 5, "colum": 6}}, {"name": "[thisMonitorDate]", "coords": {"row": 4, "colum": 0}}, {"name": "[unit]", "coords": {"row": 3, "colum": 1}}, {"name": "[factorName]", "coords": {"row": 3, "colum": 1}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	\N
10	沉降类人工监测模板	\N	temp_mcomm_subside	daily/mc-daily.xlsx		\N	0	t	{"data": {"count": 11, "station": [{"index": 0, "valueType": "data-index", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "location", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "init-value", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "last-mv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "current-mv", "coords_col": 4, "factor_items": ""}, {"coef": 1000.0, "index": 5, "valueType": "current-cv", "coords_col": 5, "factor_items": ""}, {"coef": 1000.0, "index": 6, "valueType": "c-speed", "coords_col": 6, "factor_items": ""}, {"coef": 1000.0, "index": 7, "valueType": "current-accum-cv", "coords_col": 7, "factor_items": ""}], "sortByExt": null, "coords_row": 7}, "tempType": "daily", "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 6, "colum": 3}}, {"name": "[thisMonitorDate]", "coords": {"row": 3, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 6, "colum": 4}}, {"name": "[unit]", "coords": {"row": 5, "colum": 2}}, {"name": "[unit]", "coords": {"row": 5, "colum": 3}}, {"name": "[unit]", "coords": {"row": 5, "colum": 4}}, {"name": "[unit]", "coords": {"row": 5, "colum": 5}}, {"name": "[unit]", "coords": {"row": 5, "colum": 6}}, {"name": "[unit]", "coords": {"row": 5, "colum": 7}}, {"name": "[unit]", "coords": {"row": 5, "colum": 8}}, {"name": "[weather]", "coords": {"row": 3, "colum": 3}}, {"name": "[calendar_content]", "coords": {"row": 19, "colum": 2}}, {"name": "[stage]", "coords": {"row": 1, "colum": 6}}, {"name": "[observe_days]", "coords": {"row": 3, "colum": 4}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 9, "endRow": 21, "startCol": 0, "startRow": 20}, "factorItem": ""}], "extGroupItems": null}	{}	{}	\N
9	深部水平位移人工监测模板	深部水平位移人工监测模板	temp_mc_internal_displacement	daily/mc-daily.xlsx	4005	\N	0	t	{"data": {"count": 38, "station": [{"index": 1, "valueType": "current-cv", "coords_col": 1, "factor_items": "yTotal"}, {"index": 2, "valueType": "last-accum-cv", "coords_col": 2, "factor_items": "yTotal"}, {"index": 3, "valueType": "current-accum-cv", "coords_col": 3, "factor_items": "yTotal"}, {"index": 4, "valueType": "c-speed", "coords_col": 4, "factor_items": "yTotal"}], "sortType": "asc", "sortByExt": "depth", "coords_row": 7}, "tempType": "daily", "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 3, "colum": 0}}, {"name": "[weather]", "coords": {"row": 3, "colum": 3}}, {"name": "[calendar_content]", "coords": {"row": 46, "colum": 2}}, {"name": "[stage]", "coords": {"row": 1, "colum": 6}}], "sheetIndex": 4, "tail_items": null, "chart_coords": [{"coords": {"endCol": 9, "endRow": 45, "startCol": 5, "startRow": 7}, "factorItem": "yTotal"}], "extGroupItems": [{"name": "depth", "colum": 0}]}	{}	{}	\N
14	地下水位人工模板	\N	temp_mcomm_waterlevel	daily/mc-daily.xlsx	\N	\N	0	t	{"data": {"count": 11, "station": [{"index": 0, "valueType": "data-index", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "location", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "init-value", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "last-mv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "current-mv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "current-cv", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "c-speed", "coords_col": 6, "factor_items": ""}, {"index": 7, "valueType": "current-accum-cv", "coords_col": 7, "factor_items": ""}], "sortByExt": null, "coords_row": 7}, "tempType": "daily", "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 6, "colum": 3}}, {"name": "[thisMonitorDate]", "coords": {"row": 3, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 6, "colum": 4}}, {"name": "[unit]", "coords": {"row": 5, "colum": 2}}, {"name": "[unit]", "coords": {"row": 5, "colum": 3}}, {"name": "[unit]", "coords": {"row": 5, "colum": 4}}, {"name": "[unit]", "coords": {"row": 5, "colum": 5}}, {"name": "[unit]", "coords": {"row": 5, "colum": 6}}, {"name": "[unit]", "coords": {"row": 5, "colum": 7}}, {"name": "[unit]", "coords": {"row": 5, "colum": 8}}, {"name": "[weather]", "coords": {"row": 3, "colum": 3}}, {"name": "[calendar_content]", "coords": {"row": 19, "colum": 2}}, {"name": "[observe_days]", "coords": {"row": 3, "colum": 4}}, {"name": "[stage]", "coords": {"row": 1, "colum": 6}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 9, "endRow": 21, "startCol": 0, "startRow": 20}, "factorItem": ""}], "extGroupItems": null}	{}	{}	\N
24	苏州人工监测水位模板	苏州人工监测水位模板	temp_water-level	daily/suzhou-template.xlsx	\N	\N	0	t	{"data": {"count": 25, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"unit": "mm", "index": 1, "valueType": "current-cv", "coords_col": 1, "factor_items": ""}, {"unit": "mm", "index": 2, "valueType": "current-accum-cv", "coords_col": 2, "factor_items": ""}, {"unit": "mm", "index": 3, "valueType": "c-speed", "coords_col": 3, "factor_items": ""}, {"unit": "mm", "index": 4, "valueType": "init-value", "coords_col": 4, "factor_items": ""}, {"unit": "mm", "index": 5, "valueType": "last-mv", "coords_col": 5, "factor_items": ""}, {"unit": "mm", "index": 6, "valueType": "current-mv", "coords_col": 6, "factor_items": ""}], "sortByExt": null, "coords_row": 10}, "tempType": "daily", "manCovers": [{"sheet": "封面", "statistics": [{"count": 11, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 3, "valueType": "[unit]", "coords_col": 3}, {"index": 4, "valueType": "current-cv<max.c-speed>", "coords_col": 4}, {"index": 5, "valueType": "factor_speed_unit", "coords_col": 5}, {"index": 6, "valueType": "yellow_thresholds_current-cv", "coords_col": 6}, {"index": 7, "valueType": "current-accum-cv<max.name>", "coords_col": 7}, {"index": 8, "valueType": "current-accum-cv<max.value>", "coords_col": 8}, {"index": 9, "valueType": "[unit]", "coords_col": 9}, {"index": 10, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 10}], "coords_row": 55}]}, {"sheet": "巡视"}], "head_items": [{"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 4, "colum": 1}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 7, "endRow": 44, "startCol": 0, "startRow": 35}, "factorItem": ""}], "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}]
33	苏州人工监测沉降模板	苏州人工监测沉降模板	temp_subside	daily/suzhou-template.xlsx	\N	\N	0	t	{"data": {"count": 24, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "current-cv", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "current-accum-cv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "c-speed", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "init-value", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "last-mv", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "current-mv", "coords_col": 6, "factor_items": ""}], "sortByExt": null, "coords_row": 8}, "tempType": "daily", "manCovers": [{"sheet": "封面", "statistics": [{"count": 11, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 3, "valueType": "[unit]", "coords_col": 3}, {"index": 4, "valueType": "current-cv<max.c-speed>", "coords_col": 4}, {"index": 5, "valueType": "factor_speed_unit", "coords_col": 5}, {"index": 6, "valueType": "yellow_thresholds_current-cv", "coords_col": 6}, {"index": 7, "valueType": "current-accum-cv<max.name>", "coords_col": 7}, {"index": 8, "valueType": "current-accum-cv<max.value>", "coords_col": 8}, {"index": 9, "valueType": "[unit]", "coords_col": 9}, {"index": 10, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 10}], "coords_row": 55}]}, {"sheet": "巡视"}], "head_items": [{"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 4, "colum": 1}}], "sheetIndex": 4, "tail_items": null, "chart_coords": [{"coords": {"endCol": 7, "endRow": 39, "startCol": 0, "startRow": 32}, "factorItem": ""}], "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}]
41	昆明人工监测墙顶水平位移模板	昆明人工监测墙顶水平位移模板	temp_displacement	daily/kunming-template.xlsx	\N	\N	0	t	{"data": {"count": 30, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "init-value", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "last-cv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "current-cv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "current-accum-cv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "c-speed", "coords_col": 5, "factor_items": ""}], "sortByExt": null, "coords_row": 4}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核"}, {"sheet": "巡视检查表"}, {"sheet": "监测数据汇总表", "statistics": [{"count": 6, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-accum-cv<max.name>", "coords_col": 2}, {"index": 2, "valueType": "current-accum-cv<max.value>", "coords_col": 3}, {"index": 3, "valueType": "current-cv<max.name>", "coords_col": 4}, {"index": 4, "valueType": "current-cv<max>", "coords_col": 5}, {"index": 5, "valueType": "alarm_value", "coords_col": 6}], "coords_row": 3}]}, {"sheet": "监测结论"}], "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 1}}, {"name": "[lastMonitorDate]", "coords": {"row": 0, "colum": 4}}, {"name": "[thisMonitorDate]", "coords": {"row": 1, "colum": 4}}, {"name": "[unit]", "coords": {"row": 3, "colum": 1}}, {"name": "[unit]", "coords": {"row": 3, "colum": 2}}, {"name": "[unit]", "coords": {"row": 3, "colum": 3}}, {"name": "[unit]", "coords": {"row": 3, "colum": 4}}, {"name": "[unit]", "coords": {"row": 3, "colum": 5}}, {"name": "[unit]", "coords": {"row": 3, "colum": 6}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 6, "endRow": 45, "startCol": 1, "startRow": 36}, "factorItem": ""}], "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "alarm_value", "type": "factor", "alias": "控制值/预警值"}]
43	长春人工监测通用模板_单参数	长春人工监测通用模板_单参数	temp_common_1	daily/changchun-template.xlsx	\N	\N	0	t	{"data": {"count": 38, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"unit": "m", "index": 1, "valueType": "init-value", "coords_col": 1, "factor_items": ""}, {"unit": "m", "index": 2, "valueType": "last-mv", "coords_col": 2, "factor_items": ""}, {"unit": "m", "index": 3, "valueType": "current-mv", "coords_col": 3, "factor_items": ""}, {"unit": "mm", "index": 4, "valueType": "current-accum-cv", "coords_col": 4, "factor_items": ""}, {"unit": "mm", "index": 5, "valueType": "current-cv", "coords_col": 5, "factor_items": ""}, {"unit": "mm", "index": 6, "valueType": "c-speed", "coords_col": 6, "factor_items": ""}, {"index": 7, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 7, "factor_items": ""}, {"index": 8, "valueType": "yellow_thresholds_current-cv", "coords_col": 8, "factor_items": ""}], "sortByExt": null, "coords_row": 6}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "图纸"}, {"sheet": "分析", "statistics": [{"count": 11, "datas": [{"index": 1, "valueType": "[factorName]", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max.name>", "coords_col": 2}, {"index": 3, "valueType": "current-cv<max>", "coords_col": 3}, {"index": 4, "valueType": "current-cv<max.current-accum-cv>", "coords_col": 4}, {"index": 5, "valueType": "current-accum-cv<max.name>", "coords_col": 5}, {"index": 6, "valueType": "current-accum-cv<max.value>", "coords_col": 6}], "coords_row": 7}]}, {"sheet": "巡查表"}, {"sheet": "巡查照片"}], "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 1, "colum": 2}}, {"name": "[lastMonitorDate]", "coords": {"row": 4, "colum": 2}}, {"name": "[thisMonitorDate]", "coords": {"row": 2, "colum": 2}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}]
45	长春人工监测通用模板_双参数	长春人工监测通用模板_双参数	temp_common_2	daily/changchun-template.xlsx	\N	\N	0	t	{"data": {"count": 16, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": "x,y"}, {"unit": "m", "index": 1, "valueType": "init-value", "coords_col": 1, "factor_items": "x,y"}, {"unit": "m", "index": 2, "valueType": "last-mv", "coords_col": 3, "factor_items": "x,y"}, {"unit": "m", "index": 3, "valueType": "current-mv", "coords_col": 5, "factor_items": "x,y"}, {"unit": "mm", "index": 4, "valueType": "current-accum-cv", "coords_col": 7, "factor_items": "x"}, {"unit": "mm", "index": 5, "valueType": "current-cv", "coords_col": 8, "factor_items": "x"}, {"unit": "mm", "index": 6, "valueType": "current-cv", "coords_col": 9, "factor_items": "x"}, {"index": 7, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 10, "factor_items": ""}, {"index": 8, "valueType": "yellow_thresholds_current-cv", "coords_col": 11, "factor_items": ""}], "sortByExt": null, "coords_row": 6}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "图纸"}, {"sheet": "分析", "statistics": [{"count": 11, "datas": [{"index": 1, "valueType": "[factorName]", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max.name>", "coords_col": 2}, {"index": 3, "valueType": "current-cv<max>", "coords_col": 3}, {"index": 4, "valueType": "current-cv<max.current-accum-cv>", "coords_col": 4}, {"index": 5, "valueType": "current-accum-cv<max.name>", "coords_col": 5}, {"index": 6, "valueType": "current-accum-cv<max.value>", "coords_col": 6}], "coords_row": 7}]}, {"sheet": "巡查表"}, {"sheet": "巡查照片"}], "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 1, "colum": 2}}, {"name": "[lastMonitorDate]", "coords": {"row": 4, "colum": 2}}, {"name": "[thisMonitorDate]", "coords": {"row": 2, "colum": 2}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}]
47	长春人工监测ZQT模板	长春人工监测ZQT模板	temp_ZQT	daily/changchun-template.xlsx	\N	\N	0	t	{"data": {"count": 55, "station": [{"index": 1, "valueType": "next-to-last-accum-cv", "coords_col": 1, "factor_items": "yTotal"}, {"index": 2, "valueType": "last-accum-cv", "coords_col": 2, "factor_items": "yTotal"}, {"index": 3, "valueType": "current-accum-cv", "coords_col": 3, "factor_items": "yTotal"}, {"index": 4, "valueType": "current-cv", "coords_col": 4, "factor_items": "yTotal"}, {"index": 5, "valueType": "current-cv", "coords_col": 5, "factor_items": "yTotal"}], "sortType": "asc", "sortByExt": "depth", "coords_row": 6}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "图纸"}, {"sheet": "分析", "statistics": [{"count": 11, "datas": [{"index": 1, "valueType": "[factorName]", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max.name>", "coords_col": 2}, {"index": 3, "valueType": "current-cv<max>", "coords_col": 3}, {"index": 4, "valueType": "current-cv<max.current-accum-cv>", "coords_col": 4}, {"index": 5, "valueType": "current-accum-cv<max.name>", "coords_col": 5}, {"index": 6, "valueType": "current-accum-cv<max.value>", "coords_col": 6}], "coords_row": 7}]}, {"sheet": "巡查表"}, {"sheet": "巡查照片"}], "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 1, "colum": 2}}, {"name": "[lastMonitorDate]", "coords": {"row": 4, "colum": 2}}, {"name": "[thisMonitorDate]", "coords": {"row": 2, "colum": 2}}], "sheetIndex": 4, "tail_items": null, "chart_coords": [{"coords": {"endCol": 11, "endRow": 63, "startCol": 7, "startRow": 4}, "factorItem": "yTotal"}], "extGroupItems": [{"name": "depth", "colum": 0}]}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}]
28	杭州人工监测通用模板_上海地铁	杭州人工监测通用模板_上海地铁	temp_common	daily/hangzhou-sh-template.xlsx	\N	\N	0	t	{"data": {"count": 26, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "last-accum-cv", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "current-accum-cv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "current-cv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "current-cv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "yellow_thresholds_current-cv", "coords_col": 6, "factor_items": ""}, {"index": 7, "valueType": "station.label.region", "coords_col": 7, "factor_items": ""}], "sortByExt": null, "coords_row": 8}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核单"}, {"sheet": "分析报告", "statistics": [{"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 3, "valueType": "current-accum-cv<max.name>", "coords_col": 3}, {"index": 4, "valueType": "current-accum-cv<max.value>", "coords_col": 4}, {"index": 5, "valueType": "yellow_thresholds_current-cv", "coords_col": 5}, {"index": 6, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 6}], "coords_row": 24}, {"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "factor_station_actually_num", "coords_col": 1}, {"index": 2, "valueType": "factor_station_num", "coords_col": 2}, {"index": 3, "default": 0, "valueType": "", "coords_col": 3}, {"index": 4, "valueType": "factor_station_invalid_num", "coords_col": 4}, {"index": 5, "valueType": "factor_station_valid_rate", "coords_col": 5}], "coords_row": 36}]}, {"sheet": "巡查表"}], "head_items": [{"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 4, "colum": 2}}, {"name": "[thisMonitorDate]", "coords": {"row": 5, "colum": 2}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 1}}, {"name": "[unit]", "coords": {"row": 6, "colum": 1}}, {"name": "[unit]", "coords": {"row": 6, "colum": 4}}, {"name": "[unit]", "coords": {"row": 7, "colum": 5}}, {"name": "[unit]", "coords": {"row": 7, "colum": 6}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}, {"name": "instrument_name", "type": "factor", "alias": "仪器名称"}, {"name": "instrument_number", "type": "factor", "alias": "仪器编号"}]
30	杭州人工监测水位模板_上海地铁	杭州人工监测水位模板_上海地铁	temp_water-level	daily/hangzhou-sh-template.xlsx	\N	\N	0	t	{"data": {"count": 25, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"unit": "mm", "index": 1, "valueType": "last-accum-cv", "coords_col": 1, "factor_items": ""}, {"unit": "mm", "index": 2, "valueType": "current-accum-cv", "coords_col": 2, "factor_items": ""}, {"unit": "mm", "index": 3, "valueType": "accum-cv", "coords_col": 3, "factor_items": ""}, {"unit": "mm", "index": 4, "valueType": "accum-cv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "station.label.waterDeep", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 6, "factor_items": ""}, {"index": 7, "valueType": "yellow_thresholds_current-cv", "coords_col": 7, "factor_items": ""}, {"index": 8, "valueType": "station.label.region", "coords_col": 8, "factor_items": ""}], "sortByExt": null, "coords_row": 8}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核单"}, {"sheet": "分析报告", "statistics": [{"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 3, "valueType": "current-accum-cv<max.name>", "coords_col": 3}, {"index": 4, "valueType": "current-accum-cv<max.value>", "coords_col": 4}, {"index": 5, "valueType": "yellow_thresholds_current-cv", "coords_col": 5}, {"index": 6, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 6}], "coords_row": 24}, {"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "factor_station_actually_num", "coords_col": 1}, {"index": 2, "valueType": "factor_station_num", "coords_col": 2}, {"index": 3, "default": 0, "valueType": "", "coords_col": 3}, {"index": 4, "valueType": "factor_station_invalid_num", "coords_col": 4}, {"index": 5, "valueType": "factor_station_valid_rate", "coords_col": 5}], "coords_row": 36}]}, {"sheet": "巡查表"}], "head_items": [{"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 4, "colum": 2}}, {"name": "[thisMonitorDate]", "coords": {"row": 5, "colum": 2}}, {"name": "[unit]", "coords": {"row": 5, "colum": 7}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}, {"name": "instrument_name", "type": "factor", "alias": "仪器名称"}, {"name": "instrument_number", "type": "factor", "alias": "仪器编号"}]
19	昆明人工监测通用模板	昆明人工监测通用模板	temp_common	daily/kunming-template.xlsx	\N	\N	0	t	{"data": {"count": 30, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"unit": "m", "index": 1, "valueType": "init-value", "coords_col": 1, "factor_items": ""}, {"unit": "m", "index": 2, "valueType": "last-mv", "coords_col": 2, "factor_items": ""}, {"unit": "m", "index": 3, "valueType": "current-mv", "coords_col": 3, "factor_items": ""}, {"unit": "mm", "index": 4, "valueType": "current-cv", "coords_col": 4, "factor_items": ""}, {"unit": "mm", "index": 5, "valueType": "current-accum-cv", "coords_col": 5, "factor_items": ""}, {"unit": "mm", "index": 6, "valueType": "c-speed", "coords_col": 6, "factor_items": ""}], "sortByExt": null, "coords_row": 4}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核"}, {"sheet": "巡视检查表"}, {"sheet": "监测数据汇总表", "statistics": [{"count": 6, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-accum-cv<max.name>", "coords_col": 2}, {"index": 2, "valueType": "current-accum-cv<max.value>", "coords_col": 3}, {"index": 3, "valueType": "current-cv<max.name>", "coords_col": 4}, {"index": 4, "valueType": "current-cv<max>", "coords_col": 5}, {"index": 5, "valueType": "alarm_value", "coords_col": 6}], "coords_row": 3}]}, {"sheet": "监测结论"}], "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 1}}, {"name": "[lastMonitorDate]", "coords": {"row": 0, "colum": 4}}, {"name": "[thisMonitorDate]", "coords": {"row": 1, "colum": 4}}, {"name": "[unit]", "coords": {"row": 3, "colum": 1}}, {"name": "[unit]", "coords": {"row": 3, "colum": 2}}, {"name": "[unit]", "coords": {"row": 3, "colum": 3}}, {"name": "[unit]", "coords": {"row": 3, "colum": 4}}, {"name": "[unit]", "coords": {"row": 3, "colum": 5}}, {"name": "[unit]", "coords": {"row": 3, "colum": 6}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 7, "endRow": 45, "startCol": 1, "startRow": 36}, "factorItem": ""}], "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "alarm_value", "type": "factor", "alias": "控制值/预警值"}]
35	杭州人工监测水位模板_浙江五洲	杭州人工监测水位模板_浙江五洲	temp_water-level	daily/hangzhou-zj-template.xlsx	\N	\N	0	t	{"data": {"count": 30, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"unit": "mm", "index": 1, "valueType": "last-accum-cv", "coords_col": 1, "factor_items": ""}, {"unit": "mm", "index": 2, "valueType": "current-accum-cv", "coords_col": 2, "factor_items": ""}, {"unit": "mm", "index": 3, "valueType": "accum-cv", "coords_col": 3, "factor_items": ""}, {"unit": "mm", "index": 4, "valueType": "accum-cv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "station.label.waterDeep", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 6, "factor_items": ""}, {"index": 7, "valueType": "yellow_thresholds_current-cv", "coords_col": 7, "factor_items": ""}, {"index": 8, "valueType": "station.label.region", "coords_col": 8, "factor_items": ""}], "sortByExt": null, "coords_row": 8}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核单"}, {"sheet": "监测分析日报表", "statistics": [{"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 5, "valueType": "current-accum-cv<max.name>", "coords_col": 5}, {"index": 6, "valueType": "current-accum-cv<max.value>", "coords_col": 6}, {"index": 3, "valueType": "yellow_thresholds_current-cv", "coords_col": 3}, {"index": 7, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 7}], "coords_row": 8}, {"count": 11, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 2, "valueType": "factor_station_actually_num", "coords_col": 2}, {"index": 1, "valueType": "factor_station_num", "coords_col": 1}, {"index": 3, "valueType": "factor_station_invalid_num", "coords_col": 3}, {"index": 5, "valueType": "factor_station_valid_rate", "coords_col": 5}], "coords_row": 21}]}, {"sheet": "巡视检查报表"}], "head_items": [{"name": "[structureName]", "coords": {"row": 0, "colum": 0}}, {"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 4, "colum": 1}}, {"name": "[thisMonitorDate]", "coords": {"row": 5, "colum": 1}}, {"name": "[unit]", "coords": {"row": 6, "colum": 1}}, {"name": "[unit]", "coords": {"row": 6, "colum": 4}}, {"name": "[unit]", "coords": {"row": 7, "colum": 5}}, {"name": "[unit]", "coords": {"row": 7, "colum": 6}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 9, "endRow": 52, "startCol": 1, "startRow": 38}, "factorItem": ""}], "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}, {"name": "instrument_name", "type": "factor", "alias": "仪器名称"}, {"name": "instrument_number", "type": "factor", "alias": "仪器编号"}]
40	杭州人工监测支撑轴力模板_浙江五洲	杭州人工监测支撑轴力模板_浙江五洲	temp_support-force	daily/hangzhou-zj-template.xlsx	\N	\N	0	t	{"data": {"count": 33, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "last-mv", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "current-mv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "current-cv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "current-cv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "yellow_thresholds_current-cv", "coords_col": 6, "factor_items": ""}, {"index": 7, "valueType": "station.label.region", "coords_col": 7, "factor_items": ""}], "sortByExt": null, "coords_row": 8}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核单"}, {"sheet": "监测分析日报表", "statistics": [{"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 5, "valueType": "current-accum-cv<max.name>", "coords_col": 5}, {"index": 6, "valueType": "current-accum-cv<max.value>", "coords_col": 6}, {"index": 3, "valueType": "yellow_thresholds_current-cv", "coords_col": 3}, {"index": 7, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 7}], "coords_row": 8}, {"count": 11, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 2, "valueType": "factor_station_actually_num", "coords_col": 2}, {"index": 1, "valueType": "factor_station_num", "coords_col": 1}, {"index": 3, "valueType": "factor_station_invalid_num", "coords_col": 3}, {"index": 5, "valueType": "factor_station_valid_rate", "coords_col": 5}], "coords_row": 21}]}, {"sheet": "巡视检查报表"}], "head_items": [{"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 4, "colum": 1}}, {"name": "[thisMonitorDate]", "coords": {"row": 5, "colum": 1}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 1}}, {"name": "[unit]", "coords": {"row": 6, "colum": 1}}, {"name": "[unit]", "coords": {"row": 6, "colum": 4}}, {"name": "[unit]", "coords": {"row": 7, "colum": 5}}, {"name": "[unit]", "coords": {"row": 7, "colum": 6}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 8, "endRow": 49, "startCol": 1, "startRow": 41}, "factorItem": ""}], "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}, {"name": "instrument_name", "type": "factor", "alias": "仪器名称"}, {"name": "instrument_number", "type": "factor", "alias": "仪器编号"}]
21	昆明人工监测ZQT模板	昆明人工监测ZQT模板	temp_ZQT	daily/kunming-template.xlsx	\N	\N	0	t	{"data": {"count": 50, "station": [{"index": 1, "valueType": "current-cv", "coords_col": 1, "factor_items": "yTotal"}, {"index": 2, "valueType": "last-accum-cv", "coords_col": 2, "factor_items": "yTotal"}, {"index": 3, "valueType": "current-accum-cv", "coords_col": 3, "factor_items": "yTotal"}, {"index": 4, "valueType": "c-speed", "coords_col": 4, "factor_items": "yTotal"}], "sortType": "asc", "sortByExt": "depth", "coords_row": 2}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核"}, {"sheet": "巡视检查表"}, {"sheet": "监测数据汇总表", "statistics": [{"count": 6, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-accum-cv<max.name>", "coords_col": 2}, {"index": 2, "valueType": "current-accum-cv<max.value>", "coords_col": 3}, {"index": 3, "valueType": "current-cv<max.name>", "coords_col": 4}, {"index": 4, "valueType": "current-cv<max>", "coords_col": 5}, {"index": 5, "valueType": "alarm_value", "coords_col": 6}], "coords_row": 3}]}, {"sheet": "监测结论"}], "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 0}}], "sheetIndex": 4, "tail_items": null, "chart_coords": [{"coords": {"endCol": 8, "endRow": 51, "startCol": 5, "startRow": 1}, "factorItem": "yTotal"}], "extGroupItems": [{"name": "depth", "colum": 0}]}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "alarm_value", "type": "factor", "alias": "控制值/预警值"}]
23	苏州人工监测水平位移模板	苏州人工监测水平位移模板	temp_displacement	daily/suzhou-template.xlsx	\N	\N	0	t	{"data": {"count": 28, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"unit": "mm", "index": 1, "valueType": "current-cv", "coords_col": 1, "factor_items": ""}, {"unit": "mm", "index": 2, "valueType": "current-accum-cv", "coords_col": 2, "factor_items": ""}, {"unit": "mm", "index": 3, "valueType": "c-speed", "coords_col": 3, "factor_items": ""}, {"unit": "m", "index": 4, "valueType": "init-value", "coords_col": 4, "factor_items": ""}, {"unit": "m", "index": 5, "valueType": "last-mv", "coords_col": 6, "factor_items": ""}, {"unit": "m", "index": 6, "valueType": "current-mv", "coords_col": 8, "factor_items": ""}], "sortByExt": null, "coords_row": 10}, "tempType": "daily", "manCovers": [{"sheet": "封面", "statistics": [{"count": 11, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 3, "valueType": "[unit]", "coords_col": 3}, {"index": 4, "valueType": "current-cv<max.c-speed>", "coords_col": 4}, {"index": 5, "valueType": "factor_speed_unit", "coords_col": 5}, {"index": 6, "valueType": "yellow_thresholds_current-cv", "coords_col": 6}, {"index": 7, "valueType": "current-accum-cv<max.name>", "coords_col": 7}, {"index": 8, "valueType": "current-accum-cv<max.value>", "coords_col": 8}, {"index": 9, "valueType": "[unit]", "coords_col": 9}], "coords_row": 55}]}, {"sheet": "巡视"}], "head_items": [{"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 5, "colum": 4}}, {"name": "[thisMonitorDate]", "coords": {"row": 4, "colum": 0}}, {"name": "[weather]", "coords": {"row": 3, "colum": 4}}, {"name": "[stage]", "coords": {"row": 2, "colum": 7}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 10, "endRow": 47, "startCol": 0, "startRow": 38}, "factorItem": ""}], "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}]
25	苏州人工监测测斜模板	苏州人工监测测斜模板	temp_CX	daily/suzhou-template.xlsx	\N	\N	0	t	{"data": {"count": 70, "station": [{"index": 1, "valueType": "last-accum-cv", "coords_col": 1, "factor_items": "yTotal"}, {"index": 2, "valueType": "current-accum-cv", "coords_col": 2, "factor_items": "yTotal"}, {"index": 3, "valueType": "current-cv", "coords_col": 3, "factor_items": "yTotal"}, {"index": 4, "valueType": "c-speed", "coords_col": 4, "factor_items": "yTotal"}], "sortType": "asc", "sortByExt": "depth", "coords_row": 10}, "tempType": "daily", "manCovers": [{"sheet": "封面", "statistics": [{"count": 11, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 3, "valueType": "[unit]", "coords_col": 3}, {"index": 4, "valueType": "current-cv<max.c-speed>", "coords_col": 4}, {"index": 5, "valueType": "factor_speed_unit", "coords_col": 5}, {"index": 6, "valueType": "yellow_thresholds_current-cv", "coords_col": 6}, {"index": 7, "valueType": "current-accum-cv<max.name>", "coords_col": 7}, {"index": 8, "valueType": "current-accum-cv<max.value>", "coords_col": 8}, {"index": 9, "valueType": "[unit]", "coords_col": 9}, {"index": 10, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 10}], "coords_row": 55}]}, {"sheet": "巡视"}], "head_items": [{"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 4, "colum": 1}}, {"name": "[stage]", "coords": {"row": 2, "colum": 5}}], "sheetIndex": 4, "tail_items": null, "chart_coords": [{"coords": {"endCol": 7, "endRow": 79, "startCol": 5, "startRow": 8}, "factorItem": "yTotal"}], "extGroupItems": [{"name": "depth", "colum": 0}]}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}]
26	杭州人工监测通用模板_浙江五洲	杭州人工监测通用模板_浙江五洲	temp_common	daily/hangzhou-zj-template.xlsx	\N	\N	0	t	{"data": {"count": 26, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "last-accum-cv", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "current-accum-cv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "current-cv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "current-cv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "yellow_thresholds_current-cv", "coords_col": 6, "factor_items": ""}, {"index": 7, "valueType": "station.label.region", "coords_col": 7, "factor_items": ""}], "sortByExt": null, "coords_row": 8}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核单"}, {"sheet": "监测分析日报表", "statistics": [{"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 5, "valueType": "current-accum-cv<max.name>", "coords_col": 5}, {"index": 6, "valueType": "current-accum-cv<max.value>", "coords_col": 6}, {"index": 3, "valueType": "yellow_thresholds_current-cv", "coords_col": 3}, {"index": 7, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 7}], "coords_row": 8}, {"count": 11, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 2, "valueType": "factor_station_actually_num", "coords_col": 2}, {"index": 1, "valueType": "factor_station_num", "coords_col": 1}, {"index": 3, "valueType": "factor_station_invalid_num", "coords_col": 3}, {"index": 5, "valueType": "factor_station_valid_rate", "coords_col": 5}], "coords_row": 21}]}, {"sheet": "巡视检查报表"}], "head_items": [{"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 4, "colum": 1}}, {"name": "[thisMonitorDate]", "coords": {"row": 5, "colum": 1}}, {"name": "[itemName]", "coords": {"row": 6, "colum": 1}}, {"name": "[unit]", "coords": {"row": 6, "colum": 1}}, {"name": "[unit]", "coords": {"row": 6, "colum": 4}}, {"name": "[unit]", "coords": {"row": 7, "colum": 5}}, {"name": "[unit]", "coords": {"row": 7, "colum": 6}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 8, "endRow": 54, "startCol": 1, "startRow": 44}, "factorItem": ""}], "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}, {"name": "instrument_name", "type": "factor", "alias": "仪器名称"}, {"name": "instrument_number", "type": "factor", "alias": "仪器编号"}]
27	杭州人工监测ZQT模板_浙江五洲	杭州人工监测ZQT模板_浙江五洲	temp_ZQT	daily/hangzhou-zj-template.xlsx	\N	\N	0	t	{"data": {"count": 50, "station": [{"index": 1, "valueType": "last-accum-cv", "coords_col": 1, "factor_items": "yTotal"}, {"index": 2, "valueType": "current-accum-cv", "coords_col": 2, "factor_items": "yTotal"}, {"index": 3, "valueType": "current-cv", "coords_col": 3, "factor_items": "yTotal"}, {"index": 4, "valueType": "current-cv", "coords_col": 4, "factor_items": "yTotal"}], "sortType": "asc", "sortByExt": "depth", "coords_row": 9}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核单"}, {"sheet": "监测分析日报表", "statistics": [{"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 5, "valueType": "current-accum-cv<max.name>", "coords_col": 5}, {"index": 6, "valueType": "current-accum-cv<max.value>", "coords_col": 6}, {"index": 3, "valueType": "yellow_thresholds_current-cv", "coords_col": 3}, {"index": 7, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 7}], "coords_row": 8}, {"count": 11, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 2, "valueType": "factor_station_actually_num", "coords_col": 2}, {"index": 1, "valueType": "factor_station_num", "coords_col": 1}, {"index": 3, "valueType": "factor_station_invalid_num", "coords_col": 3}, {"index": 5, "valueType": "factor_station_valid_rate", "coords_col": 5}], "coords_row": 21}]}, {"sheet": "巡视检查报表"}, {"sheet": "测斜统计表", "statistics": [{"type": "group", "count": 45, "datas": [{"ps": {"combine": true}, "index": 0, "default": "墙体深层水平位移", "valueType": "", "coords_col": 0}, {"index": 1, "valueType": "c-speed<max.name>", "coords_col": 1}, {"index": 2, "valueType": "c-speed<max.value>", "coords_col": 2}, {"ps": {"combine": true}, "index": 3, "valueType": "yellow_thresholds_current-cv", "coords_col": 3}, {"index": 5, "valueType": "current-accum-cv<max.name>", "coords_col": 5}, {"index": 6, "valueType": "current-accum-cv<max.value>", "coords_col": 6}, {"ps": {"combine": true}, "index": 7, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 7}], "coords_row": 3}]}], "head_items": [{"name": "[factorName]", "coords": {"row": 4, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 0, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 5, "colum": 2}}, {"name": "[thisMonitorDate]", "coords": {"row": 6, "colum": 2}}], "sheetIndex": 4, "tail_items": null, "chart_coords": [{"coords": {"endCol": 8, "endRow": 58, "startCol": 5, "startRow": 7}, "factorItem": "yTotal"}], "extGroupItems": [{"name": "depth", "colum": 0}]}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}, {"name": "instrument_name", "type": "factor", "alias": "仪器名称"}, {"name": "instrument_number", "type": "factor", "alias": "仪器编号"}]
29	杭州人工监测支撑轴力模板_上海地铁	杭州人工监测支撑轴力模板_上海地铁	temp_support-force	daily/hangzhou-sh-template.xlsx	\N	\N	0	t	{"data": {"count": 24, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "last-mv", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "current-mv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "current-cv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "current-cv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "alarm_param1", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "alarm_param2", "coords_col": 6, "factor_items": ""}, {"index": 7, "valueType": "station.label.region", "coords_col": 7, "factor_items": ""}], "sortByExt": null, "coords_row": 8}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核单"}, {"sheet": "分析报告", "statistics": [{"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 3, "valueType": "current-accum-cv<max.name>", "coords_col": 3}, {"index": 4, "valueType": "current-accum-cv<max.value>", "coords_col": 4}, {"index": 5, "valueType": "yellow_thresholds_current-cv", "coords_col": 5}, {"index": 6, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 6}], "coords_row": 24}, {"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "factor_station_actually_num", "coords_col": 1}, {"index": 2, "valueType": "factor_station_num", "coords_col": 2}, {"index": 3, "default": 0, "valueType": "", "coords_col": 3}, {"index": 4, "valueType": "factor_station_invalid_num", "coords_col": 4}, {"index": 5, "valueType": "factor_station_valid_rate", "coords_col": 5}], "coords_row": 36}]}, {"sheet": "巡查表"}], "head_items": [{"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 4, "colum": 2}}, {"name": "[thisMonitorDate]", "coords": {"row": 5, "colum": 2}}, {"name": "[unit]", "coords": {"row": 5, "colum": 7}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}, {"name": "instrument_name", "type": "factor", "alias": "仪器名称"}, {"name": "instrument_number", "type": "factor", "alias": "仪器编号"}]
32	杭州人工监测ZQT_TST模板_上海地铁	杭州人工监测ZQT_TST模板_上海地铁	temp_ZQT_TST	daily/hangzhou-sh-template.xlsx	\N	\N	0	t	{"data": {"count": 50, "station": [{"index": 1, "valueType": "last-accum-cv", "coords_col": 1, "factor_items": "yTotal"}, {"index": 2, "valueType": "current-accum-cv", "coords_col": 2, "factor_items": "yTotal"}, {"index": 3, "valueType": "current-mv", "coords_col": 3, "factor_items": "yTotal"}, {"index": 4, "valueType": "current-mv", "coords_col": 4, "factor_items": "yTotal"}], "sortType": "asc", "sortByExt": "depth", "coords_row": 9}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核单"}, {"sheet": "分析报告", "statistics": [{"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 3, "valueType": "current-accum-cv<max.name>", "coords_col": 3}, {"index": 4, "valueType": "current-accum-cv<max.value>", "coords_col": 4}, {"index": 5, "valueType": "yellow_thresholds_current-cv", "coords_col": 5}, {"index": 6, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 6}], "coords_row": 24}, {"count": 10, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "factor_station_actually_num", "coords_col": 1}, {"index": 2, "valueType": "factor_station_num", "coords_col": 2}, {"index": 3, "default": 0, "valueType": "", "coords_col": 3}, {"index": 4, "valueType": "factor_station_invalid_num", "coords_col": 4}, {"index": 5, "valueType": "factor_station_valid_rate", "coords_col": 5}], "coords_row": 36}]}, {"sheet": "巡查表"}, {"sheet": "测斜统计", "statistics": [{"type": "group", "count": 19, "datas": [{"index": 0, "valueType": "group_name", "coords_col": 0}, {"index": 1, "valueType": "c-speed<max.value>", "coords_col": 1}, {"index": 2, "valueType": "c-speed<max.depth>", "coords_col": 2}, {"index": 3, "valueType": "current-accum-cv<max.value>", "coords_col": 3}, {"index": 4, "valueType": "current-accum-cv<max.depth>", "coords_col": 4}, {"index": 5, "valueType": "<station.label.region>", "coords_col": 5}], "coords_row": 8}]}], "head_items": [{"name": "[factorName]", "coords": {"row": 4, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[lastMonitorDate]", "coords": {"row": 5, "colum": 2}}, {"name": "[thisMonitorDate]", "coords": {"row": 6, "colum": 2}}], "sheetIndex": 4, "tail_items": null, "chart_coords": [{"coords": {"endCol": 8, "endRow": 58, "startCol": 5, "startRow": 9}, "factorItem": "yTotal"}], "extGroupItems": [{"name": "depth", "colum": 0}]}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}, {"name": "instrument_name", "type": "factor", "alias": "仪器名称"}, {"name": "instrument_number", "type": "factor", "alias": "仪器编号"}]
34	苏州人工监测支撑轴力模板	苏州人工监测支撑轴力模板	temp_support-force	daily/suzhou-template.xlsx	\N	\N	0	t	{"data": {"count": 27, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "current-mv", "coords_col": 2, "factor_items": ""}, {"index": 2, "valueType": "current-cv", "coords_col": 3, "factor_items": ""}, {"index": 3, "valueType": "current-accum-cv", "coords_col": 4, "factor_items": ""}], "sortByExt": null, "coords_row": 10}, "tempType": "daily", "manCovers": [{"sheet": "封面", "statistics": [{"count": 11, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-cv<max.name>", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max>", "coords_col": 2}, {"index": 3, "valueType": "[unit]", "coords_col": 3}, {"index": 4, "valueType": "current-cv<max.c-speed>", "coords_col": 4}, {"index": 5, "valueType": "factor_speed_unit", "coords_col": 5}, {"index": 6, "valueType": "yellow_thresholds_current-cv", "coords_col": 6}, {"index": 7, "valueType": "current-accum-cv<max.name>", "coords_col": 7}, {"index": 8, "valueType": "current-accum-cv<max.value>", "coords_col": 8}, {"index": 9, "valueType": "[unit]", "coords_col": 9}, {"index": 10, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 10}], "coords_row": 55}]}, {"sheet": "巡视"}], "head_items": [{"name": "[factorName]", "coords": {"row": 3, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 2, "colum": 0}}, {"name": "[thisMonitorDate]", "coords": {"row": 4, "colum": 1}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 11, "endRow": 47, "startCol": 0, "startRow": 37}, "factorItem": ""}], "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}]
42	昆明人工监测支撑轴力模板	昆明人工监测支撑轴力模板	temp_support-force	daily/kunming-template.xlsx	\N	\N	0	t	{"data": {"count": 37, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "init-value", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "last-accum-cv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "current-accum-cv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "current_cv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "current-accum-cv", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "c-speed", "coords_col": 6, "factor_items": ""}], "sortByExt": null, "coords_row": 4}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "审核"}, {"sheet": "巡视检查表"}, {"sheet": "监测数据汇总表", "statistics": [{"count": 6, "datas": [{"index": 0, "valueType": "[factorName]", "coords_col": 0}, {"index": 1, "valueType": "current-accum-cv<max.name>", "coords_col": 2}, {"index": 2, "valueType": "current-accum-cv<max.value>", "coords_col": 3}, {"index": 3, "valueType": "current-cv<max.name>", "coords_col": 4}, {"index": 4, "valueType": "current-cv<max>", "coords_col": 5}, {"index": 5, "valueType": "alarm_value", "coords_col": 6}], "coords_row": 3}]}, {"sheet": "监测结论"}], "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 1}}, {"name": "[lastMonitorDate]", "coords": {"row": 0, "colum": 4}}, {"name": "[thisMonitorDate]", "coords": {"row": 1, "colum": 4}}, {"name": "[unit]", "coords": {"row": 3, "colum": 1}}, {"name": "[unit]", "coords": {"row": 3, "colum": 2}}, {"name": "[unit]", "coords": {"row": 3, "colum": 3}}, {"name": "[unit]", "coords": {"row": 3, "colum": 4}}, {"name": "[unit]", "coords": {"row": 3, "colum": 5}}, {"name": "[unit]", "coords": {"row": 3, "colum": 6}}], "sheetIndex": 0, "tail_items": null, "chart_coords": [{"coords": {"endCol": 7, "endRow": 48, "startCol": 1, "startRow": 43}, "factorItem": ""}], "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "alarm_value", "type": "factor", "alias": "控制值/预警值"}]
46	长春人工监测支撑轴力模板	长春人工监测支撑轴力模板	temp_support-force	daily/changchun-template.xlsx	\N	\N	0	t	{"data": {"count": 16, "station": [{"index": 0, "valueType": "location", "coords_col": 0, "factor_items": ""}, {"index": 1, "valueType": "init-value", "coords_col": 1, "factor_items": ""}, {"index": 2, "valueType": "last-mv", "coords_col": 2, "factor_items": ""}, {"index": 3, "valueType": "current-mv", "coords_col": 3, "factor_items": ""}, {"index": 4, "valueType": "current-accum-cv", "coords_col": 4, "factor_items": ""}, {"index": 5, "valueType": "current-cv", "coords_col": 5, "factor_items": ""}, {"index": 6, "valueType": "c-speed", "coords_col": 6, "factor_items": ""}, {"index": 7, "valueType": "yellow_thresholds_current-accum-cv", "coords_col": 7, "factor_items": ""}, {"index": 8, "valueType": "yellow_thresholds_current-cv", "coords_col": 8, "factor_items": ""}], "sortByExt": null, "coords_row": 6}, "tempType": "daily", "manCovers": [{"sheet": "封面"}, {"sheet": "图纸"}, {"sheet": "分析", "statistics": [{"count": 11, "datas": [{"index": 1, "valueType": "[factorName]", "coords_col": 1}, {"index": 2, "valueType": "current-cv<max.name>", "coords_col": 2}, {"index": 3, "valueType": "current-cv<max>", "coords_col": 3}, {"index": 4, "valueType": "current-cv<max.current-accum-cv>", "coords_col": 4}, {"index": 5, "valueType": "current-accum-cv<max.name>", "coords_col": 5}, {"index": 6, "valueType": "current-accum-cv<max.value>", "coords_col": 6}], "coords_row": 7}]}, {"sheet": "巡查表"}, {"sheet": "巡查照片"}], "head_items": [{"name": "[factorName]", "coords": {"row": 0, "colum": 0}}, {"name": "[structureName]", "coords": {"row": 1, "colum": 2}}, {"name": "[lastMonitorDate]", "coords": {"row": 4, "colum": 2}}, {"name": "[thisMonitorDate]", "coords": {"row": 2, "colum": 2}}], "sheetIndex": 0, "tail_items": null, "chart_coords": null, "extGroupItems": null}	{}	{}	[{"name": "project_section", "alias": "工程名称"}, {"name": "construct_unit", "alias": "施工单位"}, {"name": "construct_control_unit", "alias": "监理单位"}, {"name": "construct_monitor_unit", "alias": "施工方监测单位"}, {"name": "thirdpart_monitor_unit", "alias": "第三方监测单位"}, {"name": "report_code", "alias": "编号"}, {"name": "last_stage", "alias": "上次期数"}, {"name": "monitoring_instructions", "type": "factor", "alias": "监测说明"}, {"name": "yellow_thresholds_current-cv", "type": "factor", "alias": "报警值日变量"}, {"name": "yellow_thresholds_current-accum-cv", "type": "factor", "alias": "报警值累计量"}]
\.


--
-- Data for Name: t_resource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_resource (code, name, description, type, parent_resource) FROM stdin;
002	结构物管理	\N	\N	\N
002001	新增结构物	\N	\N	002
002002	修改结构物信息	\N	\N	002
002003	删除结构物	\N	\N	002
003	设备组网	\N	\N	\N
003001	编辑设备组网	\N	\N	003
004	2D布设	\N	\N	\N
004001	添加布设图	\N	\N	004
004002	修改布设图	\N	\N	004
004003	删除布设图	\N	\N	004
004004	测点布设	\N	\N	004
005	监测模型管理	\N	\N	\N
005001	新增结构物类型	\N	\N	005
005002	修改结构物类型	\N	\N	005
005003	删除结构物类型	\N	\N	005
005004	新增监测因素	\N	\N	005
005005	修改监测因素	\N	\N	005
005006	删除监测因素	\N	\N	005
005007	新增监测模板	\N	\N	005
005008	修改监测模板	\N	\N	005
005009	删除监测模板	\N	\N	005
006	测点管理	\N	\N	\N
006001	新增测点	\N	\N	006
006002	修改测点信息	\N	\N	006
006003	删除测点	\N	\N	006
007	3D布设	\N	\N	\N
007001	更新模型	\N	\N	007
007002	测点布设	\N	\N	007
007003	截面配置	\N	\N	007
008	组合计算配置	\N	\N	\N
008001	新增分组	\N	\N	008
008002	修改分组	\N	\N	008
008003	删除分组	\N	\N	008
009	报表生成配置	\N	\N	\N
009001	新增生成规则	\N	\N	009
009002	修改生成规则	\N	\N	009
009003	删除生成规则	\N	\N	009
009004	立即生成报表	\N	\N	009
010	项目管理	\N	\N	\N
010001	新建项目	\N	\N	010
010002	修改项目	\N	\N	010
010003	修改项目管理员	\N	\N	010
010004	删除项目	\N	\N	010
011	文档管理	\N	\N	\N
011001	上传文件	\N	\N	011
011002	删除文件	\N	\N	011
011003	下载	\N	\N	011
012	事记	\N	\N	\N
012001	新增事记	\N	\N	012
012002	修改事记	\N	\N	012
012003	删除事记	\N	\N	012
013	企业成员管理	\N	\N	\N
013001	新增部门	\N	\N	013
013002	修改部门	\N	\N	013
013003	删除部门	\N	\N	013
013004	新增职务	\N	\N	013
013005	修改职务	\N	\N	013
013006	删除职务	\N	\N	013
013007	新增成员	\N	\N	013
013008	修改成员	\N	\N	013
013009	删除成员	\N	\N	013
013010	启用成员	\N	\N	013
013011	禁用成员	\N	\N	013
013012	修改职位权限	\N	\N	013
013013	修改数据范围	\N	\N	013
014	企业管理	\N	\N	\N
014001	修改企业信息	\N	\N	014
014002	修改企业logo	\N	\N	014
014003	删除企业	\N	\N	014
014004	转让企业	\N	\N	014
015	告警管理	\N	\N	\N
015001	人工确认告警恢复	\N	\N	015
016	阈值配置	\N	\N	\N
016001	新增阈值配置	\N	\N	016
016002	修改阈值配置	\N	\N	016
016003	删除阈值配置	\N	\N	016
017	视频管理	\N	\N	\N
017001	新增NVR	\N	\N	017
017002	修改NVR	\N	\N	017
017003	删除NVR	\N	\N	017
017004	新增摄像头	\N	\N	017
017005	修改摄像头	\N	\N	017
017006	删除摄像头	\N	\N	017
001	告警推送管理	\N	\N	\N
001001	新增告警推送策略	\N	\N	001
001002	修改告警推送策略	\N	\N	001
001003	删除告警推送策略	\N	\N	001
018	智慧工地	\N	\N	\N
018001	新增机构	\N	\N	018
018002	修改机构	\N	\N	018
018003	删除机构	\N	\N	018
018004	新增工地	\N	\N	018
018005	修改工地	\N	\N	018
018006	删除工地	\N	\N	018
019	事件评分指标权重	\N	\N	\N
019002	设置事件评分指标权重	\N	\N	019
019003	删除事件评分指标权重	\N	\N	019
019004	新增结构物年平均降雨量	\N	\N	019
021	变化速率阈值配置	\N	\N	\N
021001	添加变化速率阈值配置	\N	\N	021
021002	修改变化速率阈值配置	\N	\N	021
021003	删除变化速率阈值配置	\N	\N	021
020	聚集配置	\N	\N	\N
020002	添加聚集配置	\N	\N	020
020003	修改聚集配置	\N	\N	020
020004	删除聚集配置	\N	\N	020
015002	查看设备类告警	\N	\N	015
015003	查看数据类告警	\N	\N	015
022	通信状态	\N	\N	\N
022001	查看通信状态	\N	\N	022
007004	添加模型	\N	\N	007
023	异常推送配置	\N	\N	\N
023001	异常推送配置	\N	\N	023
024	数据计算	\N	\N	\N
024001	数据计算	\N	\N	024
025	结构物群	\N	\N	\N
025001	新建结构物群	\N	\N	025
025002	编辑结构物群	\N	\N	025
025003	关联结构物	\N	\N	025
025004	删除结构物群	\N	\N	025
010005	发起审核	\N	\N	010
010006	项目审核	\N	\N	010
010007	项目发布	\N	\N	010
010008	查看已发布	\N	\N	010
026	动态采集	\N	\N	\N
026001	新增动态采集	\N	\N	026
026002	编辑动态采集	\N	\N	026
026003	删除动态采集	\N	\N	026
027	BIM模型	\N	\N	\N
027001	添加模型	\N	\N	027
027002	更新模型	\N	\N	027
027003	测点布设	\N	\N	027
028	项目公告	\N	\N	\N
028001	新建项目公告	\N	\N	028
028002	编辑项目公告	\N	\N	028
028003	删除项目公告	\N	\N	028
\.


--
-- Data for Name: t_structure_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_structure_type (id, name, description, parent_type, portrait) FROM stdin;
4	大坝		0	\N
5	隧道		0	\N
6	尾矿库		0	\N
7	建筑物		0	\N
9	特种设备		0	\N
10	气象监测站		0	\N
11	市政管网		0	\N
12	涵洞	\N	0	\N
14	梁式桥		1	\N
15	拱式桥		1	\N
16	钢架桥		1	\N
17	斜拉桥		1	\N
18	悬索桥		1	\N
19	塔吊		0	\N
21	高支模		0	\N
23	公厕		0	\N
26	智慧路灯		0	\N
20	扬尘		0	\N
28	医护		0	\N
29	垃圾箱		0	\N
27	河流		0	\N
31	卸料平台		0	\N
25	定位设备		0	\N
35	升降机	\N	0	\N
36	爬架		0	\N
3	边坡		0	\N
2	基坑		0	\N
8	铁塔		0	\N
38	路灯	\N	0	\N
40	水质监测站	\N	0	\N
41	站台		0	\N
39	小区	\N	0	\N
42	管道管线		0	\N
43	园区企业		0	\N
33	地灾		0	\N
1	桥梁		0	\N
48	烟囱		0	\N
47	消火栓		0	\N
46	消防		0	\N
24	农业		0	
\.


--
-- Data for Name: t_structure_type_factor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_structure_type_factor (id, structure_type, factor) FROM stdin;
1	1	1
2	1	2
3	1	3
4	1	4
5	1	5
6	1	6
7	1	7
8	1	8
9	1	9
10	1	10
11	1	11
12	1	12
13	1	13
14	1	14
15	1	15
16	1	16
17	1	17
18	1	18
19	1	19
20	1	20
21	1	21
22	1	22
23	1	23
24	1	24
25	1	25
26	1	26
27	1	27
28	1	28
31	2	31
33	2	33
34	2	34
35	2	35
36	2	36
37	2	37
38	2	38
39	2	39
40	2	40
41	2	41
42	2	42
43	2	43
44	2	44
45	2	45
46	2	46
47	2	47
48	2	48
49	2	49
50	2	50
51	2	51
52	2	52
1046	7	332
1047	7	333
58	3	58
1050	2	336
1051	7	337
1052	33	338
1053	46	339
1055	46	341
70	4	70
71	4	71
72	4	72
75	4	75
76	4	76
77	4	77
79	4	79
1057	46	1
84	5	84
85	5	85
86	5	86
88	5	88
89	5	89
90	5	90
91	5	91
92	5	92
93	5	93
94	5	94
95	5	95
96	5	96
97	5	97
98	5	98
102	5	102
103	5	103
104	5	104
105	5	105
106	5	106
107	5	107
108	5	108
109	5	109
112	6	112
113	6	113
114	6	114
116	6	116
117	6	117
1058	46	2
1060	46	342
1061	46	343
127	7	127
129	7	129
133	9	133
134	9	134
135	9	135
137	9	137
138	9	138
139	9	139
140	9	140
142	9	142
143	9	143
145	9	145
146	9	146
147	9	147
148	9	148
1066	1	325
1067	5	344
151	10	151
152	10	152
153	10	153
155	10	155
156	10	156
158	10	158
159	10	159
160	10	160
161	10	161
162	11	162
163	11	163
164	11	164
165	11	165
166	11	166
167	11	167
168	11	168
169	9	169
170	10	170
171	10	171
173	7	173
174	11	174
175	2	127
176	5	153
209	2	204
210	2	205
29	2	2
55	3	3
67	4	3
81	5	3
110	6	3
120	7	3
30	2	4
68	4	4
82	5	4
111	6	4
57	3	31
69	4	31
83	5	31
122	7	31
32	2	5
123	7	5
136	9	5
201	5	5
154	10	137
203	5	166
202	5	156
73	4	58
87	5	34
172	7	34
74	4	43
124	7	11
141	9	11
208	10	11
62	3	13
99	5	13
115	6	13
125	7	13
66	3	52
78	4	18
100	5	18
128	7	18
53	2	26
130	7	26
144	9	26
101	5	204
126	7	204
216	11	211
219	1	156
220	11	214
221	10	215
222	10	216
223	10	217
224	10	218
225	10	219
226	10	220
228	2	222
229	2	223
232	9	226
234	1	228
237	9	231
238	9	232
240	8	234
243	7	237
244	7	140
245	7	156
246	7	21
247	6	238
248	2	239
250	2	241
252	10	242
253	10	243
254	19	249
255	20	250
256	21	251
257	21	252
258	21	253
259	21	254
260	14	2
261	14	7
262	14	15
263	14	28
264	15	2
265	15	7
266	15	15
267	15	28
268	16	2
269	16	7
270	16	15
271	16	28
272	17	2
273	17	7
274	17	15
275	17	28
276	18	2
277	18	7
278	18	15
279	18	28
280	10	255
281	10	256
289	23	259
290	23	260
291	23	261
292	23	263
293	23	262
294	23	2
295	19	264
298	24	267
302	25	271
303	26	1
304	26	242
118	7	2
54	3	2
80	5	2
119	7	2
149	10	2
212	12	2
235	8	2
157	10	3
121	7	4
132	9	4
150	10	4
215	12	4
239	9	167
231	1	206
414	3	310
230	7	223
241	11	226
214	12	11
282	1	237
249	7	24
312	28	274
313	28	275
213	12	204
242	1	204
305	26	272
306	20	259
307	2	273
310	27	256
311	27	250
314	28	276
315	28	277
316	28	278
317	28	279
318	28	280
352	27	283
353	1	284
354	29	284
355	27	3
356	27	31
357	10	285
358	2	286
359	10	287
360	23	288
361	5	289
362	4	290
363	4	291
364	4	292
365	23	293
366	6	294
367	4	295
368	4	296
369	31	297
371	2	299
374	2	301
375	2	300
376	2	298
378	33	3
379	33	31
380	33	302
381	1	303
382	10	304
383	35	264
385	36	306
388	36	251
389	36	253
390	36	252
391	3	60
392	3	61
393	3	63
394	3	4
395	3	151
396	3	156
397	3	33
398	3	24
399	3	18
400	3	204
401	3	206
402	3	241
403	3	35
404	3	36
405	3	11
406	3	307
407	6	308
408	2	94
409	2	309
415	8	131
416	8	227
417	8	3
418	8	156
419	8	206
420	8	11
422	2	311
423	2	312
424	5	313
425	38	314
426	7	315
427	40	256
428	41	316
430	6	317
431	39	256
432	39	250
433	39	260
434	39	259
435	39	314
436	39	315
438	1	319
439	1	320
440	39	320
441	2	321
442	20	322
443	42	256
444	42	70
445	42	140
446	7	323
447	3	324
449	27	326
450	2	327
451	1	328
452	33	1
453	33	2
454	33	4
455	33	5
456	33	6
457	33	7
458	33	8
459	33	9
460	33	10
461	33	11
462	33	13
463	33	14
464	33	15
465	33	16
466	33	17
467	33	18
468	33	19
469	33	20
470	33	21
471	33	22
472	33	23
473	33	24
474	33	25
475	33	26
476	33	27
477	33	28
478	33	33
479	33	36
480	33	37
481	33	38
482	33	39
483	33	40
484	33	41
485	33	42
486	33	43
487	33	44
488	33	45
489	33	46
490	33	47
491	33	48
492	33	49
493	33	50
494	33	51
495	33	52
496	33	58
497	33	60
498	33	61
499	33	63
500	33	70
501	33	71
502	33	72
503	33	75
504	33	76
505	33	77
506	33	79
507	33	84
508	33	85
509	33	86
510	33	88
511	33	89
512	33	90
513	33	91
514	33	92
515	33	93
516	33	94
517	33	95
518	33	96
519	33	97
520	33	98
521	33	102
522	33	103
523	33	104
524	33	105
525	33	106
526	33	107
527	33	108
528	33	109
529	33	112
530	33	113
531	33	114
532	33	116
533	33	117
534	33	127
535	33	129
536	33	131
537	33	133
538	33	134
539	33	135
540	33	137
541	33	138
542	33	12
543	33	35
544	33	139
545	33	140
546	33	142
547	33	143
548	33	145
549	33	146
550	33	147
551	33	148
552	33	151
553	33	152
554	33	153
555	33	155
556	33	156
557	33	158
558	33	159
559	33	160
560	33	161
561	33	162
562	33	163
563	33	164
564	33	165
565	33	166
566	33	167
567	33	168
568	33	169
569	33	170
570	33	171
571	33	173
572	33	174
573	33	204
574	33	205
575	33	206
576	33	211
577	33	214
578	33	215
579	33	216
580	33	217
581	33	218
582	33	219
583	33	220
584	33	222
585	33	223
586	33	226
587	33	227
588	33	228
589	33	231
590	33	232
591	33	234
592	33	237
593	33	238
594	33	239
595	33	241
596	33	242
597	33	243
598	33	249
599	33	250
600	33	251
601	33	252
602	33	253
603	33	255
604	33	256
605	33	259
606	33	260
607	33	261
608	33	262
609	33	263
610	33	264
611	33	266
612	33	267
613	33	269
614	33	34
615	33	272
616	33	271
617	33	273
618	33	274
619	33	275
620	33	276
621	33	277
622	33	278
623	33	279
624	33	280
625	33	284
626	33	285
627	33	287
628	33	288
629	33	289
630	33	293
631	33	297
632	33	303
633	33	310
634	33	312
635	33	313
636	33	314
637	33	315
638	33	316
639	33	319
640	33	320
641	33	321
642	33	323
643	33	325
644	33	327
645	33	328
646	1	329
647	1	330
648	3	330
649	10	330
1049	2	335
1054	46	340
1068	5	345
1069	3	346
1070	3	347
1071	48	348
1072	46	315
1074	47	342
1075	47	315
1076	7	349
1077	43	259
1078	3	350
1103	24	266
1104	24	269
1105	24	152
1106	24	153
1107	24	250
1108	24	3
1111	5	353
1112	5	354
1113	2	355
1114	5	356
1115	1	357
1118	43	359
\.


--
-- Data for Name: t_type_alarm_source; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_type_alarm_source (id, name, description) FROM stdin;
0	DTU	\N
1	传感器	\N
2	测点	\N
\.


--
-- Data for Name: t_type_alarm_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_type_alarm_state (id, name, description) FROM stdin;
0	未恢复	\N
1	人工恢复	\N
2	自动回复	\N
\.


--
-- Data for Name: t_type_event_index; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_type_event_index (id, name, description) FROM stdin;
1	暴雨预警	\N
2	平台数据类告警	\N
3	近十日降雨量	\N
4	地震发生情况	\N
5	地灾发生情况	\N
\.


--
-- Data for Name: t_type_file_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_type_file_type (id, name) FROM stdin;
2	报表文件
3	数据文件
1	应用文件
4	审核报告
\.


--
-- Data for Name: t_type_institution_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_type_institution_role (id, name, description) FROM stdin;
1	住建局	
2	监理单位	
3	施工单位	
4	建设单位	
\.


--
-- Data for Name: t_type_org_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_type_org_type (id, name, description) FROM stdin;
1002	Owner	业主
1001	Agent	集成商
1003	Assess	评估商
1004	Operator	运营商
\.


--
-- Data for Name: t_type_project_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_type_project_state (id, name, description) FROM stdin;
0	待发审	等待发起审核
1	待审核	审核处理中
2	待修改	审核未通过,等待修改
3	审核通过	项目已审核通过
4	已发布	项目已发布
-1	已删除	项目已删除
\.


--
-- Data for Name: t_type_report_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_type_report_state (id, name, description) FROM stdin;
0	未确认	\N
1	已确认	\N
\.


--
-- Data for Name: t_type_role_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_type_role_type (code, description) FROM stdin;
A	注册机构的所有者
C	项目机构的管理员
CC	非管理员子角色
B	运营机构的管理员
\.


--
-- Data for Name: t_units; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_units (name, dimension, description, coef, base, alternative) FROM stdin;
km	length	千米	1000.0000000000000000	f	\N
dm	length	分米	0.1000000000000000	f	\N
cm	length	厘米	0.0100000000000000	f	\N
mm	length	毫米	0.0010000000000000	f	\N
um	length	微米	0.0000010000000000	f	\N
nm	length	纳米	0.0000000010000000	f	\N
pm	length	皮米	0.0000000000010000	f	\N
ly	length	光年	9460700000000000.0000000000000000	f	\N
AU	length	天文单位	149600000000.0000000000000000	f	\N
in	length	英寸,inch	0.0254000000000000	f	\N
ft	length	英尺	0.3048000000000000	f	\N
yd	length	码	0.9144000000000000	f	\N
mi	length	英里	1609.3440000000000000	f	\N
nmi	length	海里	1852.0000000000000000	f	\N
fm	length	英寻	1.8288000000000000	f	\N
fur	length	弗隆	201.1680000000000000	f	\N
里	length	里	500.0000000000000000	f	\N
丈	length	丈	3.3333333000000000	f	\N
尺	length	尺	0.3333333000000000	f	\N
寸	length	寸	0.0333333000000000	f	\N
分	length	分	0.0033333000000000	f	\N
厘	length	厘	0.0003333000000000	f	\N
毫	length	毫	0.0000333000000000	f	\N
g	weight	克	0.0010000000000000	f	\N
mg	weight	毫克	0.0000010000000000	f	\N
ug	weight	微克	0.0000000010000000	f	\N
t	weight	吨	1000.0000000000000000	f	\N
q	weight	公担	100.0000000000000000	f	\N
ct	weight	克拉	0.0002000000000000	f	\N
point	weight	分	0.0000020000000000	f	\N
dwt	weight	英钱	1.3607800000000000	f	\N
oz	weight	盎司	0.0283495000000000	f	\N
lb	weight	磅	0.4535924000000000	f	\N
dr	weight	打兰	0.0017718000000000	f	\N
两	weight	两	0.0500000000000000	f	\N
钱	weight	钱	0.0050000000000000	f	\N
斤	weight	斤,市斤	0.5000000000000000	f	\N
yr	time	年,year	31536000.0000000000000000	f	\N
week	time	周,week	604800.0000000000000000	f	\N
d	time	天,day	86400.0000000000000000	f	\N
h	time	时,小时,hour	3600.0000000000000000	f	\N
min	time	分,分钟,minute	60.0000000000000000	f	\N
ms	time	毫秒	0.0010000000000000	f	\N
us	time	微秒	0.0000010000000000	f	\N
ns	time	纳秒	0.0000000010000000	f	\N
kA	current	千安	1000.0000000000000000	f	\N
MA	current	兆安	1000000.0000000000000000	f	\N
mA	current	毫安	0.0010000000000000	f	\N
uA	current	微安	0.0000010000000000	f	\N
nA	current	纳安	0.0000000010000000	f	\N
m	length	米	1.0000000000000000	t	\N
kg	weight	千克,公斤	1.0000000000000000	t	\N
s	time	秒,second	1.0000000000000000	t	\N
A	current	安	1.0000000000000000	t	\N
℃	temperature	摄氏度	274.1500000000000000	f	\N
℉	temperature	华氏度	255.9277778000000000	f	\N
kPa	pressure	千帕	1000.0000000000000000	f	\N
MPa	pressure	兆帕	1000000.0000000000000000	f	\N
hPa	pressure	百帕	100.0000000000000000	f	\N
atm	pressure	标准大气压	101325.0000000000000000	f	\N
bar	pressure	巴	100000.0000000000000000	f	\N
mmHg	pressure	毫米汞柱	133.3223684000000000	f	\N
mmH2O	pressure	毫米水柱	9.8066136000000000	f	\N
mH2O	pressure	米水柱	9806.6136000000000000	f	\N
mbar	pressure	毫巴	100.0000000000000000	f	\N
K	temperature	开氏度	1.0000000000000000	t	\N
kN	force	千牛	1000.0000000000000000	f	\N
kgf	force	千克力	9.8066500000000000	f	\N
kg/dm3	density	千克/立方分米	1000.0000000000000000	f	\N
kg/cm3	density	千克/立方厘米	1000000.0000000000000000	f	\N
kJ	work	千焦	1000.0000000000000000	f	\N
kW·h	work	千瓦·时,度	3600000.0000000000000000	f	\N
cal	work	卡	4.1858518000000000	f	\N
kcal	work	千卡	4185.8518208000000000	f	\N
N	force	牛	1.0000000000000000	t	\N
kg/m3	density	千克/立方米	1.0000000000000000	t	\N
J	work	焦耳	1.0000000000000000	t	\N
kW	power	千瓦	1000.0000000000000000	f	\N
kg·m/s	power	公斤·米/秒	9.8066500000000000	f	\N
N·m/s	power	牛顿·米/秒	1.0000000000000000	f	\N
J/s	power	焦耳/秒	1.0000000000000000	f	\N
W	power	瓦,瓦特	1.0000000000000000	t	\N
l	volume	升	0.0010000000000000	f	\N
mm3	volume	立方毫米	0.0000000010000000	f	\N
ml	volume	毫升	0.0000010000000000	f	\N
cm3	volume	立方厘米	0.0000010000000000	f	\N
dm3	volume	立方分米	0.0010000000000000	f	\N
m3	volume	立方米	1.0000000000000000	t	\N
km2	area	平方千米	1000000.0000000000000000	f	\N
dm2	area	平方分米	0.0100000000000000	f	\N
cm2	area	平方厘米	0.0001000000000000	f	\N
mm2	area	平方毫米	0.0000010000000000	f	\N
m2	area	平方米	1.0000000000000000	t	\N
C/s	current	C/s	0.1000000000000000	f	\N
GA	current	GA	1000000000.0000000000000000	f	\N
Pa	pressure	帕斯卡,帕	1.0000000000000000	t	N/m2
kN/mm2	pressure	kN/mm^2	1000000000.0000000000000000	f	\N
ε	strain	ε	1.0000000000000000	t	_
uε	strain	με	0.0000010000000000	f	\N
m3/s	flow	立方米每秒	1.0000000000000000	t	m^3/s
L/s	flow	升每秒	0.0010000000000000	f	\N
t	force	吨	10000.0000000000000000	f	\N
\.


--
-- Data for Name: t_video_nvr_vendor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.t_video_nvr_vendor (id, name, enabled) FROM stdin;
1	海康威视	t
2	浙江大华技术股份有限公司	t
\.


--
-- Name: t_alarm_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_alarm_category_id_seq', 1, false);


--
-- Name: t_alarm_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_alarm_code_id_seq', 107, true);


--
-- Name: t_alarm_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_alarm_type_id_seq', 21, true);


--
-- Name: t_calendar_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_calendar_type_id_seq', 3, true);


--
-- Name: t_component_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_component_id_seq', 1, false);


--
-- Name: t_factor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_factor_id_seq', 359, true);


--
-- Name: t_factor_proto_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_factor_proto_device_id_seq', 905, true);


--
-- Name: t_factor_proto_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_factor_proto_item_id_seq', 413, true);


--
-- Name: t_filter_method_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_filter_method_id_seq', 1, false);


--
-- Name: t_formula_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_formula_id_seq', 1, false);


--
-- Name: t_group_type_factor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_group_type_factor_id_seq', 4, true);


--
-- Name: t_item_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_item_unit_id_seq', 409, true);


--
-- Name: t_report_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_report_template_id_seq', 14, true);


--
-- Name: t_structure_type_factor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_structure_type_factor_id_seq', 1118, true);


--
-- Name: t_structure_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_structure_type_id_seq', 50, true);


--
-- Name: t_type_event_index_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_type_event_index_id_seq', 1, false);


--
-- Name: t_video_nvr_vendor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.t_video_nvr_vendor_id_seq', 2, true);


--
-- PostgreSQL database dump complete
--



INSERT INTO public.t_organization (id, org_type, name, domain, state, aptitude_file, register_code, logo, scale, region, app_key, app_secret) VALUES (1, 1001, '江西飞尚科技有限公司云平台', 'anxinyun', 1, null, '9e370b8f-4c3e-4032-a366-4acb146711bc', 'image/6eaec9cb-9d75-4a63-bb28-5f6f7e2aacd8/image.png', '21-50人', '649,705,708', '654e52caf15361dd09419addd42edcc40e7f9870', '4c5a064360b9ba35fe59440efab3b1c720c34c9a');

INSERT INTO public.t_department (id, org, name) VALUES (1, 1, '默认');

INSERT INTO public.t_role (id, dep, name, portal, description, type) VALUES (1, 1, '所有者', 'A', null, false);

INSERT INTO public.t_user (id, name, name_present, password, phone, email, avator, org, role, register_time, mail_notice, sms_notice, no_disturb, enabled, open_id, nick_name, wx_notice, union_id, institution_role) VALUES (1, 'SuperAdmin', '超级管理员', 'c8a1b2245ee704e7657b2c9a7c9086af', '', 'admin@god.com', '8.png', 1, 1, '2018-07-25 08:00:28.465074', true, false, true, true, null, null, false, null, null);


INSERT INTO public.t_role_resource (role, resource) VALUES (1, '007004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '002001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '002002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '002003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '003001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '004001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '004002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '004003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '004004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '005');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '005001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '005002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '005003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '005004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '005005');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '005006');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '005007');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '005008');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '005009');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '006');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '006001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '006002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '006003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '007');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '007001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '007002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '007003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '008');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '008001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '008002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '008003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '009');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '009001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '009002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '009003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '009004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '010');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '010001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '010002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '010003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '010004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '011');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '011001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '011002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '011003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '012');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '012001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '012002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '012003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013005');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013006');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013007');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013008');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013009');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013010');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013011');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013012');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '013013');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '014');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '014001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '014002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '014003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '014004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '015');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '015001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '016');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '016001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '016002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '016003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '017');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '017001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '017002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '017003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '017004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '017005');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '017006');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '001001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '001002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '001003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '018');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '018001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '018002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '018003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '018004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '018005');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '018006');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '019');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '019002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '019003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '019004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '020');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '020002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '020003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '020004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '021');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '021001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '021002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '021003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '015002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '015003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '022');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '022001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '023');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '023001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '024');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '024001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '025');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '025001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '025002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '025003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '025004');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '010005');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '010006');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '010007');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '010008');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '026');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '026001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '026002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '026003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '027');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '027001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '027002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '027003');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '028001');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '028002');
INSERT INTO public.t_role_resource (role, resource) VALUES (1, '028003');