#!/bin/bash
#k8s的 pod名称获取,后续需需要改进
#-f 容器内脚本 不加 则 宿主机内脚本
microk8s.kubectl exec  -it pg-deployment-8564d489c8-7xr95 -n lk  -- psql -U postgres -f script/create_db.sql

microk8s.kubectl exec  -it pg-deployment-8564d489c8-7xr95 -n lk  -- psql -U postgres  -d iota -f script/iota_create.sql

microk8s.kubectl exec  -it pg-deployment-8564d489c8-7xr95 -n lk  -- psql -U postgres -d axy -f script/axy_schema.sql

microk8s.kubectl exec  -it pg-deployment-8564d489c8-7xr95 -n lk  -- psql -U postgres -d axy -f script/axy_data.sql
