#!/bin/bash
for i in $(ls ./base_images/ESAndKibana/ES/es_index/);
do
	echo "--2"
	setting=$(cat ./base_images/ESAndKibana/ES/es_index/$i)
	#30092 是k8s的es-service 的nodePort
	curl -H "Content-Type: application/json" -XPUT "http://localhost:30092/$i" -d "$setting"
done
