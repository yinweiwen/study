#! /bin/bash

yaml_list=()
index=0
function read_dir() {

    for file in $(ls $1); do
        local path=$1"/"$file
        if [ -d $path ]; then #注意此处之间一定要加上空格，否则会报错
            read_dir $path
        else
            #echo $path #在此处处理文件即可
            extendname=${file##*.}
            if [ "$extendname" == "yaml" ]; then

                yaml_list[index]="$path"
                echo "找到yaml文件：${yaml_list[index]}"
                index=$((index + 1))
            fi
        fi
    done
    #echo "数组元素个数为: ${#yaml_list[*]}"
}
#读取第一个参数
read_dir $1
echo "c-数组元素个数为: ${#yaml_list[*]}"
return 0