#!/bin/bash
#所有app镜像
images=(
    docker.io/emqx/emqx:4.3.9=docker.io/emqx/emqx:4.3.9
    repository.anxinyun.cn/base-images/es:6.8.2-3.21-04-21=repository.anxinyun.cn/base-images/es:6.8.2-3.21-04-21
    repository.anxinyun.cn/base-images/kibana:6.8.2=repository.anxinyun.cn/base-images/kibana:6.8.2
    repository.anxinyun.cn/base-images/kafka-alpine:2.11-1.21-04-19=repository.anxinyun.cn/base-images/kafka-alpine:2.11-1.21-04-19
    repository.anxinyun.cn/base-images/pg:12-1.21-04-14=repository.anxinyun.cn/base-images/pg:12-1.21-04-14
    repository.anxinyun.cn/base-images/adminer:latest=repository.anxinyun.cn/base-images/adminer:latest
    repository.anxinyun.cn/base-images/redis:5-1.21-04-13=repository.anxinyun.cn/base-images/redis:5-1.21-04-13
   
)

OIFS=$IFS # 保存旧值

for image in ${images[*]}; do
    IFS='='
    set $image
    echo "准备拉取 $2"
    microk8s.ctr image pull $2
    #microk8s.ctr image tag $2 $1
    #microk8s.ctr image rm $2
    echo "拉取成功 $2"
    IFS=$OIFS # 还原旧值
done

return 0
