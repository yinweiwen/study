#!/bin/bash
#所有app镜像
images=(
    repository.anxinyun.cn/anxinyun/smislocal-alarm:6.21-03-18=repository.anxinyun.cn/anxinyun/smislocal-alarm:6.21-03-18
    repository.anxinyun.cn/local/config_center:latest=repository.anxinyun.cn/local/config_center:latest
    repository.anxinyun.cn/anxinyun/api:137.21-08-17=repository.anxinyun.cn/anxinyun/api:137.21-08-17
    repository.anxinyun.cn/anxinyun/console-web:75.21-06-10=repository.anxinyun.cn/anxinyun/console-web:75.21-06-10
    repository.anxinyun.cn/anxinyun/project:latest=repository.anxinyun.cn/anxinyun/project:latest
    repository.anxinyun.cn/local/et:latest=repository.anxinyun.cn/local/et:latest
    repository.anxinyun.cn/local/dac:4.22-03-29=repository.anxinyun.cn/local/dac:4.22-03-29
    repository.anxinyun.cn/local/prometheus:1.22-03-29=repository.anxinyun.cn/local/prometheus:1.22-03-29
    repository.anxinyun.cn/anxin/iota-proxy:latest=repository.anxinyun.cn/anxin/iota-proxy:latest
    repository.anxinyun.cn/iota/web-console-api:50.21-05-24=repository.anxinyun.cn/iota/web-console-api:50.21-05-24 
    repository.anxinyun.cn/anxinyun/py.rpc:dragon.32=repository.anxinyun.cn/anxinyun/py.rpc:dragon.32
    repository.anxinyun.cn/local/report-client:12.21-10-28=repository.anxinyun.cn/local/report-client:12.21-10-28
)

OIFS=$IFS # 保存旧值

for image in ${images[*]}; do
    IFS='='
    set $image
    echo "准备拉取 $2"
    microk8s.ctr image pull $2
    #microk8s.ctr image tag $2 $1
    #microk8s.ctr image rm $2
    echo "拉取成功 $2"
    IFS=$OIFS # 还原旧值
done

return 0
